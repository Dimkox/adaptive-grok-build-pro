# Release

- Version: 2.0.6
- Commit: `549f29da1c4ff44ba44d8388c294fd5dd29bfd81`
- Assets: `packages/adaptive-grok-build-pro-v2.0.6.zip` + `.sha256`
- Notes: `dist/RELEASE-NOTES.md`
- Go: user «делай всё полностью вместе с релизом»
