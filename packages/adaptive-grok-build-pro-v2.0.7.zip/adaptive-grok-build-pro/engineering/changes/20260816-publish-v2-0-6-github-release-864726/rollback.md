# Rollback

```bash
gh release delete v2.0.6 --yes
git push origin :refs/tags/v2.0.6
git tag -d v2.0.6
```

Do not delete v2.0.5. If main must revert: revert `549f29d` and push (separate approval). No force-push.
