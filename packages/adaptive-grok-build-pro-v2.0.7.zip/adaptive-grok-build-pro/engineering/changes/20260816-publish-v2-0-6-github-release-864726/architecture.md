# Architecture

No product-code change. Last mile only. write_agent is null.

Sequence: approve → tag existing commit → push main → push tag → gh release create. Do not run package_stack again. Do not `git add` leftover evidence.
