# Test plan

Observational:

1. `git rev-parse 'v2.0.6^{}'` == `549f29da1c4ff44ba44d8388c294fd5dd29bfd81`
2. `gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest` tag_name v2.0.6
3. Zip digest matches `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`
4. `gh release view v2.0.5` still exists
5. `python3 scripts/grok_verify.py --mode pr` on the published tree
