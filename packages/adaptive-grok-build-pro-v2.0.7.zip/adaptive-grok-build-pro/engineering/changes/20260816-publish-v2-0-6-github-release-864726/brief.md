# Publish v2.0.6 GitHub Release

Working 2.0.6 is already committed locally (`549f29d`). Origin/main is still `7c0ae75` (v2.0.5). GitHub Latest is v2.0.5. User demanded the full publish: «делай всё полностью вместе с релизом».

## Outcome

GitHub Latest is v2.0.6 on commit `549f29d` with the existing zip + sha256.

## Scope

- Tag existing `549f29d` as annotated `v2.0.6`
- `git push origin main` then `git push origin v2.0.6`
- `gh release create` with existing `packages/` assets and `dist/RELEASE-NOTES.md`

## Out of scope

- Rebuild zip, retag 2.0.5, force-push, commit leftover ad4090 dirt, new product features
