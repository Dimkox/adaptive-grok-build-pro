# Analysis — architect (last mile for already-committed v2.0.6)

Change: `20260816-publish-v2-0-6-github-release-864726`  
Active route: `864726c99dba` · intent=`release` · risk=`high` · write=`null` · reviews=`security_reviewer`+`release_reviewer` · gates=`scope_and_design_approval`,`production_action_approval`  
Prior ship: `ec0388` status `ready` on commit `549f29d`  
User: GitHub Latest still v2.0.5 (6 releases) · «делай всё полностью вместе с релизом»

Read-only design. No application-code edits. No `.env` read. No push / tag / merge / `gh release` from this agent.

Narrow question: exact last-mile commands to publish already-committed 2.0.6, and who executes.

## Ruling

**No rebuild. No retag of `v2.0.5`. No second commit of leftover dirt. Tag existing `549f29d` as annotated `v2.0.6`, push that SHA to `main`, push the tag, then `gh release create`. `write_agent` is null, so the parent controller executes after a live `grok_approve.py production` token. Rollback deletes only `v2.0.6`.**

| # | Decision | Ruling |
| --- | --- | --- |
| 1 | Command sequence | Preconditions → `grok_approve production` → `git tag -a v2.0.6 549f29d` → `git push origin 549f29d:refs/heads/main` → `git push origin v2.0.6` → `gh release create v2.0.6` with existing `packages/` assets + `dist/RELEASE-NOTES.md`. |
| 2 | Rebuild zip? | **No.** Digest is already `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`. `package_stack` now would fold post-`549f29d` paperwork. |
| 3 | Retag `v2.0.5`? | **No.** Leave local/remote `v2.0.5` = annotated `7f85f7be…` peeling to `7c0ae75`. GitHub Release `v2.0.5` stays. |
| 4 | Second commit? | **No.** Do not `git add` this 864726 package, runtime, `dist/`, or leftover ad4090/cd8a96/ec0388 evidence. Push the existing ship SHA only. |
| 5 | Who executes | **Controller**, after `grok_approve.py production`. Not architect. Not analysis/review agents. There is no write owner to print-and-stop. |
| 6 | `grok_approve` | **Required** for controller/agent `Bash` that contains `git push` or `gh release create`. Human terminal may skip. Expired 2.0.5 tokens are dead. |

Default runbook `engineering/runbooks/publish-v2.0.6.md` is print-only. This route is the authorized exception, same pattern as cd8a96 for 2.0.5: user-approved scope (source of truth #1) plus recorded `production_action_approval` plus `write_agent=null`. Print-only already left Latest on 2.0.5.

This report is design. It is not authorization for the architect to run the last mile.

## Current facts (inspected this wave)

| Item | Value |
| --- | --- |
| Local `HEAD` / `refs/heads/main` | `549f29da1c4ff44ba44d8388c294fd5dd29bfd81` — `Release v2.0.6: ruff, bandit, coverage, dependabot` |
| `origin/main` | `7c0ae7573535ddd0cfe3800f81278991ced81584` (v2.0.5 ship) |
| Ancestry | linear fast-forward: `7c0ae75` → `549f29d` (`.git/logs/HEAD`) |
| Local tags | `v2.0.0`–`v2.0.5` present. **No** `refs/tags/v2.0.6` |
| Local `v2.0.5` | annotated object `7f85f7be43fd8008f6af522a967ebc5268a481d1` (unchanged from cd8a96) |
| Local `v2.0.4` | `10c522f294bc5ffbdbef32d1487af59ff4e8453b` (untouched) |
| GitHub Latest | `v2.0.5` on `7c0ae75` (html `/releases` and `/releases/latest`, 2026-08-16) |
| GitHub Releases | six: `v2.0.0`–`v2.0.5`. No `v2.0.6` |
| Remote | `origin` = `https://github.com/Dimkox/adaptive-grok-build-pro.git` |
| `VERSION` | `2.0.6` |
| Zip digest (`packages/` + `dist/` siblings) | `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610` |
| `dist/RELEASE-NOTES.md` | CHANGELOG `## 2.0.6` verbatim (gitignored scratch; present) |
| Prior ship package | `ec0388` status `ready`; zip assembled and committed on `549f29d` |
| `approvals.json` | two rows dated `2026-08-16T16:09:55Z`, expired `16:24:55Z`, reason “publish v2.0.5…”. **Dead.** |
| Active change | this 864726 package, status `draft` (created `17:47:18Z`, after the ship) |
| This-route receipts | empty (`864726c99dba/`) |
| CI | verify + upload `dist/*.zip*`; **no** `gh release` / `git push` |

Leftover after `549f29d` (do not add before tag/push): this whole 864726 package, any post-ship evidence under ad4090 / cd8a96 / ec0388, gitignored runtime / `dist/` / `err.log`. Stay out of any add: `.env`, `.env.*`, keys.

## 1. Exact command sequence

`scripts/grok_deploy.py` / `deploy.py:_human_commands` still print the full six-line runbook (`package_stack` → `cp` → `git tag` → `git push origin <branch>` → `git push origin v2.0.6` → `gh release create`). That printer is **stale relative to this tree**: packager and `cp` are already done. Running `grok_deploy.py` **now also fails**: change is `draft` and route `864726c99dba` has no verification/review receipts (`deploy.py:55-63`). That failure is not a publish blocker. Use the reduced SHA-pinned sequence below.

Order is load-bearing: **approve, then tag the ship SHA, then push `main`, then push the tag, then create the release.**

- Tag before push so the annotated object exists locally and cannot be minted later by `gh`.
- Push `main` before the tag so default-branch `VERSION` and the tag move together; a tag-only push would advertise 2.0.6 while `main` still reads 2.0.5.
- Push the annotated tag before `gh release create`. `gh release create v2.0.6` with no remote tag can mint a *different* tag from `HEAD`. A later `git push origin v2.0.6` would then reject (or require `-f`, which is forbidden).

### 1.1 Machine token (controller Bash only)

```bash
python3 scripts/grok_approve.py production --reason "publish v2.0.6 tag and GitHub Release"
```

- TTL default **15 minutes**. Finish tag + both pushes + `gh` inside that window.
- `grok_approve.py production` itself is allowed without a prior token (`test_approve_script_is_not_blocked_by_scope_argument`).
- PreToolUse blocks controller `Bash` whose leading argv is `git push` or `gh release create` until a live `production` row exists (`policy.py` `PRODUCTION_INVOCATIONS`; `test_policy.py` deny-without / allow-with).
- `git tag` is **not** a production invocation. Still pin the SHA; do not retag `v2.0.5`.
- `external-write` is **not** required for this Bash sequence. cd8a96 also minted one; that is optional insurance, **not** a license to call MCP `create_release`.
- Human terminal: PreToolUse does not apply; the token may be skipped. Outcome and command bytes stay the same.

Do not use MCP `create_release` / `create_or_update_ref`. That is an `external-write` side effect and a second publisher next to the runbook.

### 1.2 Preconditions — stop if any expect fails

```bash
git fetch origin

git rev-parse HEAD
# expect 549f29da1c4ff44ba44d8388c294fd5dd29bfd81

git rev-parse origin/main
# expect 7c0ae7573535ddd0cfe3800f81278991ced81584

git rev-parse 'v2.0.5^{}'
# expect 7c0ae7573535ddd0cfe3800f81278991ced81584

git show-ref --verify --quiet refs/tags/v2.0.6; echo $?
# expect 1 (local tag missing)

git ls-remote --tags origin 'refs/tags/v2.0.6'
# expect empty

# zip sibling must still be
# b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610  adaptive-grok-build-pro-v2.0.6.zip
test -f packages/adaptive-grok-build-pro-v2.0.6.zip
test -f packages/adaptive-grok-build-pro-v2.0.6.zip.sha256
test -f dist/RELEASE-NOTES.md

gh auth status
gh release view v2.0.5 --json tagName,isLatest
# expect tagName=v2.0.5 and isLatest=true before we publish
```

No-go if `origin/main` moved off `7c0ae75`, local `v2.0.5` no longer peels to `7c0ae75`, origin already has a `v2.0.6` object, `HEAD` is no longer `549f29d` **and** we cannot still name that SHA, or the zip digest changed. Then stop. Reassess. No `-f`.

### 1.3 Last mile — controller executes

```bash
git tag -a v2.0.6 549f29da1c4ff44ba44d8388c294fd5dd29bfd81 -m "v2.0.6"
git push origin 549f29da1c4ff44ba44d8388c294fd5dd29bfd81:refs/heads/main
git push origin v2.0.6
gh release create v2.0.6 \
  packages/adaptive-grok-build-pro-v2.0.6.zip \
  packages/adaptive-grok-build-pro-v2.0.6.zip.sha256 \
  --notes-file dist/RELEASE-NOTES.md \
  --verify-tag
```

SHA-pin is intentional:

- `git tag -a v2.0.6 <sha>` tags the ship even if a later paperwork commit moves `HEAD`.
- `git push origin <sha>:refs/heads/main` is the same fast-forward as `git push origin main` **iff** `HEAD` is still `549f29d`, and cannot accidentally push a later local commit.

`--verify-tag` makes `gh` refuse to mint a new tag if the annotated ref did not land on origin. Do **not** pass `--target`; that is how `gh` creates a tag when the ref is missing.

May be four Bash calls or one `&&` chain. Any chunk whose leading argv is `git push` or `gh release create` needs the live production token.

### 1.4 Confirm

```bash
git rev-parse 'v2.0.6^{}'
# expect 549f29da1c4ff44ba44d8388c294fd5dd29bfd81

git ls-remote origin refs/heads/main 'refs/tags/v2.0.6'
# main and peeled tag both 549f29d

gh release view v2.0.6
gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest --jq .tag_name
# expect v2.0.6

gh release view v2.0.5
# must still exist; must not be Latest
```

Asset digest on the published zip must remain `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`.

### 1.5 Skip (already done / would make things worse)

| Command | Why skip |
| --- | --- |
| `python3 scripts/package_stack.py` | Rebuild would include post-`549f29d` evidence and break digest `b34af685…` |
| `cp dist/…v2.0.6.zip* packages/` | Tracked zip already in `549f29d` |
| `git add` / commit of 864726, reviews, runtime | Second commit. Not the ship. Do not retag after paperwork |
| `git tag -a v2.0.5` / `-f` / `-d v2.0.5` | 2.0.5 is published Latest. Leave it |
| `git tag -a v2.0.6` without the SHA, after `HEAD` moved | Would pin paperwork, not the ship |
| `git push --force` / `git reset --hard` | `policy.py` `DESTRUCTIVE_COMMANDS` |
| `python3 scripts/grok_deploy.py` | Optional print only; currently fails on `draft` + missing receipts; printed packager line is wrong |
| `python3 scripts/grok_deploy.py --record` | Needs live production approval; still does not publish |
| MCP GitHub `create_release` / `create_or_update_ref` | Second publisher |

## 2. Do not move or recreate v2.0.5

`.git/refs/tags/v2.0.5` is still annotated object `7f85f7be43fd8008f6af522a967ebc5268a481d1`. cd8a96 already pushed it; GitHub Release `v2.0.5` is Latest on `7c0ae75`.

- `git tag -a v2.0.5` → fatal: tag exists. Do not “fix” with `-f`.
- `git tag -d v2.0.5` then recreate → unnecessary risk of retargeting a published release.
- `git tag` is **not** a production invocation; the hook would not stop an agent retag. This design still forbids it.

New tag name only: `v2.0.6` on `549f29d`.

## 3. No second commit on `main` before the tag

`549f29d` already contains VERSION/CHANGELOG/README 2.0.6, the tracked zip + sha256, `engineering/runbooks/publish-v2.0.6.md`, and the quality contour. That is the ship.

Uncommitted paths are paperwork:

- this 864726 package (brief/requirements/architecture/this analysis), created `17:47` after the ship
- possible post-ship evidence under ec0388 / cd8a96 / ad4090
- gitignored runtime / `dist/` / `err.log`

A pre-push evidence commit would move `HEAD` off the reviewed ship SHA and tempt a packager rebuild. Same ruling as cd8a96 / ad4090, now stronger because `origin/main` is still `7c0ae75` and the only missing advertisement is 2.0.6.

Optional hygiene commit **after** `v2.0.6` exists on origin is out of this last mile. Do not retag after that commit.

Working-tree dirt does not ride `git push origin <sha>:refs/heads/main`. Only a new commit would. Do not make one.

## 4. Who executes

| Action | Who |
| --- | --- |
| This design | `architect` (done; stop) |
| Parallel facts | `repo_explorer`, `docs_researcher` (read-only) |
| `grok_approve.py production` | **Controller** |
| `git tag` + `git push origin <sha>:main` + `git push origin v2.0.6` + `gh release create` | **Controller**, after the token |
| `package_stack` / retag `v2.0.5` / `git add` leftover evidence | Nobody |
| Human terminal running the same bytes | Also valid; then skip `grok_approve` |
| `security_reviewer` + `release_reviewer` | After last mile + `grok_verify --mode pr`, observational |
| This architect / analysis / review agents running last mile | **Forbidden** |

Why the controller, not a write owner and not a human-only print loop:

1. Source of truth #1: «делай всё полностью вместе с релизом» authorizes the **publish outcome** in this session, not another print-only close.
2. Route `write_agent` is `null`. Adaptive-delivery step 4 has no implementer to dispatch. The parent controller is the only remaining actor who can execute.
3. Named gates `scope_and_design_approval` and `production_action_approval` are already recorded in `evidence/human-approval.md`.
4. cd8a96 is the precedent: default runbook is print-only; a last-mile change with explicit user go is the exception, and the session owner runs the commands after `grok_approve`.
5. Adaptive-delivery close (`SKILL.md:103`) and `release-readiness` still forbid treating publish as *closure paperwork*. They do not repeal an explicit production gate on a `release` route.
6. PreToolUse still requires the 15-minute `production` token for controller `Bash`. Approval lifts the hook; it does not authorize force-push, retag of 2.0.5, or MCP.

Do not spawn `general_implementer` or any other write role. The hook will block it (`write_agent` is null).

## 5. Rollback that does not touch v2.0.5

Unchanged from `rollback.md` and `engineering/runbooks/publish-v2.0.6.md`:

```bash
gh release delete v2.0.6 --yes
git push origin :refs/tags/v2.0.6
git tag -d v2.0.6
```

| Must not | Why |
| --- | --- |
| `gh release delete v2.0.5` / edit that release | Published 2.0.5 stays the previous artifact |
| `git push origin :refs/tags/v2.0.5` / retag `v2.0.5` | Remote tag still peels to `7c0ae75` |
| `git push --force` / `git reset --hard` | Destructive; would rewrite `main` |
| Revert `549f29d` as part of a *failed tag/Release* | If `main` was not pushed, there is nothing to revert. If it was, reverting is a **separate** production approval |
| Delete `packages/…v2.0.6.zip*` | Tracked on `549f29d`; belongs on `main` even if the Release is withdrawn |

If `main` itself must come back later: revert `549f29d` and push (fresh production approval if an *agent* pushes). No force-push. That is not this last mile.

Note: `gh release delete` is **not** in `PRODUCTION_INVOCATIONS` (only `gh release create`). Rollback is still controller-or-human-owned so v2.0.5 cannot be deleted by a sloppy extra argument.

Partial-failure matrix:

| After | Next |
| --- | --- |
| `grok_approve` fails | Stop. Do not tag/push. Fix and retry approve only |
| Tag create fails (name taken locally) | Stop. Do not `-f`. Inspect peel. If it already is `549f29d`, continue from push |
| Tag ok, `main` push fails | Stop. Do not `gh release create`. Fix auth / non-ff. Retry SHA-pin push only. No `-f` |
| `main` ok, tag push fails | Retry `git push origin v2.0.6` only. Do not retag |
| Tag on origin, `gh` fails | Retry `gh release create … --verify-tag` only. Do not retag |
| Release created against the wrong tag object | Rollback **v2.0.6 only**. Recreate from a local annotated tag that peels to `549f29d`. No `-f` on `v2.0.5` |
| Notes wrong | `gh release edit v2.0.6 --notes-file dist/RELEASE-NOTES.md`. Do not retag |
| Zip wrong after publish | Rollback v2.0.6 only; new commit + **new** tag name. No `git tag -f v2.0.6` |
| Token expires mid-sequence | Re-run `grok_approve.py production` with the same reason. Resume the **next unfinished** command only |

## 6. Post-publish (not the last mile)

After Latest is `v2.0.6`:

1. Controller: `python3 scripts/grok_verify.py --mode pr` on the published tree (working tree may still contain this analysis; that is session paperwork, not a second ship).
2. Dispatch `security_reviewer` and `release_reviewer` in parallel. They inspect the **live** tag peel, Latest badge, zip digest, and that `v2.0.5` still exists. They do not execute.
3. Record `verification`, `security_review`, `release_review` receipts. A receipt is stale after any later repo write.
4. Optionally transition this change `draft` → `ready` / `released` and mark ec0388 released. Do not fold that paperwork into a new tag.

Those receipts close route `864726c99dba`. They are not a second ship.

## 7. Go / no-go

**Go** on existing commit `549f29d` + existing zip + new annotated tag `v2.0.6` + fast-forward `main` + GitHub Release `v2.0.6`.

**No-go** on packager rebuild, retag of `v2.0.5`, second commit of dirt, force-push, MCP release, architect-executed last mile, or spawning a write agent.

Acceptance (from `requirements.md` / `test-plan.md`):

- `git rev-parse 'v2.0.6^{}'` == `549f29da1c4ff44ba44d8388c294fd5dd29bfd81`
- `origin/main` is that SHA
- Remote tag `v2.0.6` exists
- GitHub Latest is `v2.0.6` with zip digest `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`
- Release `v2.0.5` still exists
