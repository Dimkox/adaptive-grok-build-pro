# Docs research — print vs execute, required artifacts, and whether this prompt is production approval

Route: `864726c99dba`. Change: `20260816-publish-v2-0-6-github-release-864726`.
Question: what `engineering/runbooks/publish-v2.0.6.md` and the 2.0.5 last-mile evidence say about executing vs printing, and whether this user prompt is enough production approval.

Read: `AGENTS.md`; `engineering/decisions.md`; `engineering/runbooks/publish-v2.0.{4,5,6}.md`; `.grok/skills/adaptive-delivery/SKILL.md`; `.grok/skills/release-readiness/SKILL.md`; this change package; `20260816-finish-unpublished-v2-0-5-tag-and-github-release-cd8a96` (brief, architecture, requirements, release, rollback, tasks, state, human-approval, implementation, analysis-docs_researcher, analysis-architect, code-review); `20260816-ship-working-v2-0-6-quality-contour-ec0388` (brief, release, state, implementation, analysis-task_analyst); `20260815-user-query-гит-пуш-пакет-релиз-user-query-ad4090/evidence/human-approval.md`; `CHANGELOG.md`; `README.md`; `QUICKSTART.md`; `dist/RELEASE-NOTES.md`; `packages/README.md`; `packages/adaptive-grok-build-pro-v2.0.6.zip.sha256`; `VERSION`; `deploy.py` `_human_commands`; `scripts/grok_approve.py`; `.grok-stack/runtime/approvals.json` (not `.env`).

No APIs invented. No `.env` read. This agent did not push, tag, or release.

## 1. Artifacts and notes required

Standing last-mile printer and the 2.0.6 runbook print the same six lines (`publish-v2.0.6.md:19-26`; `deploy.py:24-34`):

```bash
python3 scripts/package_stack.py
cp dist/adaptive-grok-build-pro-v2.0.6.zip* packages/
git tag -a v2.0.6 -m "v2.0.6"
git push origin main
git push origin v2.0.6
gh release create v2.0.6 packages/adaptive-grok-build-pro-v2.0.6.zip packages/adaptive-grok-build-pro-v2.0.6.zip.sha256 --notes-file dist/RELEASE-NOTES.md
```

This change already has the zip. `864726/architecture.md:5` and `864726/brief.md:17` forbid a rebuild. Skip the first two printer lines. Same reduction as cd8a96 vs the six-line 2.0.5 runbook.

| Contract | Value | Cite |
| --- | --- | --- |
| Tag | annotated `v2.0.6` | `publish-v2.0.6.md:22`; `864726/requirements.md:4` |
| Tag target | `549f29da1c4ff44ba44d8388c294fd5dd29bfd81` (`Release v2.0.6: ruff, bandit, coverage, dependabot`) | `864726/requirements.md:3-4`; `864726/release.md:4`; `ec0388/state.json:32` |
| `origin/main` | that same SHA (today it is still `7c0ae75`) | `864726/brief.md:3`; `864726/requirements.md:5`; local `refs/remotes/origin/main` |
| Remote tag | `v2.0.6` must exist after push | `864726/requirements.md:6` |
| Zip | `packages/adaptive-grok-build-pro-v2.0.6.zip` | `publish-v2.0.6.md:25`; `864726/release.md:5` |
| Sha256 sibling | `packages/adaptive-grok-build-pro-v2.0.6.zip.sha256` | same |
| Zip digest | `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610` | `864726/requirements.md:7`; `ec0388/evidence/implementation.md:82`; on-disk `.sha256` |
| Notes | `--notes-file dist/RELEASE-NOTES.md` | `publish-v2.0.6.md:25`; `864726/release.md:6` |
| Notes body | CHANGELOG `## 2.0.6 — 2026-08-16` verbatim (already on disk) | `ec0388/evidence/analysis-task_analyst.md:85`; `dist/RELEASE-NOTES.md:1-9` |
| Source tar.gz | **no** | 2.0.4 / 2.0.5 / 2.0.6 contracts are zip + sha256 only (`cd8a96/evidence/analysis-docs_researcher.md:216-217`) |
| Prior release | `v2.0.5` stays | `864726/requirements.md:8`; `864726/rollback.md:9`; `864726/brief.md:17` |

`dist/` is gitignored. `gh` reads the working-tree notes file. Do not attach the 2.0.5 notes, the v2.0.1 `dist/HANDOFF.md`, or invented Assets/Install sections.

Unlike the 2.0.5 last mile, **`git push origin main` is still required**. cd8a96 skipped it because `origin/main` was already `7c0ae75`. Here local `HEAD` is `549f29d` and `origin/main` is still the 2.0.5 SHA. No local tag `v2.0.6` exists (tags stop at `v2.0.5`).

Confirm after publish (`864726/test-plan.md`):

1. `git rev-parse 'v2.0.6^{}'` == `549f29da1c4ff44ba44d8388c294fd5dd29bfd81`
2. `gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest` `tag_name` `v2.0.6`
3. Zip digest still `b34af685…`
4. `gh release view v2.0.5` still exists

Rollback deletes only `v2.0.6` (`publish-v2.0.6.md:28-34`; `864726/rollback.md`). No force-push. Do not delete `v2.0.5`.

## 2. What the documents say about print vs execute

### Standing rule (print)

| Source | Says |
| --- | --- |
| `publish-v2.0.6.md:3-5` | **Print-only last mile.** Assemble the zip first; humans own tag / push / GitHub Release. Agents must not run `git push`, `git tag`, or `gh release`. |
| `publish-v2.0.5.md:3-5` | User-authorized publish, **same agent sentence**: humans own those commands. That sentence was added in ad4090 (`ad4090/evidence/implementation.md:17`) and was **not** removed after cd8a96 executed. |
| `publish-v2.0.4.md:1-3,40-42` | Human-owned. Agent never runs `git push` / `gh release`. `grok_deploy.py` only prepares and prints. |
| Adaptive-delivery §7 (`SKILL.md:103`) | Do not deploy, publish, merge, or perform external writes as **closure**. Last mile is `python3 scripts/grok_deploy.py`; **humans own the printed commands**. |
| Release-readiness (`SKILL.md:18-20`) | Do not deploy. `--record` only with production approval. Humans run the printed commands. |
| `README.md:110`, `QUICKSTART.md:33` | `grok_deploy.py` is prepare-only; humans run tag / push / GitHub Release. |
| `CHANGELOG.md:5` (2.0.6 section, also the notes file) | “2.0.5 remains the previous published GitHub Latest **until a human last mile**.” |
| `ec0388/release.md:5-6` | Do not tag, push, or `gh release` on that assemble route. |
| `ec0388/evidence/implementation.md:50,69,93` | Wrote the print-only 2.0.6 runbook. Did not tag/push/`gh`. Zip is not Latest until a human `grok_deploy`. |
| `ec0388/evidence/analysis-task_analyst.md:87,191-210` | Runbook **prints**. Prior cd8a96 «делай» finished **v2.0.5 only** and does not transfer. A later prompt that **names** push/release, plus `grok_approve.py production` and a ready change, is the only way those commands become in-scope. |

`git tag` is still **not** in `PRODUCTION_INVOCATIONS` (`decisions.md:33-35`; prior cd8a96 docs). The hook does not block tagging the same way it blocks `git push` / `gh release create`. The runbook and adaptive-delivery still forbid agents from tagging.

### AGENTS.md is conditional, not an absolute ban

Prohibited routine actions (`AGENTS.md:101-104`):

> - Direct push to a protected/shared branch.
> - Merge, publish, deploy, or production mutation by Grok Build **without short-lived explicit approval**.

Source-of-truth order puts **user-approved scope first** (`AGENTS.md:19-21`). Conflict rule: stop only for a named human gate or an irreversible/security-sensitive decision; otherwise make a bounded ruling and continue (`AGENTS.md:28`).

This route **has** the named gates `scope_and_design_approval` and `production_action_approval` (`864726/route.json:22-25`). Default machine-approval TTL is **15 minutes** (`grok_approve.py:18`; `cd8a96/evidence/analysis-docs_researcher.md:105`). Markdown `human-approval.md` is **not** `has_valid_approval` (`state.py:167-187`; same prior report).

`делай` is a follow-up token. It does **not** revive a ready route or a leftover from another session (`decisions.md:29-31`; `CHANGELOG.md:35`). That is why this is new route `864726`, not reuse of ready `ec0388` or ready `cd8a96`. Same session id `01a00b4c-c5a4-7a92-86c9-c2e96e4a6783` as cd8a96 does not merge the routes.

### What the 2.0.5 last mile actually did after «делай»

cd8a96 analysis **recommended print-only**. `cd8a96/evidence/analysis-docs_researcher.md:322` said current «делай» is **not** `production_action_approval`. `cd8a96/evidence/analysis-architect.md:14,24` said write owner **prints only**.

Then the change package **overruled** that default (`cd8a96/brief.md:45-51`; `cd8a96/architecture.md:15-17`):

> User-approved scope is source of truth #1. «делай» plus prior «да» authorizes finishing the last mile **in this session**. Print-only already left Latest on 2.0.4.
>
> Default runbook is print-only. This change is the authorized exception: record `grok_approve.py production` and execute the two remaining commands.
>
> Analysis recommended print-only. User source of truth #1 plus a day of unpublished Latest 2.0.4 overrides that default **for this change only**. Agent default «do not push» yields to this authorized last mile.

They then **executed** (`cd8a96/evidence/implementation.md:54-88`; `cd8a96/tasks.md:6-8`; `cd8a96/state.json:21`):

1. `python3 scripts/grok_approve.py production --reason "publish v2.0.5 tag and GitHub Release"` → id `3c0ab95c9f72`, 15 min, `2026-08-16T16:09:55+00:00`–`16:24:55+00:00`
2. matching `external-write` token `5fd6bdb8db43`
3. `git push origin v2.0.5` (exit 0)
4. `gh release create v2.0.5` with existing zip + sha256 + `dist/RELEASE-NOTES.md` (exit 0)
5. Latest became `v2.0.5` at `2026-08-16T16:10:10Z`

`cd8a96/evidence/human-approval.md` recorded `production_action_approval` from prior «да» / «смерджи все» plus this «делай». `cd8a96/evidence/code-review.md` **PASS** on the landed advertisement. Independent confirm: Latest `v2.0.5`, digest `b80e6310…`, `v2.0.4` intact.

That exception was scoped: push existing tag + create Release. No rebuild, no retag, no `git push origin main`, no force-push. `write_agent` was `general_implementer`.

## 3. Print-vs-execute contradiction

**Yes. It is already named. The 2.0.6 runbook did not repeal it; it restated print-only after the 2.0.5 exception.**

| Layer | Print | Execute |
| --- | --- | --- |
| `publish-v2.0.6.md` | Agents must not run tag / push / `gh` | — |
| `publish-v2.0.5.md` (still on disk after publish) | Same agent sentence | Title: “User-authorized publish” |
| Adaptive-delivery / release-readiness / README | Humans own printed commands | — |
| `AGENTS.md:104` | Routine publish without a short-lived token is banned | Publish **with** short-lived explicit approval is not that ban |
| e584b3 (2.0.4) | Contemporaneous runbook said print | `state.json` “push and gh release executed” after «я разрешаю»; later analysis called it mixed precedent |
| ad4090 | Added the 2.0.5 agent-must-not-run sentence; analysis said do not repeat e584b3 | Hook may have allowed a push/`gh` attempt; auth failed; Latest stayed 2.0.4 |
| cd8a96 analysis | Print only; «делай» is not this route’s `production_action_approval` | — |
| cd8a96 brief / architecture / implementation | Default is print-only | **Authorized exception this change only**; they ran approve + push tag + `gh release create` |
| ec0388 | Wrote print-only `publish-v2.0.6.md`; cd8a96 exception **does not transfer** | Later prompt that **names** release + live `grok_approve` + ready change is the on-ramp |

Bounded ruling already on file for 2.0.5: mixed 2.0.4 chat precedent is source of truth #6; standing runbook wins **unless** the user re-authorizes a last mile and the change records an exception. cd8a96 was that exception. ec0388 then put print-only back in the 2.0.6 runbook.

This 864726 package already writes the execute sequence (`architecture.md:5`: approve → tag existing commit → push main → push tag → `gh release create`) and claims both human gates (`evidence/human-approval.md`). `write_agent` is **null**. Adaptive-delivery still says do not publish as closure.

## 4. Is this user prompt enough production approval?

User text (route `task`): GitHub still shows Latest **v2.0.5** (6 releases) and «угораешь блять? **делай всё полностью вместе с релизом**».

**Split the two meanings of “approval,” same split as `cd8a96/evidence/analysis-docs_researcher.md:248-289`.**

### Verbal / markdown — **yes, this prompt authorizes the 2.0.6 publish outcome**

| Check | This prompt | Cite |
| --- | --- | --- |
| Names the release | «вместе **с релизом**» | route `task`; `864726/brief.md:3`; `864726/release.md:7` |
| Demands the full last mile, not another assemble | «делай **всё полностью**» while Latest is still 2.0.5 | same; user is looking at the Releases page |
| Matches ec0388 on-ramp | “A later user prompt that names push/release” | `ec0388/evidence/analysis-task_analyst.md:210` |
| Stronger than cd8a96 «делай» | 2.0.5 last mile was just «делай» after stale Latest 2.0.4 | `cd8a96/brief.md:15,47`; `cd8a96/route.json:61` |
| SoT #1 | User-approved scope outranks the print-only default | `AGENTS.md:19-21`; `cd8a96/brief.md:47` |
| Named gates on this route | Both recorded granted 2026-08-16 | `864726/route.json:22-25`; `864726/evidence/human-approval.md:3-7`; `864726/tasks.md:4` |
| Prior 2.0.5 «делай» | Does **not** transfer (ec0388). This is a **new** go for 2.0.6. | `ec0388/evidence/analysis-task_analyst.md:201` |

Authorized outcome (already written in this package): GitHub Latest is `v2.0.6` on `549f29d` with the existing zip + sha256 (`864726/brief.md:7`; `864726/requirements.md`). Do not force-push. Do not touch `v2.0.5`. Do not rebuild. Do not print secrets.

That is the same shape as cd8a96: user sees a stale Latest badge and orders the last mile done. Print-only already left Latest on 2.0.5 after a working local 2.0.6 (`CHANGELOG.md:5`; `ec0388/evidence/implementation.md:93`).

### Live machine token — **no, this prompt is not `has_valid_approval`**

| Token | Status |
| --- | --- |
| cd8a96 `3c0ab95c9f72` production | Expired `2026-08-16T16:24:55+00:00` |
| cd8a96 `5fd6bdb8db43` external-write | Same expiry |
| `approvals.json` now | only those two dead rows |
| `864726/tasks.md:5` | `grok_approve production` still unchecked |
| `864726/evidence/human-approval.md:9` | Claims a machine token will be / was recorded **before** the gated commands |

Markdown approval is not a live token. Default TTL is 15 minutes. A human running git/gh **outside** the hook does not need `grok_approve`. An agent-side `git push` / `gh release create` **does** (`cd8a96/evidence/analysis-docs_researcher.md:280-283`; `AGENTS.md:104`). `grok_deploy.py --record` also needs a live production token (`deploy.py:74-75`). Dry-run print needs the change `ready`/`released` plus empty evidence gaps (`deploy.py:55-63`); this change is still `draft`.

### What this prompt does **not** do by itself

- It does not repeal `publish-v2.0.6.md:5`. The runbook still says humans own the argv.
- It does not make `write_agent` appear. This route’s write owner is **null** (`864726/route.json:67`; active-route same). cd8a96 could execute because `general_implementer` owned that last mile.
- It does not authorize force-push, retag of `v2.0.5`, rebuild of the zip, MCP `create_release`, or reading `.env`.
- It does not let **this** agent (docs_researcher) push, tag, or release.

## 5. Bottom line

1. **Required advertisement:** existing `packages/adaptive-grok-build-pro-v2.0.6.zip` + `.sha256` (digest `b34af685…`), notes `dist/RELEASE-NOTES.md` (CHANGELOG 2.0.6 verbatim), annotated tag `v2.0.6` → `549f29d`, then `git push origin main`, `git push origin v2.0.6`, `gh release create`. Do not rebuild. Leave `v2.0.5` up.

2. **Print-vs-execute contradiction is real and already named.** The 2.0.6 runbook, adaptive-delivery, and CHANGELOG say print-only / human last mile. AGENTS.md allows production mutation **with** a short-lived explicit approval. cd8a96 analysis said print; the package then recorded a **this-change-only** exception after «делай» and **did** `grok_approve` + `git push origin v2.0.5` + `gh release create`. ec0388 wrote print-only back and said that exception does not transfer.

3. **This prompt authorizes the outcome.** «делай всё полностью вместе с релизом» while Latest is still 2.0.5 is verbal `production_action_approval` for GitHub Latest `v2.0.6` on the already-built `549f29d` zip. It is the later “names release” prompt ec0388 required. It is **not** a live 15-minute `grok_approve` token. Agent-side gated commands still need a fresh `python3 scripts/grok_approve.py production` in this session, the same gate cd8a96 used before it executed.
