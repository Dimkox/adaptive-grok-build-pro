# Requirements

- [ ] `git rev-parse HEAD` is `549f29da1c4ff44ba44d8388c294fd5dd29bfd81`
- [ ] Annotated tag `v2.0.6` peels to that SHA
- [ ] `origin/main` is that SHA
- [ ] Remote tag `v2.0.6` exists
- [ ] GitHub Latest is `v2.0.6` with zip digest `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`
- [ ] Release `v2.0.5` still exists
