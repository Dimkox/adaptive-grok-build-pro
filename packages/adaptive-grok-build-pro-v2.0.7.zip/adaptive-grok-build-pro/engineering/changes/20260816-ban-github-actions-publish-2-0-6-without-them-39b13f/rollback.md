# Rollback plan — Ban GitHub Actions; publish 2.0.6 without them

## Trigger conditions

## Application rollback

## Data recovery / forward-fix

## Verification after rollback
