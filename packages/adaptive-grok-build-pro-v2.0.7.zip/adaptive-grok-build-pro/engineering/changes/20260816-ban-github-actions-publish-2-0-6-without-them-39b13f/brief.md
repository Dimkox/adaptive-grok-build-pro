# Ban GitHub Actions; publish 2.0.6 without them

Change ID: `20260816-ban-github-actions-publish-2-0-6-without-them-39b13f`
Created: 2026-08-16T17:50:47+00:00
Risk: low
Complexity: standard
Domains: generic

## Problem

The user sent a message while you were working:
<user_query>
НИКОГДА НЕ ИСПОЛЬЗУЕМ ЕБАНЫЕ GITHUB ACTOIONS!!!!!!!
</user_query>
Make sure to complete any unfinished tasks from previous turns.

## Outcome

Describe the observable user or business result.

## Scope

### In scope

- 

### Out of scope

- 

## Constraints

- Backward compatibility:
- Data/privacy:
- Performance:
- Operational:
