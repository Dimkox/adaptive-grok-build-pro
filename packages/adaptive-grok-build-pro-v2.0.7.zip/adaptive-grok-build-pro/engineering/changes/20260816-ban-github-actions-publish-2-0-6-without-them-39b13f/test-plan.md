# Test plan — Ban GitHub Actions; publish 2.0.6 without them

## Risk-based scenarios

| Priority | Scenario | Evidence |
| --- | --- | --- |
| P0 | | |
| P1 | | |

## Automated checks

- Unit:
- Integration:
- Contract:
- E2E:
- Static analysis:

## Manual checks

- 
