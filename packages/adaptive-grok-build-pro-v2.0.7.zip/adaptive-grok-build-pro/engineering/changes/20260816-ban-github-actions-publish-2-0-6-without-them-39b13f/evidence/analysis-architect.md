# Analysis — architect

Change: `20260816-ban-github-actions-publish-2-0-6-without-them-39b13f`  
Route: `39b13fbab936` · write=`general_implementer` · reviews=`code_reviewer`+`test_reviewer`  
Risk: low · complexity: standard · human_gates: none  
Supersedes (unpublished 2.0.6 only): Dependabot-for-Actions and hosted workflow from `ec0388`.  
Does **not** tag `549f29d` (that commit still ships GitHub Actions).

Read-only. No application-code edits. No `.env`. No push / tag / merge / deploy.

Narrow question: how to ban GitHub Actions **without adding another CI vendor**, stay on unpublished 2.0.6, and leave a rebuild + human last mile.

---

## Ruling (one screen)

**Delete the Actions surface. Refuse `--with-ci`. Local `grok_verify --mode pr` is the only gate. Keep VERSION 2.0.6. Rebuild the zip. Do not publish in this write.**

User: «НИКОГДА НЕ ИСПОЛЬЗУЕМ ЕБАНЫЕ GITHUB ACTOIONS». That overrides the unpublished 2.0.6 Dependabot + workflow contour. It does **not** authorize Woodpecker / GitLab / Forgejo / Drone / Jenkins, or any other vendor template.

| In | Out |
| --- | --- |
| Delete `.github/workflows/adaptive-grok.yml` and `.github/dependabot.yml` | Another CI vendor, `pyproject.toml`, Codecov |
| Delete `.grok-stack/templates/ci/github-actions.yml`; README says never GHA; local `grok_verify` only | Keep the template “for optional use”; vendor list in that README |
| `--with-ci` → `SystemExit` (“GitHub Actions are forbidden”); no copy, even with `--force` / `--dry-run` | Remove the flag (old scripts must fail loudly); silent skip |
| Drop byte-identical workflow lock; add refuse + no-workflow tests | Keep `test_root_workflow_equals_template` |
| `decisions.md`: never GitHub Actions | Policy hook that deletes consumer `.github/` |
| Amend unpublished `## 2.0.6`; rebuild `packages/` zip | Bump to 2.0.7; retag 2.0.5; tag `549f29d` |
| Implementer: files + tests + zip | Implementer: `git tag` / `git push` / `gh release` |

Last mile remains `python3 scripts/grok_deploy.py`. Controller may run printed commands **after** this change is on the tree (prior `864726` production approval). **Retarget the tag to the post-ban commit, not `549f29d`.**

---

## 1. Current surface (facts)

| Path | Role today |
| --- | --- |
| `.github/workflows/adaptive-grok.yml` | This-repo GHA: `verify` (pip-install ruff/bandit/coverage + unittest + doctor + `grok_verify --mode pr`) and conditional `package` (artifact upload; no publish) |
| `.grok-stack/templates/ci/github-actions.yml` | Byte-identical template. `install_into --with-ci` copies it to consumers as `.github/workflows/adaptive-grok.yml` |
| `.grok-stack/templates/ci/README.md` | Documents optional GHA + a self-host vendor list (Woodpecker, Forgejo, GitLab, Drone, Jenkins) |
| `.github/dependabot.yml` | `package-ecosystem: github-actions` weekly |
| `scripts/install_into.py` L119–127, L188 | `--with-ci` copies the template; help says “Install a generic GitHub Actions verification workflow.” |
| `tests/test_deploy.py` | `test_root_workflow_equals_template`, `test_template_package_job_is_conditional_and_has_no_publish`, `test_workflow_installs_quality_tools` |
| `tests/test_installer.py` | `test_with_ci_preserves_unrelated_workflow` asserts `adaptive-grok.yml` is created |

Load-bearing installer fact: `MANAGED_DIRS` includes `.grok-stack`, so **every** `install_into` (even without `--with-ci`) copies `.grok-stack/templates/ci/github-actions.yml` into the consumer. Deleting only the root workflow is not enough. The template YAML must go.

`included_files()` packages `.github/**` when those files exist. Today `MANIFEST.sha256` lists the workflow and Dependabot. After delete + `package_stack.py`, those members disappear. That is the desired zip.

`VERSION` is `2.0.6`. Local tip is unpublished (`origin/main` is still 2.0.5; no `v2.0.6` tag). `864726` approved tagging `549f29d`. That approval is for a **release act**, not for shipping Actions after the user banned them.

Historical `CHANGELOG` 2.0.4 line about GHA stays. 2.0.4 already shipped.

---

## 2. Exact write for `general_implementer`

One vertical. One write owner. Tests first.

### 2.1 Delete (git rm)

```
.github/workflows/adaptive-grok.yml
.github/dependabot.yml
.grok-stack/templates/ci/github-actions.yml
```

Do not leave `.gitkeep` under `.github/`. Empty dirs are untracked; that is fine. Do not add a replacement `*.yml`.

### 2.2 Replace `.grok-stack/templates/ci/README.md`

Keep the directory. Replace the file so it says **never GitHub Actions** and points only at local verify. **No vendor list.** Suggested body (writer may tighten wording, not the meaning):

```markdown
# CI templates

Never GitHub Actions. This product does not ship a workflow and will not copy one.

The only supported verification gate is local:

```bash
make doctor
make verify
python scripts/grok_verify.py --mode pr
```
```

Delete the current “Optional GitHub Actions workflow” paragraph and the “If you self-host CI (Woodpecker, …)” list. That list is another CI vendor.

Root `README.md` already documents local `make doctor` / `make verify` and does not advertise `--with-ci`. Leave it unless a GHA install line appears (it does not today). GitHub CLI for **Releases** stays — that is not Actions.

### 2.3 `--with-ci` refuses; do not copy

In `scripts/install_into.py` `install()`:

- If `with_ci` is true, raise `SystemExit` **before any copy**, including before the managed-file loop.
- `--force` does not override.
- `--dry-run` does not print `COPY` / `WOULD COPY` and does not create `.github/`.
- Do not read or copy `github-actions.yml`. After 2.1 that file is gone; the refuse path must not depend on it existing.

Keep the argparse flag so existing scripts get a clear error instead of “unrecognized arguments”. Change help to state the flag is rejected.

**Stable message** (tests assert a substring):

```
GitHub Actions are forbidden. Do not copy a workflow. Use local python scripts/grok_verify.py --mode pr.
```

`SystemExit` may carry that string (`raise SystemExit(msg)`). Do not create `.github/workflows/adaptive-grok.yml` on the target. Do not delete a consumer’s existing unrelated workflows (the function never reaches copy). No uninstall / `--remove-ci` path.

Default install (`with_ci=False`) is unchanged except it no longer ships the deleted template YAML.

### 2.4 Tests

**Remove** (they lock the banned files):

- `tests/test_deploy.py::test_root_workflow_equals_template`
- `tests/test_deploy.py::test_template_package_job_is_conditional_and_has_no_publish`
- `tests/test_deploy.py::test_workflow_installs_quality_tools`

**Replace** `tests/test_installer.py::test_with_ci_preserves_unrelated_workflow` with a refuse test. Call `MODULE.install(..., with_ci=True)` (same helper style as today). Assert:

1. `SystemExit` is raised.
2. `str(cm.exception)` contains `GitHub Actions` and `forbidden`.
3. Target has no `.github/workflows/adaptive-grok.yml`.
4. Also with `force=True` and with `dry_run=True` — same refuse, no write. One test with a small loop is enough; do not invent a matrix.

**Add** on this repo (keep it in `test_deploy.py` next to the removed lock, or `test_structure.py` — either is fine; do not add a new test module):

- No `.github/workflows/*.yml` (directory missing **or** empty).
- No `.github/dependabot.yml`.
- No `.grok-stack/templates/ci/github-actions.yml`.

Do not add a zip-member scan unless it is a one-liner on an existing package test. After delete, `included_files()` cannot pack what is gone. Rebuild is an implementer step, not a new packager feature.

Leave all other installer tests alone. `test_prepare_sources_do_not_execute_publish_commands` stays.

### 2.5 `engineering/decisions.md`

New **top** entry, ≤3 sentences:

```
## 2026-08-16 — Never GitHub Actions

Do not add, copy, or restore `.github/workflows` or Dependabot for Actions. `install_into --with-ci` must SystemExit; local `python scripts/grok_verify.py --mode pr` is the verification gate. Do not replace Actions with another hosted CI vendor.
```

This is the durable product rule. It supersedes the unpublished 2.0.6 Dependabot-for-GHA choice. Do not rewrite older change-package history (`ec0388`, `99b743`, `ef7b14`).

### 2.6 Stay on unpublished 2.0.6

- `VERSION` remains `2.0.6`. No 2.0.7.
- Amend `CHANGELOG.md` section `## 2.0.6 — 2026-08-16` in place:
  - Drop “CI fail-closed after `pip install`” from the Ruff bullet (that phrase was the GHA job).
  - Replace “Dependabot for GitHub Actions only” with: GitHub Actions are forbidden; workflow, Dependabot, and `--with-ci` copy are removed; local `grok_verify --mode pr` is the gate.
  - Keep Ruff/Bandit/coverage/semgrep-consumer bullets.
  - Keep “2.0.5 remains the previous published GitHub Latest until a human last mile.”
- Mirror the same 2.0.6 section in `dist/RELEASE-NOTES.md` (last mile uses `--notes-file dist/RELEASE-NOTES.md`).
- Do **not** edit the shipped `## 2.0.4` GHA bullet.

Then rebuild:

```bash
python3 scripts/package_stack.py
cp dist/adaptive-grok-build-pro-v2.0.6.zip* packages/
```

`package_stack.py` regenerates `MANIFEST.sha256`. Expected: workflow and Dependabot lines gone; `templates/ci/README.md` hash changes; `VERSION` inside the zip is still `2.0.6`. Do not touch `packages/adaptive-grok-build-pro-v2.0.5.zip*`.

### 2.7 Change-package docs (this folder)

Skeleton `brief.md` / `architecture.md` / `requirements.md` / `tasks.md` / `test-plan.md` / `release.md` / `rollback.md` should be filled from this ruling when the write owner lands the vertical. Do not invent extra scope there.

---

## 3. Implementation order

1. Land the failing tests (remove lock tests; add refuse + absence).
2. Delete the three YAML files; rewrite `templates/ci/README.md`.
3. Make `--with-ci` `SystemExit`; update `--help`.
4. `decisions.md` + CHANGELOG 2.0.6 + `dist/RELEASE-NOTES.md`.
5. `python3 -m unittest discover -s tests` then `python3 scripts/grok_verify.py --mode pr`.
6. Rebuild zip → `packages/`.
7. Independent `code_reviewer` + `test_reviewer` on the final tree.
8. Bind receipts after the last change-package write (`ready` first).

Do not run `git tag`, `git push`, or `gh release` in this write.

---

## 4. Last mile (controller / human — after this change)

Prior `864726` approval authorized a v2.0.6 GitHub Release. That approval is still the last-mile grant. The **object** of the tag is not.

| Do | Do not |
| --- | --- |
| Tag the commit that contains this ban + rebuilt zip | Tag `549f29d` (still has Actions + Dependabot) |
| `git push origin main` then `git push origin v2.0.6` | Force-push; retag `v2.0.5` |
| `gh release create v2.0.6` with the **new** `packages/` zip + sha256 and updated `dist/RELEASE-NOTES.md` | Publish the old `b34af685…` zip |

Print-only path: `python3 scripts/grok_deploy.py` (same command list as `engineering/runbooks/publish-v2.0.6.md`). Humans / controller own the gated commands. `grok_deploy.py` itself is unchanged — GitHub **Release** is not GitHub **Actions**.

---

## 5. Compatibility and residuals

- **Consumers** that already have `.github/workflows/adaptive-grok.yml` keep it. This installer never deletes unrelated files. No migration job.
- **Scripts** that pass `--with-ci` start failing. That is the contract.
- **Local quality** (ruff / bandit / coverage / unittest) is unchanged. Skip-if-missing locally stays. There is no hosted fail-closed pip-install anymore; that is intended.
- **2.0.5** published tree is untouched.
- Empty `.github/` after delete is not a defect.

---

## 6. Out of scope (stop if a later prompt tries these)

- Any replacement workflow (`woodpecker.yml`, `.gitlab-ci.yml`, Forgejo, Drone, Jenkinsfile, Circle, Buildkite).
- Dependabot `pip` / `requirements-ci.txt` / `pyproject.toml`.
- Changing `verification.py` check names or skip rules.
- Policy/PreToolUse block on creating `.github/workflows` (nice later, not this slice).
- Removing the `--with-ci` flag.
- Rewriting historical change packages or shipped 2.0.4 notes.
- Implementer-owned tag / push / `gh release`.

---

## 7. Rollback

Restore the three deleted files from the pre-change commit, revert `install_into.py` + tests + `decisions.md` + 2.0.6 notes, rebuild the zip. If a `v2.0.6` tag/release already exists on the post-ban commit, humans delete the GitHub release and the tag (`engineering/runbooks/publish-v2.0.6.md`). No data migration.

---

## 8. Acceptance (writer and reviewers)

- [ ] This repo has no `.github/workflows/*.yml` and no `.github/dependabot.yml`
- [ ] `.grok-stack/templates/ci/github-actions.yml` is gone; README says never GHA; local `grok_verify` only
- [ ] `install(..., with_ci=True)` raises `SystemExit` with “GitHub Actions” / “forbidden” and writes no workflow (`force` and `dry_run` included)
- [ ] Byte-identical workflow lock tests are gone; refuse + absence tests exist and pass
- [ ] `engineering/decisions.md` records never GitHub Actions
- [ ] `VERSION` is `2.0.6`; CHANGELOG / RELEASE-NOTES amended, not bumped
- [ ] `packages/adaptive-grok-build-pro-v2.0.6.zip` rebuilt; no workflow members; 2.0.5 zip unchanged
- [ ] `python3 scripts/grok_verify.py --mode pr` PASS
- [ ] No `git tag` / `git push` / `gh release` in the implementer diff
