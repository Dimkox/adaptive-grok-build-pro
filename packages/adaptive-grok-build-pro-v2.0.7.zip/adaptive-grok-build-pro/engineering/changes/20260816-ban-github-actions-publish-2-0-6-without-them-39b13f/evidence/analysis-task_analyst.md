# Analysis — task_analyst

Change: `20260816-ban-github-actions-publish-2-0-6-without-them-39b13f`  
Route: `39b13fbab936` · intent=`feature` · risk=`low` · write=`general_implementer`  
Reviews after implementation: `code_reviewer` + `test_reviewer`  
Evidence kinds: `verification`, `code_review`, `test_review`  
Human gates on this route: none  
Narrow question: **What does «НИКОГДА НЕ ИСПОЛЬЗУЕМ GITHUB ACTIONS» plus unfinished 2.0.6 publish mean as acceptance, and what is out of scope?**

Read-only. No application-code edits. No `.env`. No push / tag / merge / deploy from this agent.

---

## Ruling (one screen)

«НИКОГДА НЕ ИСПОЛЬЗУЕМ ЕБАНЫЕ GITHUB ACTIONS» plus «complete unfinished 2.0.6 publish» is **two sequenced outcomes on the same unpublished 2.0.6 identity**:

1. **Ban GitHub Actions on this product tree and installer.**
2. **Rebuild the 2.0.6 zip after that ban.**
3. **Then last-mile GitHub Release `v2.0.6`.**

GitHub **Release** (`gh release create`, git remotes, `grok_deploy` printed commands) is **not** GitHub **Actions**. The prior user line «делай всё полностью вместе с релизом» still authorizes the Release. It does **not** authorize workflows, Dependabot `github-actions`, or `--with-ci` copying YAML.

| In | Out |
| --- | --- |
| Delete `.github/workflows/` (the only file today is `adaptive-grok.yml`) | Invent GitLab CI / Woodpecker / Forgejo / Jenkins YAML |
| Delete Dependabot `package-ecosystem: github-actions` (today `.github/dependabot.yml`) | Disable `gh`, remotes, `git push`, `gh release create` |
| `--with-ci` must **error or refuse** and must **not** write a workflow | Uninstall GHA from already-installed consumer repos |
| Tests lock the ban (invert the four keep-GHA tests) | Bump VERSION to 2.0.7 |
| Local `grok_verify --mode pr` remains the quality source of truth | Retag / rebuild / force-push **v2.0.5** |
| Keep `VERSION` = `2.0.6` (still unpublished) | Tag existing `549f29d` / ship zip digest `b34af685…` (superseded) |
| Rebuild `dist/` + `packages/` 2.0.6 zip **after** the ban | `pyproject.toml` / `requirements.txt` / `setup.py` |
| Then last mile: annotated tag + push + `gh release create` on the **post-ban** commit | Use Actions to publish; add a publish job |

Route `864726` (“tag `549f29d`, do not rebuild”) is **superseded**. That tree still ships Actions + Actions-Dependabot. Publishing it would violate the new user rule.

This agent does **not** execute last mile. Write owner implements ban + failing tests first + rebuild. Last mile is after `ready` + live `grok_approve.py production`.

---

## Current facts (do not treat as done)

| Item | Today |
| --- | --- |
| `VERSION` | `2.0.6` — **keep** |
| Local `HEAD` / `main` | `549f29da1c4ff44ba44d8388c294fd5dd29bfd81` “Release v2.0.6: ruff, bandit, coverage, dependabot” |
| `origin/main` | `7c0ae7573535ddd0cfe3800f81278991ced81584` (v2.0.5) |
| Local / origin tags | `v2.0.0`…`v2.0.5` only. **No `v2.0.6`.** |
| GitHub Latest | **v2.0.5** @ `7c0ae75` (16 Aug 16:10). `/releases/tag/v2.0.6` is 404. |
| Tracked 2.0.6 zip | `packages/adaptive-grok-build-pro-v2.0.6.zip` digest `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610` — **stale after ban** |
| `.github/workflows/adaptive-grok.yml` | **Present.** Verify + conditional package + `upload-artifact`. No `gh release`. |
| `.grok-stack/templates/ci/github-actions.yml` | **Present.** Byte-identical to the workflow. |
| `.github/dependabot.yml` | **Present.** `package-ecosystem: github-actions` weekly only. |
| `install_into --with-ci` | Copies the template → target `.github/workflows/adaptive-grok.yml`. |
| Tests that **require** GHA | `test_root_workflow_equals_template`, `test_template_package_job_is_conditional_and_has_no_publish`, `test_workflow_installs_quality_tools`, `test_with_ci_preserves_unrelated_workflow` |
| Local verify | `make verify` → `python3 scripts/grok_verify.py --mode pr`. Ruff/Bandit/Coverage skip-if-missing. **This stays.** |
| `grok_deploy` | Print-only: `package_stack`, copy to `packages/`, `git tag`, `git push`, `gh release create`. Does not import `subprocess`. **Keep.** |
| Live production token | **None.** `approvals.json` only has expired v2.0.5 tokens. |
| Grok hooks | Not GitHub Actions. Keep `.grok/hooks/*` and root shims. |
| `pyproject.toml` / `requirements.txt` / `setup.py` | Absent. Must stay absent. |

`.github/` contains only the workflow and Dependabot. After the ban it should have **neither** file; an empty `.github/` need not be kept.

---

## 1. Acceptance

A done 39b13f tree is: **no GHA product surface**, **tests lock that**, **2.0.6 identity unchanged**, **zip rebuilt**, **local verify green**. GitHub Latest `v2.0.6` is the last mile after that, not a GHA job.

### 1.1 Ban GitHub Actions (P0)

- [ ] This repo has **no** `.github/workflows/` directory and **no** workflow YAML.
- [ ] This repo has **no** Dependabot `package-ecosystem: github-actions`. Prefer deleting `.github/dependabot.yml` entirely. Do not add a `pip` ecosystem as a consolation prize.
- [ ] `.grok-stack/templates/ci/github-actions.yml` is **gone**. Shipping that file in the zip would still distribute Actions. Template README may remain only to say: local `grok_verify` is the source of truth; **do not** add a GitLab (or other vendor) replacement template.
- [ ] `scripts/install_into.py --with-ci` **errors or refuses** (`SystemExit` with a clear message). It must **not** create `.github/workflows/adaptive-grok.yml` or copy any Actions YAML. Recommended: keep the flag so callers get a product error, not an argparse mystery. Either interpretation satisfies “error or refuse”.
- [ ] Default install (no `--with-ci`) still does not touch consumer `.github/`. Do **not** delete a consumer’s existing workflows on reinstall.
- [ ] Default install still copies hooks, scripts, `.grok-stack` (minus runtime state), and does not start requiring hosted CI.
- [ ] CHANGELOG `## 2.0.6` (unpublished — **may rewrite**) drops “Dependabot for GitHub Actions only” and “CI fail-closed after `pip install`”. It states: Actions banned; `--with-ci` refuses; local `grok_verify` is the gate; GitHub Release is not Actions; 2.0.5 remains the previous published Latest until last mile.
- [ ] Published `## 2.0.4` / `## 2.0.5` history is **not rewritten** (those ships really had optional Actions).
- [ ] `dist/RELEASE-NOTES.md` matches the rewritten 2.0.6 section.
- [ ] README / QUICKSTART stay local-verify first (`make doctor` / `make verify`). Do not document a hosted Actions path. README already omits `--with-ci`; keep it that way or say the flag is refused.
- [ ] Grok lifecycle hooks are unchanged and are not classified as GitHub Actions.

### 1.2 Tests lock the ban (P0, failing first)

Invert or replace the four tests that currently **require** Actions. Add an absence lock. Do this **before** deleting files so the first run is red.

- [ ] Given this product tree, `.github/workflows` does not exist (file or directory).
- [ ] Given this product tree, `.grok-stack/templates/ci/github-actions.yml` does not exist.
- [ ] Given this product tree, there is no Dependabot config with `package-ecosystem: github-actions`.
- [ ] Given `install(..., with_ci=True)` (or CLI `--with-ci`), the call **raises `SystemExit`** (or equivalent refuse), **no** `adaptive-grok.yml` is written, and an unrelated existing workflow file is left untouched.
- [ ] Default `install(..., with_ci=False)` still does not create `.github/workflows`.
- [ ] `test_prepare_sources_do_not_execute_publish_commands` still forbids `subprocess` / `os.system` in `deploy.py` and `grok_deploy.py`.
- [ ] `prepare_deploy` dry-run **still prints** `git tag`, `git push origin`, and `gh release create` for `VERSION` 2.0.6. Ban Actions, not Release.

Suggested homes: `tests/test_deploy.py` (replace the three workflow tests), `tests/test_installer.py` (replace `test_with_ci_preserves_unrelated_workflow`), optional `tests/test_structure.py` absence lock.

### 1.3 Local verify remains source of truth (P0)

- [ ] `python scripts/grok_verify.py --mode pr` is the gate. `make verify` still aliases it.
- [ ] Ruff / Bandit / Coverage stay first-class `grok_verify` checks: **skip-if-missing locally**. Removing Actions `pip install` is correct; do **not** invent a replacement hosted fail-closed job.
- [ ] Marker-less tree + `tests/test*.py` still emits `python-unittest`.
- [ ] `detect_repo` on this tree stays `kind=generic`. No packaging markers.
- [ ] Runtime `adaptive_grok` stays stdlib-only. Doctor has no fail items on the ship tree.
- [ ] Quality-profile JSON remains documentary; do not rewrite `verify()` to honor `required_checks`.

### 1.4 Identity 2.0.6 (unpublished) + rebuild zip

- [ ] `VERSION` is exactly `2.0.6`. Do **not** open 2.0.7.
- [ ] README H1 stays `Adaptive Grok Build Pro v2.0.6`.
- [ ] `packages/README.md` already has a 2.0.6 row. Keep it. After rebuild the sibling `.sha256` **changes**.
- [ ] After the ban lands: `python3 scripts/package_stack.py` then `cp dist/adaptive-grok-build-pro-v2.0.6.zip* packages/`.
- [ ] New zip digest **≠** `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610`.
- [ ] Zip contains `VERSION` 2.0.6, `MANIFEST.sha256`, prefix `adaptive-grok-build-pro/`.
- [ ] Zip does **not** contain `.github/workflows/*`, Dependabot `github-actions`, or `templates/ci/github-actions.yml`.
- [ ] Zip still excludes `.grok-stack/runtime` state (except `.gitkeep`), `.env`, private keys.
- [ ] `v2.0.5` tag, Release, and `packages/adaptive-grok-build-pro-v2.0.5.zip` are **untouched**.

### 1.5 Last mile (authorized, after 1.1–1.4, not this agent)

GitHub Release is **not** GitHub Actions. Prior «делай всё полностью вместе с релизом» plus this prompt’s “complete unfinished 2.0.6 publish” still authorize it **after** the ban and the rebuilt zip.

These boxes are **not** required to call the *ban* done. They are the unfinished publish, sequenced last.

- [ ] Change is `ready`; `grok_verify --mode pr` plus `code_review` + `test_review` receipts bind the **final post-ban** fingerprint (`ready` before recording — `decisions.md` 2026-08-14).
- [ ] `python3 scripts/grok_deploy.py` prints the commands. Humans / a production-approved shell own execution:

```bash
python3 scripts/package_stack.py
cp dist/adaptive-grok-build-pro-v2.0.6.zip* packages/
git tag -a v2.0.6 -m "v2.0.6"
git push origin main
git push origin v2.0.6
gh release create v2.0.6 packages/adaptive-grok-build-pro-v2.0.6.zip packages/adaptive-grok-build-pro-v2.0.6.zip.sha256 --notes-file dist/RELEASE-NOTES.md
```

- [ ] Tag peels to the **post-ban** commit, **not** `549f29d`.
- [ ] GitHub Latest is `v2.0.6` with the **new** zip digest. Release `v2.0.5` still exists.
- [ ] No Actions workflow runs as part of publish. No `workflow_dispatch` publish job.

`864726` pins (`HEAD == 549f29d`, digest `b34af685…`) are **void**. Keep the *intent* (publish 2.0.6). Drop the *object* (that SHA / that zip).

Live `approvals.json` has **no** current production token. Adaptive-delivery close still forbids publish as part of analysis/closure. Policy still blocks `git push` and `gh release create` without `python scripts/grok_approve.py production --reason "..."`. Intent authorization ≠ a live machine token.

---

## 2. Non-goals

- Do **not** add `.gitlab-ci.yml`, Woodpecker, Forgejo Actions, Drone, Jenkins, Buildkite, or any other hosted-CI template “instead”.
- Do **not** disable `gh`, `git remote`, `git push`, or `gh release create`. Those are Release, not Actions.
- Do **not** strip `gh release create` from `grok_deploy` printed commands.
- Do **not** bump VERSION off 2.0.6.
- Do **not** retag, rebuild, or force-push `v2.0.5`.
- Do **not** ship the current `549f29d` / `b34af685…` artifacts as Latest.
- Do **not** add `pyproject.toml`, `requirements.txt`, or `setup.py`.
- Do **not** make Ruff/Bandit/Coverage required toolchain tools.
- Do **not** rewrite `verify()` to honor profile `required_checks`.
- Do **not** scan consumer repos or delete their existing workflows.
- Do **not** treat Grok hooks (`.grok/hooks`, root shims) as GitHub Actions.
- Do **not** add Dependabot `pip`.
- Do **not** open 2.1.0.
- Do **not** push / tag / `gh release` from this analysis agent.

---

## 3. Test requirements (failing test first)

Add / invert tests **before** deleting Actions files.

### P0 — Absence

- [ ] Product tree: `not (ROOT / '.github/workflows').exists()`.
- [ ] Product tree: `not (ROOT / '.grok-stack/templates/ci/github-actions.yml').exists()`.
- [ ] Product tree: no file asserts `package-ecosystem: github-actions` (deleted Dependabot file is enough).

### P0 — Installer refuse

- [ ] `with_ci=True` raises `SystemExit` (or CLI `--with-ci` exits non-zero) and does not create `adaptive-grok.yml`.
- [ ] Pre-existing unrelated `.github/workflows/existing.yml` is unchanged.
- [ ] `with_ci=False` still installs hooks/scripts and still does not create `.github/workflows`.

### P0 — Release path intact

- [ ] `prepare_deploy` dry-run still lists `gh release create v2.0.6` and `git push origin`.
- [ ] Deploy sources still do not execute those commands.

### P0 — Local verify

- [ ] Existing marker-less unittest / ruff-skip / bandit-skip / coverage contracts stay green.
- [ ] After implementation: `python scripts/grok_verify.py --mode pr` on the product tree.

Then independent `code_review` + `test_review` on the **final** tree. A failing check returns to `general_implementer`.

---

## 4. Does this prompt authorize `git tag` / `gh release`?

**Yes — after the ban and the rebuilt zip. Not as GitHub Actions. Not from this agent. Not against `549f29d`.**

| Phrase | Meaning here |
| --- | --- |
| «НИКОГДА НЕ ИСПОЛЬЗУЕМ GITHUB ACTIONS» | No workflows, no Actions Dependabot, no `--with-ci` copy. Absolute for this product. |
| «complete unfinished 2.0.6 publish» | Finish the last mile that `864726` started, **on the post-ban tree**. |
| Prior «делай всё полностью вместе с релизом» | Authorizes GitHub **Release** `v2.0.6`. Remains valid. Does not authorize Actions. |
| Adaptive-delivery close | Analysis/verify/review do not publish. Last mile is `grok_deploy`; execution needs a live production approval. |
| Route `human_gates` | `[]`. Intent is already recorded; machine token is not live. |
| `864726` SHA/digest pins | Superseded by the ban. |

Do **not** run last-mile commands until 1.1–1.4 are in the tree and receipts bind that tree.

---

## Constraints that survive into implementation

1. GitHub Actions ≠ GitHub Release. Ban the first. Keep the second.
2. `VERSION` stays `2.0.6`. Rebuild the zip after the ban. Then last mile.
3. `grok_verify --mode pr` is the only quality bar. No replacement hosted CI.
4. Failing tests first; invert the four keep-GHA tests.
5. Delete the template YAML, not only `.github/workflows/`.
6. `--with-ci` refuse; do not silently ignore and copy.
7. No `pyproject.toml` / `requirements.txt` / `setup.py`.
8. Do not touch v2.0.5.
9. Do not invent GitLab CI.
10. Exactly one write owner: `general_implementer`.
11. Bind receipts after the last change-package write (`ready` first).

---

## Residual risks (for architect / writer)

- **Dual change packages.** This report is bound to **39b13f** as assigned. Runtime also grew `20260816-ban-gha-rebuild-and-verify-2-0-6-publish-9fd274` (route `9fd2741e5d1b`) with the same intent. Coordinator must pick **one** write owner / one package so two implementers do not collide.
- Four tests will go red the moment files are deleted unless inverted first.
- Current zip `b34af685…` and commit `549f29d` become lies the moment Actions are removed. Publishing them is a defect.
- Removing CI `pip install` means a developer without Ruff/Bandit/Coverage locally will skip those checks. That is the accepted local-skip contract. Do not re-host it on Actions.
- Published 2.0.4 / 2.0.5 zips still contain the old template. Leave them. Only 2.0.6 (and future installs) must not copy GHA.
- Last-mile `git push` / `gh release create` still need a **fresh** `grok_approve.py production` immediately before execution. Expired 2.0.5 tokens do not transfer.
- Do not fold leftover `864726` / `ad4090` dirt into the ship commit unless it is this change’s own evidence.

---

## Suggested write slice (for architect / implementer; not executed here)

1. Invert / add the P0 tests (red).
2. Delete `.github/workflows/adaptive-grok.yml`, `.github/dependabot.yml`, `.grok-stack/templates/ci/github-actions.yml`; rewrite CI README.
3. Make `--with-ci` raise and never copy.
4. Rewrite unpublished CHANGELOG / RELEASE-NOTES 2.0.6 (ban + local SoT + Release ≠ Actions).
5. `python3 scripts/package_stack.py` and copy into `packages/`.
6. `python scripts/grok_verify.py --mode pr`.
7. Independent reviews + fingerprint-bound receipts.
8. Only then: `grok_deploy` + live production approval + tag / push / `gh release create` on the new commit.

---

## Stop

Acceptance, non-goals, test-first requirements, 864726 supersession, and Release-vs-Actions authorization are recorded. Implementation is in scope for `general_implementer` on this route after the analysis wave. This agent does not edit application code and does not publish.
