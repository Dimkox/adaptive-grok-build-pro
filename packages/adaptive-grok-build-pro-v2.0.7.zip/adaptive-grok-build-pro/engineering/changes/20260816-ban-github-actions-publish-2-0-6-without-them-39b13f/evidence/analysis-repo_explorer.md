# Analysis — repo_explorer

Change: `20260816-ban-github-actions-publish-2-0-6-without-them-39b13f`  
Route: `39b13fbab936` · write owner: `general_implementer`  
Question: exact files that must change to **never** use GitHub Actions, and whether v2.0.6 is still unpublished.

Read-only. No application-code edits. No `.env`. No `git push` / tag / merge / `gh release`. Remote facts from public GitHub HTML + raw `VERSION` (REST API was rate-limited). Local facts from `.git/HEAD`, `refs/heads/main`, `refs/remotes/origin/main`, `refs/tags/`, `COMMIT_EDITMSG`.

---

## 1. v2.0.6 is still unpublished

**Confirmed.** There is no remote tag `v2.0.6`. GitHub Latest is still **v2.0.5**.

| Check | Local | origin / GitHub | Meaning |
| --- | --- | --- | --- |
| Identity | `VERSION` = `2.0.6`; README H1 v2.0.6 | raw `https://raw.githubusercontent.com/Dimkox/adaptive-grok-build-pro/main/VERSION` = **`2.0.5`** | 2.0.6 tree is local-only |
| `main` | `549f29da1c4ff44ba44d8388c294fd5dd29bfd81` “Release v2.0.6: ruff, bandit, coverage, dependabot” | `origin/main` + GitHub `main` = `7c0ae7573535ddd0cfe3800f81278991ced81584` (v2.0.5) | one unpushed commit |
| Tag `v2.0.6` | **absent** (`.git/refs/tags/` is `v2.0.0`–`v2.0.5`; no `packed-refs`) | **absent** (`/tags` top is `v2.0.5`; `/releases/tag/v2.0.6` is **404**) | no tag to publish from |
| GitHub Latest | — | **v2.0.5** on `7c0ae75`, published 16 Aug 16:10 (`/releases/latest`) | Latest is still 2.0.5 |
| `packages/` | local zip `v2.0.6` digest `b34af685c8d277aafcfbc4aa3f393286b12af2b092e5efa2b74ab6f5ba41b610` | origin listing stops at `v2.0.5.zip` | 2.0.6 zip is not on origin |
| `.github/` on origin | local has workflow **and** Dependabot | origin `.github/` has **only** `workflows/` (Dependabot landed on `549f29d`, unpushed) | origin still runs the 2.0.5 workflow |

Do **not** retag `v2.0.5`. Last mile (human `git tag` / `git push` / `gh release create`) is still available and is **not** GitHub Actions. Ban Actions first, rebuild the 2.0.6 zip, then tag that later tree. Do not ship the current `b34af685…` zip: it contains `.github/dependabot.yml` and `.github/workflows/adaptive-grok.yml` (`included_files()` does not exclude `.github/`; ec0388 review recorded those members in `MANIFEST.sha256`).

---

## 2. Exact files that must change (never GitHub Actions)

`.github/` today is only two files. No `action.yml`, no extra workflows, no CODEOWNERS.

### Must delete (this-repo hosted Actions)

| Path | Why |
| --- | --- |
| `.github/workflows/adaptive-grok.yml` | Only workflow. `on: push` + `pull_request`. Jobs: `verify` (`actions/checkout@v4`, `actions/setup-python@v5`, pip ruff/bandit/coverage, unittest, doctor, `grok_verify --mode pr`) and conditional `package` (`hashFiles('scripts/package_stack.py')` + `actions/upload-artifact@v4`). No `gh release` / `git push`. |
| `.github/dependabot.yml` | `package-ecosystem: github-actions` weekly. Exists only to keep Actions tags current. |

After those two deletes, empty `.github/workflows/` and `.github/` should go with them.

### Must delete or neutralize (installer / consumer template)

| Path | Why |
| --- | --- |
| `.grok-stack/templates/ci/github-actions.yml` | Byte-identical to the root workflow (locked by `test_root_workflow_equals_template`). `--with-ci` copies this to consumer `.github/workflows/adaptive-grok.yml`. Also always shipped under `.grok-stack/` because `install_into.MANAGED_DIRS` includes `.grok-stack`. |
| `.grok-stack/templates/ci/README.md` | Documents “optional GitHub Actions workflow” and “this repository copies it to `.github/workflows/adaptive-grok.yml`”. Rewrite to: never GHA; local `make verify` / `grok_verify --mode pr` only. |

### Must edit (installer `--with-ci`)

| Path | Lines | Why |
| --- | --- | --- |
| `scripts/install_into.py` | `with_ci: bool = False` (L91); copy block L119–127; `--with-ci` argparse L188; `with_ci=args.with_ci` L197 | Only code path that **writes** a consumer workflow. Default is already off. “Never” means: remove the flag **or** make `--with-ci` `SystemExit` and write nothing. |

`MANAGED_DIRS` / `MANAGED_FILES` do **not** list `.github/`. Default `install_into` without `--with-ci` does not write a workflow. It **does** still copy `.grok-stack/templates/ci/github-actions.yml` into the target as part of `.grok-stack/`. Deleting or neutralizing that template is required so consumers cannot pick up a GHA file.

### Must edit (tests that lock “keep GHA”)

These four tests **fail** if the workflow/template/`--with-ci` copy disappear without a matching test change.

| Path | Test | Current lock |
| --- | --- | --- |
| `tests/test_deploy.py` | `DeploySourceAndCiTests.test_root_workflow_equals_template` | Both files exist; bytes equal |
| `tests/test_deploy.py` | `test_template_package_job_is_conditional_and_has_no_publish` | Template contains `hashFiles('scripts/package_stack.py')`; no `gh release` / `docker push` / `git push` |
| `tests/test_deploy.py` | `test_workflow_installs_quality_tools` | Template contains `pip install` + ruff/bandit/coverage + unittest + `grok_verify.py --mode pr` |
| `tests/test_installer.py` | `test_with_ci_preserves_unrelated_workflow` | `with_ci=True` **must write** `adaptive-grok.yml` and leave an unrelated sibling workflow |

`test_prepare_sources_do_not_execute_publish_commands` in the same class is about `deploy.py` / `grok_deploy.py`, **not** Actions. Keep it.

Invert the four keep-GHA tests to: no `.github/workflows/*.yml`, no Dependabot, `--with-ci` does not write a workflow.

No other test file names `github-actions.yml`, `dependabot`, or `--with-ci`. `tests/test_structure.py` and `tests/test_manifest_package.py` do not pin CI files.

### Must edit (product docs that still claim Actions)

| Path | What to change |
| --- | --- |
| `CHANGELOG.md` | **2.0.6** still says “Dependabot for GitHub Actions only” and “CI fail-closed after `pip install`”. Replace with: no GitHub Actions; local `grok_verify` is the gate. Leave the **2.0.4** historical bullet (“This-repo GitHub Actions: verify plus a conditional package job”) as history unless the writer wants a one-line “removed in 2.0.6”. |
| `engineering/decisions.md` | No current GHA decision. Add one: never GitHub Actions; local verify is SoT; GitHub Release via `gh` is a different thing and stays human-owned. |

### README — listed, but no GHA claim today

`README.md` never names GitHub Actions, `--with-ci`, `.github/workflows`, or Dependabot. Grep is empty. It **does** name GitHub CLI `gh` “for GitHub Release” and human tag/push/Release — that is **not** Actions and must not be deleted as part of this ban.

Optional: one sentence that this product never uses GitHub Actions. Not required to make the ban true.

`QUICKSTART.md` and `Makefile` also have no Actions references. `make verify` is `python3 scripts/grok_verify.py --mode pr`.

### `managed.json` — does **not** track CI

`.grok-stack/config/managed.json` lists agents, skills, hook types, and `scripts/grok_*.py`. No workflows, no Dependabot, no `--with-ci`, no `.github/`. **Do not edit** unless a later design adds a new script.

`install_into.MANAGED_FILES` likewise has no `.github/` entries.

---

## 3. Rebuild after the tree change (publish 2.0.6 without Actions)

Not “GitHub Actions files”, but required so the unpublished SKU does not ship Actions:

| Path | Action |
| --- | --- |
| `packages/adaptive-grok-build-pro-v2.0.6.zip` | Rebuild after the deletes. In-zip `VERSION` stays `2.0.6`. In-zip members must not include `.github/workflows/*`. |
| `packages/adaptive-grok-build-pro-v2.0.6.zip.sha256` | Sibling digest of the new zip. Current `b34af685…` is the **with-Actions** tree. |
| `dist/adaptive-grok-build-pro-v2.0.6.zip*` + `dist/RELEASE-NOTES.md` | gitignored scratch from `package_stack.py`; rewrite CHANGELOG §2.0.6 first so notes match. |

`packages/README.md` already lists the 2.0.6 row. No GHA text. Origin `packages/README.md` still stops at 2.0.5.

Do **not** bump `VERSION`. Keep `2.0.6`. Do **not** touch `packages/adaptive-grok-build-pro-v2.0.5.zip*`.

---

## 4. Do not change (not GitHub Actions)

| Surface | Why leave it |
| --- | --- |
| Grok hooks (`.grok/hooks/*`, root shims, `tests/test_hooks.py`) | Lifecycle adapters, not hosted CI |
| `scripts/grok_verify.py` / `verification.py` | No `GITHUB_ACTIONS` / CI-env branch. “CI fail-closed after pip install” lives only in the workflow + CHANGELOG. Local skip-if-missing stays. |
| `scripts/grok_deploy.py`, `engineering/runbooks/publish-v2.0.6.md` | Print-only last mile: human `git tag` / `git push` / `gh release create` |
| `toolchain.json` `gh` pin | GitHub Release CLI, not Actions |
| Historical `engineering/changes/**` (99b743, ec0388, 864726, 9fd274, …) | Do not rewrite closed analysis |
| `engineering/mistakes.md` | No GHA entry |

GitHub Release ≠ GitHub Actions. This route bans the latter. Publishing v2.0.6 as a GitHub Release after the ban is still the last mile.

---

## 5. Write-owner file list (copy/paste)

**Delete**

- `.github/workflows/adaptive-grok.yml`
- `.github/dependabot.yml`
- `.grok-stack/templates/ci/github-actions.yml` (or replace with a non-Actions stub; delete is cleaner)

**Edit**

- `.grok-stack/templates/ci/README.md`
- `scripts/install_into.py` (`--with-ci` copy + help)
- `tests/test_deploy.py` (three workflow/template tests)
- `tests/test_installer.py` (`test_with_ci_preserves_unrelated_workflow`)
- `CHANGELOG.md` (§2.0.6)
- `engineering/decisions.md` (new ban decision)
- `README.md` — optional one-line ban only

**Do not edit**

- `.grok-stack/config/managed.json`

**Rebuild after the above**

- `packages/adaptive-grok-build-pro-v2.0.6.zip`
- `packages/adaptive-grok-build-pro-v2.0.6.zip.sha256`

Tests that must then pass: inverted GHA tests + existing installer/deploy/verify suite + `python3 scripts/grok_verify.py --mode pr`. Then human last mile on the **new** tree; Latest is still 2.0.5 until that happens.
