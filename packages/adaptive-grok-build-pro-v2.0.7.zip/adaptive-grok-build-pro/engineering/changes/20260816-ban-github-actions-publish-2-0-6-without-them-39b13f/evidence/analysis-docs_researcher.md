# Docs research — GitHub Actions vs local verify vs GitHub Release

Route: `39b13fbab936`. Change: `20260816-ban-github-actions-publish-2-0-6-without-them-39b13f`.
Question: what README, `templates/ci/README.md`, CHANGELOG, `install --with-ci` help, and `test_deploy` actually say today about GitHub Actions vs local verify vs GitHub Release.

Read-only. No application-code edits. No `.env`. No push / merge / deploy. No APIs invented.

## Sources

- `README.md`, `QUICKSTART.md`, `CHANGELOG.md`, `AGENTS.md`, `Makefile`, `packages/README.md`, `dist/RELEASE-NOTES.md`
- `.grok-stack/templates/ci/README.md`, `.grok-stack/templates/ci/github-actions.yml`, `.github/workflows/adaptive-grok.yml`, `.github/dependabot.yml`
- `scripts/install_into.py` (`--with-ci` help and default), `scripts/grok_deploy.py`, `.grok-stack/adaptive_grok/deploy.py`, `.grok-stack/adaptive_grok/policy.py`
- `tests/test_deploy.py`, `tests/test_installer.py`
- `engineering/decisions.md`, `engineering/adr/` (empty), `engineering/contracts/{openapi,asyncapi,schemas}/` (no product APIs)
- `engineering/runbooks/publish-v2.0.{4,5,6}.md`
- `.grok/skills/adaptive-delivery/SKILL.md`, `.grok/skills/release-readiness/SKILL.md`, `.grok/skills/feature-workflow/SKILL.md`
- Prior packages: `99b743` (this-repo CI introduced), `ec0388` (2.0.6 quality contour), `864726` (2.0.6 GitHub Release last mile)
- This change package (still a stub: `state.json` status `draft`; empty acceptance / architecture / test plan)

---

## 0. Three different things (do not collapse)

| Thing | What the tree calls it | What it does today | Last-mile? |
| --- | --- | --- | --- |
| **Local verify** | `make verify` / `python3 scripts/grok_verify.py --mode pr` | Source-of-truth quality gate on any machine | No. Required before close. |
| **GitHub Actions** | hosted CI; `.github/workflows/adaptive-grok.yml`; installer `--with-ci` | Optional hosted verify + conditional package; **does not publish** | No. |
| **GitHub Release** | `gh release create v<VERSION> …` | Human last mile that advertises `packages/` zip + sha256 | **Yes.** Different CLI, different policy gate. |

User override for this route: **never GitHub Actions**. That is source-of-truth #1 (`AGENTS.md` “User-approved scope and decisions”) and it overrides the this-repo workflow, Dependabot `github-actions`, and the optional `--with-ci` consumer path. It does **not** repeal GitHub Release or local verify.

---

## 1. README.md — silent on Actions; loud on local verify and GitHub Release

`README.md` never names GitHub Actions, `--with-ci`, `.github/workflows`, or hosted runners. Grep of that file for `--with-ci` is empty.

What it *does* say:

Requirements table (`README.md:60`):

> GitHub CLI (`gh`) | 2.40 | 2.86.0 | 2.86 | **for GitHub Release**

Install block (`README.md:72-79`) shows only:

```bash
python3 scripts/install_into.py /path/to/your/repo
# skip host installs: --no-deps
# also PHP/Node/gh: --all-deps
```

No `--with-ci` mention. Default install is the stack, not a workflow.

Scripts loop (`README.md:110`):

> Loop: route → change → verify → independent reviews → `ready` → `python3 scripts/grok_deploy.py` (prepare-only) → humans run the printed tag / push / **GitHub Release** commands.

Scripts table (`README.md:117-120`):

> `scripts/grok_verify.py` | Verification gate (unittest, Ruff, Bandit, measured coverage in `pr`/`release`)
> `scripts/grok_deploy.py` | Prepare-only last mile: check evidence, print human publish commands

Package (`README.md:139-140`):

> Published copies live in `packages/` and on the **GitHub Release**.

License / local checks (`README.md:148`):

> Local checks: `make doctor` / `make verify`. `grok_verify --mode pr` also runs Ruff and Bandit when those CLIs are on PATH (skip if missing) and a Coverage.py fail-under of 74.

`QUICKSTART.md` is the same split: verify locally, then prepare human publish. It does not mention Actions.

`QUICKSTART.md:29-33`:

> 6. Verify before finish:
> `python3 scripts/grok_verify.py --mode pr`
> Then `/release-readiness` and `python3 scripts/grok_deploy.py` to prepare human-owned publish commands (`--record` only with production approval).

`Makefile` binds local verify, not Actions:

```
verify:
	python3 scripts/grok_verify.py --mode pr
deploy:
	python3 scripts/grok_deploy.py
```

**Fact:** README treats local `make verify` / `grok_verify --mode pr` as the check, and `gh` / GitHub Release as the last-mile advertisement. It does not require, document, or even name GitHub Actions.

---

## 2. `.grok-stack/templates/ci/README.md` — hosted CI is optional; this repo still has a workflow

Full file, quoted:

> Optional GitHub Actions workflow: `github-actions.yml`. This repository copies it to `.github/workflows/adaptive-grok.yml` (verify + conditional package; no publish).
>
> Local `make verify` is the source of truth. Hosted CI is optional and does not publish.
>
> This project is MIT open source and does not depend on paid hosted CI.
>
> Local checks (free, any machine):
>
> ```bash
> make doctor
> make verify
> python scripts/grok_doctor.py
> python scripts/grok_verify.py --mode pr
> ```
>
> If you self-host CI (Woodpecker, Forgejo Actions, GitLab, Drone, Jenkins, …),
> wire the same commands. Do not require GitHub-hosted runners.

Locked facts from that file:

1. **Hosted CI is optional.**
2. **Do not require GitHub-hosted runners.**
3. **This-repo HAS a workflow** at `.github/workflows/adaptive-grok.yml` (copy of the template).
4. That workflow is **verify + conditional package; no publish**.
5. **Local `make verify` is the source of truth.**
6. Self-hosted non-GHA runners are explicitly allowed as an alternative.

The committed workflow (byte-identical to the template; see §5) still *uses* GitHub-hosted runners when it runs:

```yaml
runs-on: ubuntu-latest
```

That is the product’s optional this-repo CI. It is not a publish path. User now overrides: **never GHA** — so the optional this-repo workflow is in-scope to remove or stop using; it was never a publish prerequisite.

`99b743/brief.md:18` (the change that added this-repo CI) already called it optional:

> This repo has optional GitHub Actions (verify + conditional package), docs, and a 2.0.4 publish runbook.

`99b743/architecture.md:8`:

> **CI:** copy template to `.github/workflows/adaptive-grok.yml`. Add a conditional `package` job (`if: hashFiles('scripts/package_stack.py')`). No publish job.

`99b743/evidence/implementation.md:58`:

> Local `make verify` remains source of truth.

---

## 3. CHANGELOG — Actions are this-repo CI; GitHub Release is a different bullet

### 2.0.6 (`CHANGELOG.md:3-11`, same text in `dist/RELEASE-NOTES.md`)

> Quality contour on this tree. 2.0.5 remains the previous published **GitHub Latest until a human last mile**.
>
> - `grok_verify` runs Ruff from `ruff.toml` without a packaging marker; **local skip-if-missing; CI fail-closed after `pip install`**
> - Dependabot for **GitHub Actions** only

So 2.0.6 already distinguishes:

- **local** `grok_verify` (skip Ruff/Bandit if missing)
- **CI** fail-closed after `pip install` (the GHA workflow)
- **human last mile** that turns GitHub Latest from 2.0.5 into 2.0.6

Dependabot (`.github/dependabot.yml`) is `package-ecosystem: github-actions` only. That exists only because this-repo has a GHA workflow. A “never GHA” override makes that Dependabot file leftover, not a release blocker.

### 2.0.4 (`CHANGELOG.md:40-41`)

> Prepare-only `scripts/grok_deploy.py`: dry-run prints human publish commands; `--record` requires production approval and writes receipt `deploy`/`prepared`
> **This-repo GitHub Actions: verify plus a conditional package job (no publish)**

Same changelog section also gates `gh release create` as a **production invocation**, not as an Actions job (`CHANGELOG.md:33`):

> Production policy matches command invocations (`git push`, `gh pr merge`, `docker push`, `npm publish`, `gh release create`), not bare words in paths or arguments

### 2.0.2 (`CHANGELOG.md:54-55`)

> GitHub Release `v2.0.2` ships zip, sha256, and source tar.gz

### 2.0.0 (`CHANGELOG.md:73`)

> Local verification: `make doctor` / `make verify` / `python3 -m unittest discover -s tests`

**Fact:** CHANGELOG has never said “publish via GitHub Actions.” It said this-repo Actions verify/package and, separately, a human GitHub Release last mile.

---

## 4. `install --with-ci` help text — consumer opt-in; default is off

`scripts/install_into.py:91`:

```python
with_ci: bool = False,
```

`scripts/install_into.py:188`:

```python
parser.add_argument('--with-ci', action='store_true', help='Install a generic GitHub Actions verification workflow.')
```

Behavior when the flag is set (`install_into.py:119-127`): copy `.grok-stack/templates/ci/github-actions.yml` → **consumer** `.github/workflows/adaptive-grok.yml`. Default install does not copy it.

`tests/test_installer.py::test_with_ci_preserves_unrelated_workflow` is the only installer test for the flag: with `with_ci=True` it copies `adaptive-grok.yml` and leaves an existing sibling workflow alone.

**Fact:** `--with-ci` is an **optional consumer installer switch**. It is not how this repo itself got a workflow (this repo committed `.github/workflows/adaptive-grok.yml` in `99b743`). It is not involved in `gh release create`. A “never GHA” override can leave the flag off (already the default) or delete the flag later; it is not required to publish 2.0.6.

---

## 5. `tests/test_deploy.py` — this-repo HAS a workflow; that workflow must not `gh release`; last mile *prints* `gh release create`

### 5.1 Last mile is printed `gh release create` (not Actions)

`test_dry_run_ready_is_ok_without_receipt` (`test_deploy.py:92-108`) asserts `prepare_deploy` prints:

- `python3 scripts/package_stack.py`
- `cp dist/adaptive-grok-build-pro-v{version}.zip* packages/`
- `git tag -a v{version}`
- `git push origin`
- **`gh release create v{version}`**
- `--notes-file dist/RELEASE-NOTES.md`

and writes **no** deploy receipt on dry-run.

That printer lives in `deploy.py:_human_commands` (`deploy.py:24-34`). The sixth line is:

```text
gh release create v{version} packages/{zip} packages/{zip}.sha256 --notes-file dist/RELEASE-NOTES.md
```

`scripts/grok_deploy.py:15`:

> Prepare human-owned publish commands. Never executes tag, push, or release.

`test_prepare_sources_do_not_execute_publish_commands` forbids `subprocess` / `os.system` in `deploy.py` and `grok_deploy.py`.

### 5.2 This-repo workflow exists and equals the template

`test_root_workflow_equals_template` (`test_deploy.py:193-197`):

```python
workflow = ROOT / '.github/workflows/adaptive-grok.yml'
template = ROOT / '.grok-stack/templates/ci/github-actions.yml'
self.assertTrue(workflow.is_file())
self.assertEqual(workflow.read_bytes(), template.read_bytes())
```

**This-repo HAS a workflow.** Tests fail if it is missing or drifts from the template.

### 5.3 That workflow is verify + package, and is forbidden from publishing

`test_template_package_job_is_conditional_and_has_no_publish` (`test_deploy.py:199-204`):

- must contain `hashFiles('scripts/package_stack.py')`
- must **not** contain `gh release`
- must **not** contain `docker push`
- must **not** contain `git push`

`test_workflow_installs_quality_tools` (`test_deploy.py:206-213`) asserts the template contains `pip install`, `ruff`, `bandit`, `coverage`, `python -m unittest discover -s tests`, and `grok_verify.py --mode pr`.

The YAML itself (`github-actions.yml` / `.github/workflows/adaptive-grok.yml`):

- `on: push` and `pull_request`
- job `verify`: checkout, setup-python 3.12, pip install ruff/bandit/coverage, unittest, `grok_doctor.py`, `grok_verify.py --mode pr`
- job `package` `needs: verify` `if: hashFiles('scripts/package_stack.py') != ''`: `package_stack.py` then `actions/upload-artifact` of `dist/*.zip*`
- no `gh release`, no `git push`, no `docker push`, no `softprops/action-gh-release`, no `ncipollo/release-action`

**Fact:** `test_deploy` locks two independent contracts at once:

1. Human last mile **prints** `gh release create`.
2. GitHub Actions workflow **must not contain** `gh release`.

A writer who “bans GHA” must change or drop the workflow-existence tests. A writer who “publishes 2.0.6 without them” must **keep** the `gh release create` printer / runbook. Those are not the same edit.

---

## 6. GitHub Release is still the last mile (and is not GitHub Actions)

Confirming the user’s second question from standing contracts only.

### 6.1 Different command, different policy

`policy.py:48-54` `PRODUCTION_INVOCATIONS`:

```python
('git', 'push'),
('gh', 'pr', 'merge'),
('docker', 'push'),
('npm', 'publish'),
('gh', 'release', 'create'),
```

There is no `github-actions` / `workflow` / `act` invocation in that tuple. Actions YAML is not a gated production command. `gh release create` is.

`engineering/decisions.md:33-35`:

> compare leading tokens to `git push`, `gh pr merge`, `docker push`, `npm publish`, `gh release create`.

### 6.2 Adaptive-delivery and release-readiness

`.grok/skills/adaptive-delivery/SKILL.md:103`:

> Do not deploy, publish, merge, or perform external writes as part of closure. Those are separate, explicitly approved actions. The last mile is `python3 scripts/grok_deploy.py`; humans own the printed commands.

`.grok/skills/release-readiness/SKILL.md:20`:

> After go/no-go, run `python3 scripts/grok_deploy.py`. Use `--record` only with a valid production approval. Humans run the printed commands. Do not deploy from this skill.

### 6.3 2.0.6 runbook (print-only last mile)

`engineering/runbooks/publish-v2.0.6.md:3-5`:

> Print-only last mile. Assemble the zip first; humans own tag / push / **GitHub Release**.
>
> Agents must not run `git push`, `git tag`, or `gh release`; humans own those commands.

Printed commands (`publish-v2.0.6.md:19-26`) are the same six lines as `deploy.py`. The last one is `gh release create v2.0.6 …`. None of them is `gh workflow run` or an Actions dispatch.

Same split in `publish-v2.0.4.md:3,42` and `publish-v2.0.5.md:3-5`.

### 6.4 Prior 2.0.6 packages already separated the two

`ec0388/brief.md:13`:

> GitHub tag/release is last mile, not this change.

`ec0388/requirements.md:13-14`:

> CI template and `.github/workflows/adaptive-grok.yml` stay byte-identical
> No tag / push / `gh release`

`864726` is the publish change. Its brief outcome is **GitHub Latest v2.0.6** via tag + `git push` + `gh release create`. Its `human-approval.md` authorizes that last mile. It does not authorize, require, or mention a GitHub Actions run as a publish step.

`864726/evidence/analysis-docs_researcher.md` already recorded:

> `gh release create v2.0.6 packages/adaptive-grok-build-pro-v2.0.6.zip …`
> CI on tag push only verifies and uploads a *workflow* zip artifact; it does not create a Release.

`cd8a96/evidence/analysis-architect.md` (2.0.5 last mile):

> CI `.github/workflows/adaptive-grok.yml` | verify + upload `dist/*.zip*` artifact; **no** `gh release` / `git push`
> `gh` must use `packages/…v2.0.5.zip`, not `dist/` from Actions.

### 6.5 AGENTS.md

Prohibited routine actions include unapproved publish (`AGENTS.md:104`). They do not mention GitHub Actions. Verification is `python scripts/grok_verify.py --mode pr` (`AGENTS.md:90`), not a hosted workflow.

---

## 7. ADRs and contracts

- `engineering/adr/` is empty. No ADR names Actions as required.
- `engineering/contracts/{openapi,asyncapi,schemas}/` have no product APIs. No contract requires a GitHub-hosted runner or a workflow job.
- `feature-workflow`: a new service / framework / major dependency needs an ADR. Deleting optional CI is not a new service. Adding a required GHA publish job would be.

---

## 8. What a “never GHA; still publish 2.0.6” change may and must not touch

User override (this prompt): never GitHub Actions. Standing last-mile contract: still `gh release create`.

**May change (Actions surface, currently optional):**

- `.github/workflows/adaptive-grok.yml` (this-repo copy; tests currently require it)
- `.grok-stack/templates/ci/github-actions.yml` and `templates/ci/README.md`
- `.github/dependabot.yml` (`github-actions` only)
- installer `--with-ci` help / copy path
- `tests/test_deploy.py` workflow-existence / template-equality / workflow-content tests
- CHANGELOG 2.0.6 “CI fail-closed after pip install” / “Dependabot for GitHub Actions only” wording if the contour is being restated

**Must not change (GitHub Release last mile):**

- `deploy.py:_human_commands` sixth line `gh release create`
- `test_deploy.py` assertions that dry-run prints `gh release create` and that prepare sources do not execute it
- `engineering/runbooks/publish-v2.0.6.md` human `gh release create` / rollback `gh release delete`
- README / QUICKSTART “humans run the printed tag / push / GitHub Release commands”
- `PRODUCTION_INVOCATIONS` entry `('gh', 'release', 'create')`
- Local verify as source of truth: `make verify` / `grok_verify.py --mode pr`

**Must not invent:** a GitHub Actions publish job, `workflow_dispatch` release, or “wait for GHA green” gate. None of those exist as a required contract today, and the user now forbids GHA entirely.

**Do not confuse rollback of a Release with Actions.** Runbook rollback is `gh release delete v2.0.6 --yes` plus delete the tag. That is the Release API, not a workflow.

---

## 9. This change package

`engineering/changes/20260816-ban-github-actions-publish-2-0-6-without-them-39b13f/` is still a stub (`state.json` `draft`). Brief/requirements/architecture/test-plan do not yet record the user override. Facts above come from standing docs, not from this package’s empty acceptance list.

Recommended acceptance language for the write owner (not invented APIs — restating sources):

- Local `make verify` / `grok_verify --mode pr` remains the quality source of truth (`templates/ci/README.md`).
- This-repo and installer no longer require or use GitHub Actions (user override of the optional this-repo workflow).
- Last mile remains printed `gh release create v2.0.6` of the existing `packages/` zip + sha256 (`publish-v2.0.6.md`, `deploy.py`). Humans own it. Agents do not run it as closure.

No product HTTP/event/data contract is affected.
