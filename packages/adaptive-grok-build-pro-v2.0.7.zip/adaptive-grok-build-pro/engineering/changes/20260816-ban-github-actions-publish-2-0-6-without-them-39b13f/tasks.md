# Tasks — Ban GitHub Actions; publish 2.0.6 without them

- [ ] Freeze contracts and expected behavior.
- [ ] Add failing test or characterization test.
- [ ] Implement the smallest vertical change.
- [ ] Run selected quality profile.
- [ ] Complete independent reviews.
- [ ] Bind evidence to the final tree fingerprint.
