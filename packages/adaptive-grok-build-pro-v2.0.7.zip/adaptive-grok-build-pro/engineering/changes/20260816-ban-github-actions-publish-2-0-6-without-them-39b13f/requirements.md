# Requirements — Ban GitHub Actions; publish 2.0.6 without them

## Acceptance criteria

- [ ] Given ..., when ..., then ...

## Failure and edge cases

- 

## Non-functional requirements

- Security:
- Reliability:
- Performance:
- Observability:
