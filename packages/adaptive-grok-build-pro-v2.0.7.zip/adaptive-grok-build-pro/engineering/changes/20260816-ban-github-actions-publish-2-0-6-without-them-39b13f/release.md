# Release plan — Ban GitHub Actions; publish 2.0.6 without them

## Deployment

## Feature flags / staged rollout

## Metrics and alerts

## Go/no-go criteria
