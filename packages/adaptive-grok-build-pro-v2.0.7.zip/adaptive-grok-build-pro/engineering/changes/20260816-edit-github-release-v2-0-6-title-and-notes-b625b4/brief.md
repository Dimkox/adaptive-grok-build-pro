# Edit GitHub Release v2.0.6 title and notes

Live card has empty name and stale “2.0.5 remains Latest” sentence. User: «меняй в гите релиз».

## Outcome

GitHub Release v2.0.6 titled Adaptive Grok Build Pro v2.0.6 with current notes. Tag, zip, and v2.0.5 stay put.

## In scope

`gh release edit` title + notes only.

## Out of scope

Retag, force-push, rebuild zip, GitHub Actions, new commit.
