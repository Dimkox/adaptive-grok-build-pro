# Test plan

1. `gh release view v2.0.6 --json name` is Adaptive Grok Build Pro v2.0.6
2. Body does not contain “until a human last mile”
3. Latest tag is still v2.0.6
4. v2.0.5 still exists
