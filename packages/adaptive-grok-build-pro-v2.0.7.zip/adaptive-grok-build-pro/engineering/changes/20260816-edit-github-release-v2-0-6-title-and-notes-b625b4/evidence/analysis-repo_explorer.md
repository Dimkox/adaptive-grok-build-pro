# Analysis — repo_explorer

Change: `20260816-edit-github-release-v2-0-6-title-and-notes-b625b4`  
Route: `b625b4f012f6` · write owner: none

Read-only. No application edits. No `gh release edit`. No tag / push / retag. REST `/releases` 403 (unauthenticated rate limit); live facts are public HTML.

Fetched 2026-08-16: `/releases`, `/releases/latest`, `/releases/tag/v2.0.6`, `/releases/tag/v2.0.5`, `/releases/tag/v2.0.4`, `/releases/tag/v2.0.0`, `/releases/expanded_assets/v2.0.6`, `/releases/expanded_assets/v2.0.5`, `/tags`. Local: `refs/heads/main`, `origin/main`, `refs/tags/v2.0.6`, `VERSION`, `dist/RELEASE-NOTES.md`, `packages/…-v2.0.6.zip.sha256`.

---

## Live GitHub cards

| Tag | Title (H1 / list label) | Latest | Peel | Notes |
| --- | --- | --- | --- | --- |
| **v2.0.6** | **empty** — UI falls back to tag `v2.0.6` (page title `Release v2.0.6`, not `Adaptive Grok Build Pro v2.0.6`) | **yes** (`/releases/latest` = this card; published 16 Aug 18:29) | [`e75f3a1`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/e75f3a1b92e247279fbb6210d46715a90cf7895c) | Still: *“2.0.5 remains the previous published GitHub Latest until a human last mile.”* |
| v2.0.5 | empty — UI falls back to `v2.0.5` | no | [`7c0ae75`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/7c0ae7573535ddd0cfe3800f81278991ced81584) | 2.0.5 body; zip `b80e6310…` still attached. Do not touch. |
| v2.0.4 | **Adaptive Grok Build Pro v2.0.4** | no | `33a02f1` | titled |
| v2.0.3 | **Adaptive Grok Build Pro v2.0.3** | no | `263b6eb` | titled |
| v2.0.2 | **Adaptive Grok Build Pro v2.0.2** | no | `6be318f` | titled |
| v2.0.1 | **Adaptive Grok Build Pro v2.0.1** | no | `79d1f10` | titled |
| v2.0.0 | **Adaptive Grok Build Pro v2.0.0** | no | `786e41a` | titled |

v2.0.6 assets unchanged vs local zip: `adaptive-grok-build-pro-v2.0.6.zip` sha256 `55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` plus sidecar and auto source archives (4 assets). Local `HEAD` / `origin/main` are the same peel. Annotated tag object `8e7c5b67a1f9e51cc2f15586b72e0dceff7f8ee1` → GitHub peel `e75f3a1`. Notes body == `CHANGELOG` §2.0.6 == `dist/RELEASE-NOTES.md` (create used `--notes-file` and no `--title`).

Gap for this change: title + stale last-mile sentence only. Tag, zip, and v2.0.5 stay put.
