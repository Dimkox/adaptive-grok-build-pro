# Release review — `b625b4f012f6`

Reviewer: `release_reviewer` (read-only). Write owner: **none**.
Change: `engineering/changes/20260816-edit-github-release-v2-0-6-title-and-notes-b625b4`
Intent: `release` · risk: `high` · profiles: `base`
Fetched: 2026-08-16 (HTML; unauthenticated REST `/releases/latest` is rate-limited)

**PASS.** **GO** to keep the edited GitHub Release card. **NO-GO** to retag, recreate, delete, touch `v2.0.5`, rebuild the zip, or treat `grok_deploy` / the v2.0.6 runbook create line as this route.

| Check (assigned) | Live result |
| --- | --- |
| Latest is Adaptive Grok Build Pro v2.0.6 | **PASS** |
| Notes no longer say 2.0.5 is Latest | **PASS** |
| Tag still `e75f3a1` | **PASS** (`e75f3a1b92e247279fbb6210d46715a90cf7895c`) |
| `v2.0.5` exists | **PASS** (not Latest; peel `7c0ae75`) |

Do not push, merge, deploy, retag, or run `gh release` from this review.

## Verdict

| Gate | Result |
| --- | --- |
| Live Latest title | **PASS.** `/releases/latest` H1 is **Adaptive Grok Build Pro v2.0.6** with the Latest badge. Same card as `/releases/tag/v2.0.6`. Index row titled the same, Latest badge on `v2.0.6` only. |
| Notes no longer claim 2.0.5 is Latest | **PASS.** Body has neither `2.0.5 remains` nor `until a human last mile`. |
| Immutable tag peel | **PASS.** Live tag still peels to [`e75f3a1b92e247279fbb6210d46715a90cf7895c`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/e75f3a1b92e247279fbb6210d46715a90cf7895c). Local `HEAD` / `origin/main` are that SHA. Annotated tag object `8e7c5b67…` unchanged. |
| Previous release | **PASS.** [`v2.0.5`](https://github.com/Dimkox/adaptive-grok-build-pro/releases/tag/v2.0.5) still exists, empty name (UI `v2.0.5`), peel [`7c0ae75`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/7c0ae7573535ddd0cfe3800f81278991ced81584), no Latest badge. |
| Assets / provenance | **PASS.** Four assets. Zip `sha256:55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` uploaded `2026-08-16T18:29:21Z` — create time, not a re-upload. Matches `packages/adaptive-grok-build-pro-v2.0.6.zip.sha256`. |
| Rollback | **PASS.** Card-only restore in `rollback.md`. Do not use the runbook delete/untag path. |
| Observability | **PASS** for this CLI + GitHub card. Title, Latest badge, peel, and body are independently visible. |
| Product mutation | **PASS / empty.** `write_agent` is null. No new commit. No `.github/`. `VERSION` still `2.0.6`. |
| Further production | **NO-GO.** This review is not a grant to retag, recreate, delete, edit `v2.0.5`, or rebuild the zip. |

## 1. Assigned live confirmations

Independent re-check of public HTML (not `gh`, not a write). `/releases/latest` and `/releases/tag/v2.0.6` agree. If they ever disagree, stop.

| Surface | Observation |
| --- | --- |
| Page title | `Release Adaptive Grok Build Pro v2.0.6 · Dimkox/adaptive-grok-build-pro` |
| H1 | **Adaptive Grok Build Pro v2.0.6** (was empty; UI used to fall back to tag `v2.0.6`) |
| Latest badge | Present on `/releases/latest` and `/releases/tag/v2.0.6`. Index Latest is this card only. |
| Published | 16 Aug 18:29 (create time; metadata edit does not move this) |
| Tag ref | `v2.0.6` → commit `e75f3a1` / `e75f3a1b92e247279fbb6210d46715a90cf7895c` |
| Notes heading | `## 2.0.6 — 2026-08-16` |
| Stale last-mile sentence | **Absent.** No “2.0.5 remains the previous published GitHub Latest until a human last mile.” |
| Five 2.0.6 bullets | Present (Ruff, Bandit, Coverage 74, no GHA, optional consumer tools) |
| `v2.0.5` | Exists at 16:10, title `v2.0.5`, peel `7c0ae75`, zip `b80e6310…`, 4 assets. Untouched. |
| Local refs | `refs/heads/main` = `origin/main` = `e75f3a1b92e247279fbb6210d46715a90cf7895c`. `refs/tags/v2.0.6` = annotated `8e7c5b67a1f9e51cc2f15586b72e0dceff7f8ee1`. `refs/tags/v2.0.5` = annotated `7f85f7be43fd8008f6af522a967ebc5268a481d1`. |
| GHA | `.github/` still absent. |

Live body (lead + bullets):

```text
## 2.0.6 — 2026-08-16

Quality contour: Ruff, Bandit, coverage ratchet, no GitHub Actions.

- grok_verify runs Ruff from ruff.toml without a packaging marker; skip-if-missing, fail-closed when ruff/bandit/coverage are installed
- Bandit AST next to regex secret-scan; excludes tests/ and engineering/
- Coverage.py report in pr/release after a measured fail-under of 74 (ratchet, not a guessed 90)
- No GitHub Actions / Dependabot; local python3 scripts/grok_verify.py --mode pr is the only gate. --with-ci is forbidden.
- Optional consumer Semgrep / Trivy config / npm prettier|format when those signals exist; not enabled on this tree
```

Matches gitignored scratch `dist/RELEASE-NOTES-v2.0.6-card.md`.

Change-package acceptance (`requirements.md` / `test-plan.md`):

| Criterion | Result |
| --- | --- |
| Name is `Adaptive Grok Build Pro v2.0.6` | **PASS** |
| Notes no longer say 2.0.5 is still Latest | **PASS** |
| Body does not contain “until a human last mile” | **PASS** |
| Tag still peels to `e75f3a1b92e247279fbb6210d46715a90cf7895c` | **PASS** |
| Latest tag is still `v2.0.6` | **PASS** |
| Assets unchanged | **PASS** |
| `v2.0.5` still exists | **PASS** |

## 2. Rollback — GO as card-only restore

This change’s rollback (`rollback.md`) is the only authorized undo:

```bash
gh release edit v2.0.6 --title "" --notes-file dist/RELEASE-NOTES.md
```

That restores the pre-edit empty name and the stale last-mile sentence. `dist/RELEASE-NOTES.md` is still on disk and still contains “2.0.5 remains the previous published GitHub Latest until a human last mile.” Do **not** delete the release. Do **not** touch `v2.0.5`.

If `--title ""` is rejected by this `gh`, leave the new title and restore notes only.

| Must not | Why |
| --- | --- |
| `gh release delete v2.0.6` (runbook `publish-v2.0.6.md`) | Withdraws Latest. That is the *prior* ship’s withdraw path, not a title/notes rollback. |
| `git push origin :refs/tags/v2.0.6` / `git tag -d` / `git tag -f` | Tag peel is correct. |
| Any `v2.0.5` mutation | Previous published artifact. Still the rollback target if 2.0.6 were ever withdrawn. |
| Rebuild zip / new commit / GHA | Out of scope; would be a new production event. |

No migrations, no data backfill, no feature flags. There is nothing to recover in a database.

## 3. Observability — GO for this product shape

This is a stdlib CLI plus a GitHub Release card, not a long-running service. No APM / SLO dashboard is required. Do not treat that absence as a ship blocker.

What observes success of **this** edit:

| Signal | Where | Expected now |
| --- | --- | --- |
| Release `name` | `/releases/latest` H1 | `Adaptive Grok Build Pro v2.0.6` |
| Latest badge | same page + index | on `v2.0.6` only |
| Tag peel | release commit chip | `e75f3a1` |
| Notes honesty | body first paragraph | no “2.0.5 remains Latest” |
| Artifact identity | expanded assets | zip `55406ff2…` at 18:29:21Z |
| Previous Latest intact | `/releases/tag/v2.0.5` | exists, not Latest |

Failure signals (any one is a stop, not a silent retry with `--tag` / create):

- Latest moves off `v2.0.6`
- `/releases/latest` and `/releases/tag/v2.0.6` disagree
- peel leaves `e75f3a1`
- `v2.0.5` missing or retitled by accident
- zip digest or upload timestamp moves
- last-mile sentence returns without an explicit rollback

Local quality bar is unchanged: `python3 scripts/grok_verify.py --mode pr`. This reviewer did not run it (would write a receipt). A `verification.json` already exists under `.grok-stack/runtime/receipts/b625b4f012f6/`.

## 4. Remaining risk (not FAIL)

1. **Lead sentence rewritten, not subtracted.** Architect / `release.md` asked for CHANGELOG `## 2.0.6` minus only the last-mile clause, keeping “Quality contour on this tree.” Live card (and the scratch notes file) say “Quality contour: Ruff, Bandit, coverage ratchet, no GitHub Actions.” Five bullets are intact. Named requirements and the assigned four checks still pass. Do **not** fire a second `gh release edit` on this route unless a human wants the exact CHANGELOG sentence.
2. **Repo CHANGELOG is now historically false.** `CHANGELOG.md:5` and rollback source `dist/RELEASE-NOTES.md:3` still say 2.0.5 remains Latest until last mile. That is out of this route. A later, separately approved docs commit may fix it. Do not fold it into a retag.
3. **`grok_deploy` / runbook still print `gh release create`.** Wrong for this already-published tag. Running them would be a recreate / asset rewrite. Printer remains print-only; humans must not run those lines for this change.
4. **Working-tree fingerprint moved** (`last-fingerprint.json` is `9fc96159…`; route `base_fingerprint` is `e463d60c…`) because change-package paperwork and scratch notes are uncommitted. Expected. Do not tag that dirty tree `v2.0.6`.
5. **`v2.0.5` empty title** is the same cosmetic leftover as before. Out of scope. Do not “fix while we are here.”
6. **Unauthenticated REST is rate-limited.** Authority this wave is public HTML. HTML Latest and tag pages agree.

## 5. GO / NO-GO

| Act | Decision |
| --- | --- |
| Keep live Latest = **Adaptive Grok Build Pro v2.0.6** on peel `e75f3a1`, zip `55406ff2…` | **GO** |
| Leave `v2.0.5` published at `7c0ae75` | **GO** |
| Card-only rollback via `rollback.md` if a human wants the old empty title / stale sentence | **GO** (human-owned `gh release edit` only) |
| Retag, force-push, `gh release create` / `delete`, zip rebuild, GHA, edit `v2.0.5`, CHANGELOG commit on this route | **NO-GO** |
| Treat this review as `production_action_approval` for any further mutation | **NO-GO** |

## What this review is not

- Not a second production action.
- Not approval to run `scripts/grok_deploy.py --record` or the v2.0.6 create/delete runbook.
- Not a CHANGELOG or `dist/RELEASE-NOTES.md` rewrite.
- Did not read `.env`. Did not push, merge, deploy, or call `gh`.

## Stop

**PASS.**

- **GO:** live Latest is Adaptive Grok Build Pro v2.0.6; notes no longer say 2.0.5 is Latest; tag still `e75f3a1`; `v2.0.5` exists.
- **NO-GO:** retag, recreate, delete, touch `v2.0.5`, rebuild zip.
- Rollback: card-only `gh release edit`.
- Observability: GitHub title + Latest badge + peel + body; local `grok_verify`.
