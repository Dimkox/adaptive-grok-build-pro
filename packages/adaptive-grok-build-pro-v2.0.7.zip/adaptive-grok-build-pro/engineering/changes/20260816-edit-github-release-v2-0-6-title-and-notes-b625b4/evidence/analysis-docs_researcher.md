# Docs research — prior release title/notes; `gh release edit` is not Actions and not a retag; «меняй» is card-edit approval

Route: `b625b4f012f6`. Change: `20260816-edit-github-release-v2-0-6-title-and-notes-b625b4`.
Question: what prior releases and runbooks say about GitHub Release title and notes; confirm `gh release edit` is not GitHub Actions and not a retag; confirm user «меняй» is production approval to edit the existing v2.0.6 Release card.

Read-only. No application-code edits. No `.env`. No push / tag / merge / deploy. No APIs invented.

Adaptive-delivery loaded from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. `write_agent` is `null`. Named gates: `scope_and_design_approval`, `production_action_approval`. Required evidence: `verification`, `security_review`, `release_review`.

## Sources

- This change package (`brief.md`, `architecture.md`, `requirements.md`, `release.md`, `rollback.md`, `tasks.md`, `test-plan.md`, `state.json`, `route.json`, `evidence/human-approval.md`)
- `.grok-stack/runtime/active-route.json` (`task`: `<user_query>меняй в гите релиз</user_query>`)
- `.grok/skills/adaptive-delivery/SKILL.md` §7; `.grok/skills/release-readiness/SKILL.md`
- `AGENTS.md` source-of-truth order and prohibited routine actions
- `engineering/decisions.md` 2026-08-16 Never GitHub Actions; 2026-08-14 production-invocation prefixes
- `engineering/runbooks/publish-v2.0.{4,5,6}.md`
- `CHANGELOG.md` §2.0.6 / §2.0.5 / §2.0.4 / §2.0.2; `dist/RELEASE-NOTES.md`; `dist/HANDOFF.md`; `README.md`; `QUICKSTART.md`; `packages/README.md`; `VERSION`
- `.grok-stack/adaptive_grok/deploy.py` `_human_commands`; `.grok-stack/adaptive_grok/policy.py` `PRODUCTION_INVOCATIONS`; `tests/test_policy.py`; `tests/test_deploy.py`
- `scripts/grok_approve.py` default TTL 15 minutes
- `.grok-stack/runtime/approvals.json` (not `.env`)
- `.grok-stack/config/toolchain.json` tool `gh` (`name`: GitHub CLI, `profile`: release)
- `.grok-stack/templates/ci/README.md`
- Prior packages: `cd8a96` (v2.0.5 last mile + empty-name residual), `ad4090` (notes = CHANGELOG verbatim), `864726` / `5be23b` / `9fd274` / `39b13f` / `ec0388` (v2.0.6 last mile; `gh` ≠ Actions), `e584b3` (v2.0.4 publish record), `ef7b14` (empty 2.0.5 name)
- `engineering/adr/` empty. `engineering/contracts/{openapi,asyncapi,schemas}/` have no product APIs.

This agent did not call `gh` or GitHub. Live-card claims below are from this package and prior recorded `gh release list` / `GET /releases/latest` evidence, not a fresh view.

---

## 1. What prior releases used for title

There is no OpenAPI/ADR contract for the GitHub Release `name`. The in-repo pattern is recovered from HANDOFF, runbooks, and recorded live lists.

### 1.1 Live names already observed

`cd8a96/evidence/implementation.md:130-136` recorded `gh release list --limit 6` after the v2.0.5 create:

```text
v2.0.5                              Latest  v2.0.5  2026-08-16T16:10:10Z
# Adaptive Grok Build Pro v2.0.4              v2.0.4  2026-08-15T01:27:26Z
# Adaptive Grok Build Pro v2.0.3              v2.0.3  2026-08-14T22:28:19Z
# Adaptive Grok Build Pro v2.0.2              v2.0.2  2026-08-14T21:18:43Z
# Adaptive Grok Build Pro v2.0.1              v2.0.1  2026-08-14T21:16:09Z
# Adaptive Grok Build Pro v2.0.0              v2.0.0  2026-08-14T21:01:24Z
```

Same list is cited in `cd8a96/evidence/code-review.md:113`, `cd8a96/evidence/test-review.md:50`, and `ef7b14/evidence/release-review.md:147`.

| Tag | Recorded GitHub `name` | Cite |
| --- | --- | --- |
| `v2.0.0`–`v2.0.4` | `Adaptive Grok Build Pro v2.0.x` | `cd8a96/evidence/implementation.md:132-136` |
| `v2.0.5` | **empty** (UI shows the tag) | same file `:144`; `cd8a96/evidence/code-review.md:217`; `ef7b14/evidence/release-review.md:147` |
| `v2.0.6` | this package: empty, same 2.0.5 mistake | `b625b4/brief.md:3`; `b625b4/requirements.md:3` |

README H1 is the same string form (`# Adaptive Grok Build Pro v2.0.6`, `README.md:1`). That H1 is docs identity, not parsed by `gh` (`ec0388/evidence/analysis-repo_explorer.md:131`).

### 1.2 Who passed `--title` and who did not

The only standing command that sets a Release title is the v2.0.1 handoff:

```25:30:dist/HANDOFF.md
gh release create v2.0.1 \
  dist/adaptive-grok-build-pro-v2.0.1.zip \
  dist/adaptive-grok-build-pro-v2.0.1.zip.sha256 \
  --repo Dimkox/adaptive-grok-build-pro \
  --title "Adaptive Grok Build Pro v2.0.1" \
  --notes-file dist/RELEASE-NOTES.md
```

Later printers dropped `--title`:

| Source | Create argv | Title flag |
| --- | --- | --- |
| `publish-v2.0.4.md:23` | `gh release create v2.0.4 … --notes-file dist/RELEASE-NOTES.md` | none |
| `publish-v2.0.5.md:15` | same shape for `v2.0.5` | none |
| `publish-v2.0.6.md:27` | same shape for `v2.0.6` | none |
| `deploy.py:33` / `test_deploy.py:107-108` | `gh release create v{version} … --notes-file dist/RELEASE-NOTES.md` | none |
| v2.0.4 tag message | `Adaptive Grok Build Pro v2.0.4` (`cd8a96/evidence/analysis-docs_researcher.md:156`) | tag annotation, not `--title` |
| v2.0.5 / v2.0.6 tag message | `-m "v2.0.5"` / `-m "v2.0.6"` (runbooks) | not a product title |

`cd8a96` then created v2.0.5 with the no-`--title` runbook line and recorded the empty-name residual (`implementation.md:144`):

> Release `name` is empty (GitHub UI will show the tag). Prior releases used `Adaptive Grok Build Pro v2.0.x`. Cosmetic only; fix with `gh release edit`, not a retag.

This package’s acceptance name is exactly that prior form: `Adaptive Grok Build Pro v2.0.6` (`requirements.md:3`; `test-plan.md:3`; `brief.md:7`; `release.md:3`: “Title matches v2.0.0–v2.0.4”).

`--title` as a `gh` flag is already in this tree (`dist/HANDOFF.md:29`; this `rollback.md:4`). Do not invent a REST field. The in-repo flag for the card title is `--title`.

---

## 2. What prior releases used for notes

### 2.1 Standing last-mile contract (2.0.4 → 2.0.6)

All three runbooks and the printer attach **`--notes-file dist/RELEASE-NOTES.md`**. Nothing in `package_stack.py` writes that file. `dist/` is gitignored. `gh` reads the working-tree file.

From 2.0.5 onward the written contract is **CHANGELOG section verbatim**, not a marketing wrapper:

| Contract | Value | Cite |
| --- | --- | --- |
| Path | `dist/RELEASE-NOTES.md` | `publish-v2.0.{4,5,6}.md`; `deploy.py:33` |
| 2.0.5 body | `CHANGELOG.md` §2.0.5 verbatim | `ad4090/evidence/analysis-docs_researcher-continue.md:57-77`; `cd8a96/evidence/analysis-docs_researcher.md:179-207` |
| 2.0.6 body at create | `CHANGELOG.md` §2.0.6 verbatim (already on disk) | `864726/evidence/analysis-docs_researcher.md:34-35`; `ec0388/evidence/analysis-docs_researcher.md:75` |
| Forbidden extras | MIT one-liner; `## Changes` / `## Assets` / `## Install`; leftover prior-version heading; consumer-upgrade sentence not in CHANGELOG | `ad4090/evidence/analysis-docs_researcher-continue.md:60-77` |
| Assets | zip + sibling `.sha256` only (no source tar.gz after 2.0.2) | `CHANGELOG.md:55`; `cd8a96/evidence/analysis-docs_researcher.md:216-217` |
| Older 2.0.1 notes | `dist/HANDOFF.md` | `58e51e/release.md:7` — do not reuse |

Wrong notes after create are fixed in place:

> Wrong notes → `gh release edit`, not a retag.

Cited: `cd8a96/requirements.md:17`; `cd8a96/evidence/analysis-architect.md:162`; `ad4090/evidence/analysis-architect.md:209`; `864726/evidence/analysis-architect.md:248`.

### 2.2 What is on disk now

`dist/RELEASE-NOTES.md:1-9` equals `CHANGELOG.md:3-11`:

```text
## 2.0.6 — 2026-08-16

Quality contour on this tree. 2.0.5 remains the previous published GitHub Latest until a human last mile.

- `grok_verify` runs Ruff from `ruff.toml` without a packaging marker; skip-if-missing, fail-closed when ruff/bandit/coverage are installed
- Bandit AST next to regex `secret-scan`; excludes `tests/` and `engineering/`
- Coverage.py report in `pr`/`release` after a measured fail-under of 74 (ratchet, not a guessed 90)
- No GitHub Actions / Dependabot; local `python3 scripts/grok_verify.py --mode pr` is the only gate. `--with-ci` is forbidden.
- Optional consumer Semgrep / Trivy config / npm prettier|format when those signals exist; not enabled on this tree
```

That second sentence was true **before** the human last mile (`CHANGELOG.md:5`; `864726/evidence/analysis-docs_researcher.md:64`). After Latest is v2.0.6 it is stale. This package’s live-card claim is that the published body still has it (`brief.md:3`).

### 2.3 This change’s notes exception (named, not invented)

Standing last-mile contract = CHANGELOG 2.0.6 **verbatim**. This package **overrides that for the live card only**:

- `release.md:3`: “Notes = CHANGELOG 2.0.6 **without the stale last-mile sentence**.”
- `requirements.md:4`: notes no longer say 2.0.5 is still Latest.
- `test-plan.md:4`: body does not contain “until a human last mile”.

What remains, by subtraction from `CHANGELOG.md:3-11` (do not add Assets/Install):

```text
## 2.0.6 — 2026-08-16

Quality contour on this tree.

- `grok_verify` runs Ruff from `ruff.toml` without a packaging marker; skip-if-missing, fail-closed when ruff/bandit/coverage are installed
- Bandit AST next to regex `secret-scan`; excludes `tests/` and `engineering/`
- Coverage.py report in `pr`/`release` after a measured fail-under of 74 (ratchet, not a guessed 90)
- No GitHub Actions / Dependabot; local `python3 scripts/grok_verify.py --mode pr` is the only gate. `--with-ci` is forbidden.
- Optional consumer Semgrep / Trivy config / npm prettier|format when those signals exist; not enabled on this tree
```

Out of scope: rewrite `CHANGELOG.md`, rewrite `dist/RELEASE-NOTES.md`, new commit (`brief.md:15`; `architecture.md:3`). Rollback therefore restores the **stale** on-disk notes file (`rollback.md:4`).

---

## 3. Confirmed: `gh release edit` is not GitHub Actions

Independent in-repo sources. No document equates GitHub CLI `gh release *` with GitHub Actions.

| Thing | What the tree calls it | Publish? |
| --- | --- | --- |
| **GitHub Actions** | Hosted CI from `.github/workflows/*.yml`; Dependabot `github-actions`; old `--with-ci` | **Banned.** `decisions.md` 2026-08-16; `publish-v2.0.6.md:5`; `.grok-stack/templates/ci/README.md:3`; `CHANGELOG.md:10` |
| **GitHub CLI (`gh`)** | Optional toolchain tool, profile `release` | Yes — last mile | `toolchain.json` id `gh`; `README.md:60` “for GitHub Release” |
| **`gh release create`** | Human-owned last-mile that **creates** the Release object + zip + sha256 | Yes | `publish-v2.0.6.md:5,27`; `deploy.py:33` |
| **`gh release edit`** | In-place fix for title/notes on an **existing** Release | Card only | this package; prior “wrong notes” / empty-name residuals |
| **`gh release delete`** | Rollback of a Release object | Withdraw | runbook rollback; **not** this change (`rollback.md:6`) |

`publish-v2.0.6.md:5`:

> Last mile is the GitHub CLI (`gh release create`), **not GitHub Actions**. Do not add `.github/workflows/`.

`9fd274/evidence/analysis-docs_researcher.md:263-297` and `5be23b/evidence/analysis-docs_researcher.md:89-117` already locked: banning Actions does **not** ban `gh release create` / `delete` / the `gh` pin. Same split applies to `edit`: it is the same CLI surface, not a workflow.

`policy.py:48-54` `PRODUCTION_INVOCATIONS` is only `('gh', 'release', 'create')`. There is no `github-actions` / `workflow` / `act` prefix. `test_deploy.py` historically asserted the (now-banned) workflow YAML **omits** the string `gh release`.

This package out of scope includes GitHub Actions (`brief.md:15`; `human-approval.md:5`).

---

## 4. Confirmed: `gh release edit` is not a retag

Every prior “wrong notes / empty name” ruling uses the same sentence: **edit the card, do not retag**.

| Source | Quote / rule |
| --- | --- |
| `cd8a96/requirements.md:17` | “Wrong notes → `gh release edit`, not a retag.” |
| `cd8a96/evidence/analysis-architect.md:162` | `gh release edit v2.0.5 --notes-file dist/RELEASE-NOTES.md`. Do not retag |
| `cd8a96/evidence/implementation.md:144` | empty name: “fix with `gh release edit`, not a retag” |
| `cd8a96/evidence/code-review.md:217` | same |
| `cd8a96/evidence/test-review.md:82` | same; not a test gap |
| `ef7b14/evidence/release-review.md:147` | “`gh release edit` only; not a retag” |
| `864726/evidence/analysis-architect.md:248` | `gh release edit v2.0.6 --notes-file …`. Do not retag |
| `ad4090/evidence/analysis-architect.md:209` | same for 2.0.5 |
| This `brief.md:9-15` | In scope: `gh release edit` title + notes only. Out: retag, force-push, rebuild zip, GHA, new commit |
| This `architecture.md:3` | “No product commit. `gh release edit v2.0.6` only.” |
| This `requirements.md:5-7` | Tag still peels to `e75f3a1b92e247279fbb6210d46715a90cf7895c`. Assets unchanged. `v2.0.5` still exists |
| This `rollback.md:4-6` | `gh release edit v2.0.6 --title "" --notes-file dist/RELEASE-NOTES.md`. **Do not delete the release. Do not touch v2.0.5.** |

A retag would be `git tag -f` / delete+recreate `v2.0.6` / `gh release create` again. Those are forbidden here. `git tag` is **not** in `PRODUCTION_INVOCATIONS` (`decisions.md:37-39`; `864726/evidence/analysis-architect.md:172`); the hook would not stop a retag. This design still forbids it.

Ship SHA for the existing tag, per this package and `5be23b`: `e75f3a1b92e247279fbb6210d46715a90cf7895c` (`Release v2.0.6: ban GitHub Actions, rebuild zip`). Do not move it back to `549f29d`.

In-repo `gh release edit` flags already used (do not invent others):

- `--notes-file dist/RELEASE-NOTES.md` (prior 2.0.5/2.0.6 “notes wrong” lines)
- `--title ""` (this `rollback.md:4`, restores the empty-name card)
- `--title "Adaptive Grok Build Pro v2.0.x"` (create-time form in `dist/HANDOFF.md:29`; this package’s desired live name)

No document in this tree uses `--target`, `-f`, or asset upload on `edit`. Do not add them.

---

## 5. User «меняй» as production approval

Route `task` and this `human-approval.md` quote the same user text: «меняй в гите релиз».

`evidence/human-approval.md:3-5`:

> **scope_and_design_approval** and **production_action_approval** granted 2026-08-16 by «меняй в гите релиз».
>
> Authorized: edit existing GitHub Release v2.0.6 title and notes. Do not retag. Do not touch v2.0.5. No GitHub Actions.

### 5.1 Verbal / markdown — **yes, for this card edit only**

| Check | This prompt | Cite |
| --- | --- | --- |
| Names the GitHub Release | «в **гите релиз**» | route `task`; `brief.md:3` |
| Imperative to change the existing card | «**меняй**» (edit), not «собери» / assemble | same; `architecture.md:3` |
| SoT #1 | User-approved scope outranks the print-only default | `AGENTS.md:19-21` |
| Named gates on this route | both present | `route.json:22-25`; `human-approval.md:3` |
| Scope recorded | title + notes on **existing** `v2.0.6` | `brief.md:9-15`; `requirements.md` |
| Prior last-mile «делай» / «go ahead» | does **not** transfer; this is a **new** go for the card | `ec0388` / `864726` already said prior 2.0.5 go does not transfer; same rule here |

Authorized outcome (already written): GitHub Release `v2.0.6` named `Adaptive Grok Build Pro v2.0.6`, notes = CHANGELOG 2.0.6 without the stale last-mile sentence. Tag peel `e75f3a1`. Zip/sha256 unchanged. `v2.0.5` untouched. No GHA. No retag. No product commit.

That is the same shape as the empty-name residual from `cd8a96` / `ef7b14`, now ordered by the user.

### 5.2 What this phrase does **not** authorize

- Retag / `git tag -f` / delete+recreate `v2.0.6`
- Any mutation of `v2.0.5` (tag, Release, assets)
- Rebuild zip / new commit / `package_stack.py`
- GitHub Actions / `.github/workflows/`
- `gh release delete` (runbook rollback for a *withdrawn* release; this `rollback.md` forbids delete)
- MCP `create_release` / `create_or_update_ref` (`864726/evidence/analysis-architect.md:165`)
- Reading `.env`
- This agent (`docs_researcher`) running `gh`

### 5.3 Live machine token — **not this prompt, and not required by the `edit` prefix**

`.grok-stack/runtime/approvals.json` currently has two rows, both reason `"publish v2.0.6 tag and GitHub Release"`, created `2026-08-16T18:29:04+00:00`, expire `18:44:04+00:00` (`production` `c9cb3e5950e6`, `external-write` `9d4811cb3c50`). Those are the **create/tag/push** tokens from the prior last mile, not an “edit title and notes” reason.

Markdown `human-approval.md` is **not** `has_valid_approval` (prior `864726/evidence/analysis-docs_researcher.md:80`; `state.py` as cited there). Default TTL is 15 minutes (`grok_approve.py:18`).

`PRODUCTION_INVOCATIONS` matches `('gh', 'release', 'create')` only (`policy.py:48-54`; `test_policy.py:70-76`). **`gh release edit` is not a gated prefix.** Prior architect notes already said the same about `gh release delete` (`cd8a96/evidence/analysis-architect.md:153`; `864726/evidence/analysis-architect.md:236`). PreToolUse will not demand a token for `edit` the way it does for `create`.

`AGENTS.md:104` still classifies “publish / production mutation … without short-lived explicit approval” as a prohibited **routine** action. Editing a live Release card is a production mutation. This route already has the named `production_action_approval` gate, and this package recorded it from «меняй». A human terminal running `gh release edit` does not need `grok_approve`. An agent-side `edit` is allowed by the hook prefix table; the named gate + SoT #1 are the authorization, scoped to title+notes.

Adaptive-delivery §7 and `publish-v2.0.6.md:7` still say agents must not run `gh release` **as closure**. This route is not closing a product change; `write_agent` is `null`; the authorized action is the card edit itself. Same print-vs-execute split already named for 2.0.4 / 2.0.5 / 2.0.6 create: standing runbook is print-only; a last-mile change with explicit user go is the this-change-only exception (`864726/evidence/analysis-docs_researcher.md:108-126`). «меняй» is that go for **edit**, not a second create.

---

## 6. Bottom line

1. **Title.** v2.0.0–v2.0.4 live names are `Adaptive Grok Build Pro v2.0.x`. Only `dist/HANDOFF.md` (v2.0.1) passed `--title`. 2.0.4–2.0.6 runbooks/`deploy.py` create with `--notes-file` only. v2.0.5 shipped an empty name; the recorded fix is `gh release edit`, not a retag. This package applies that same fix to v2.0.6: name `Adaptive Grok Build Pro v2.0.6`.

2. **Notes.** Standing create contract is CHANGELOG verbatim via `dist/RELEASE-NOTES.md`. That file still contains “2.0.5 remains the previous published GitHub Latest until a human last mile.” After Latest is v2.0.6 that sentence is stale. This package’s exception: card notes = CHANGELOG 2.0.6 **minus that sentence**. Do not invent Assets/Install. Do not rewrite `CHANGELOG.md` or the gitignored notes file on this route. Rollback restores `--title ""` and the on-disk stale notes.

3. **`gh release edit` ≠ GitHub Actions.** Last mile is GitHub CLI. Actions are banned. `gh` is the `release` toolchain. Policy gates `create`, not workflows.

4. **`gh release edit` ≠ retag.** Every prior residual says edit the card and leave the tag. This package: peel stays `e75f3a1`; assets unchanged; `v2.0.5` stays; no delete.

5. **«меняй в гите релиз» is production approval for this card edit.** Both named gates are already recorded. It does not authorize retag, v2.0.5 mutation, zip rebuild, GHA, or a new create. It is not a fresh `grok_approve` row; `edit` is not a `PRODUCTION_INVOCATIONS` prefix. This agent does not run `gh`.
