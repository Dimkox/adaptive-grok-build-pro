# Analysis — architect

Change: `20260816-edit-github-release-v2-0-6-title-and-notes-b625b4`  
Route: `b625b4f012f6` · intent=`release` · risk=`high` · write=`null` · reviews=`security_reviewer`+`release_reviewer` · gates=`scope_and_design_approval`,`production_action_approval` · evidence=`verification`,`security_review`,`release_review`  
User: «меняй в гите релиз». Session ruling: only `gh release edit v2.0.6` — title Adaptive Grok Build Pro v2.0.6; notes = CHANGELOG 2.0.6 minus the stale “2.0.5 remains Latest until last mile” sentence.

Read-only design. No application-code edits. No `.env`. No push / tag / merge / `gh release` from this agent.

Narrow question: exact `gh release edit` bytes, who runs them, and what must stay frozen.

---

## Ruling (one screen)

**No product commit. No retag. No force-push. No zip rebuild. No GitHub Actions. Do not touch v2.0.5. Controller runs one `gh release edit v2.0.6` after the already-recorded gates. Architect does not execute.**

| In | Out |
| --- | --- |
| `--title "Adaptive Grok Build Pro v2.0.6"` | `--tag`, `--target`, `-f`, `git tag`, `git push` |
| Notes = CHANGELOG `## 2.0.6` with the last-mile sentence removed | `--notes-file dist/RELEASE-NOTES.md` (still has the stale sentence) |
| Scratch notes under gitignored `dist/` | Commit CHANGELOG / `dist/` / this package |
| Leave tag peel `e75f3a1`, zip `55406ff2…`, Latest on v2.0.6 | `gh release create` / `delete` / upload / `--draft` / `--prerelease` |
| Leave GitHub Release `v2.0.5` (empty title, `7c0ae75`) | Edit v2.0.5; retag; delete; `--latest` toggle |
| Controller executes | Architect / analysis / review agents; a spawned write owner; MCP `update_release` |

`write_agent` is null → adaptive-delivery step 4 has no implementer. Parent controller is the only actor who may run `gh`.

This report is design. It is not authorization for the architect to mutate GitHub.

---

## 1. Current facts (inspected this wave)

| Item | Value |
| --- | --- |
| Local `HEAD` / `refs/heads/main` | `e75f3a1b92e247279fbb6210d46715a90cf7895c` |
| `origin/main` | same SHA |
| Local annotated tag object `v2.0.6` | `8e7c5b67a1f9e51cc2f15586b72e0dceff7f8ee1` |
| GitHub tag `v2.0.6` peels to | `e75f3a1` (html `/releases/tag/v2.0.6` + `/releases/latest`, 16 Aug 18:29) |
| GitHub Latest | **v2.0.6** (Latest badge on the tag page) |
| GitHub Release **name** | empty — UI heading is the tag `v2.0.6` |
| GitHub Release **body** | CHANGELOG `## 2.0.6` verbatim, including “2.0.5 remains the previous published GitHub Latest until a human last mile.” |
| Assets | 4 (zip + sha256 + GitHub source zip/tar). Do not inspect-as-mutate. |
| Tracked zip digest | `55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` |
| `VERSION` | `2.0.6` |
| `CHANGELOG.md:5` / `dist/RELEASE-NOTES.md:3` | still contain the stale last-mile sentence |
| GitHub Release `v2.0.5` | exists at `7c0ae75`; empty name (UI `v2.0.5`); **not** Latest |
| Titles v2.0.0–v2.0.4 | `Adaptive Grok Build Pro v2.0.x` (the pattern this edit restores for 2.0.6) |
| Remote | `origin` = `https://github.com/Dimkox/adaptive-grok-build-pro.git` |
| Policy `PRODUCTION_INVOCATIONS` | `git push`, `gh pr merge`, `docker push`, `npm publish`, **`gh release create` only** — not `edit` |
| `approvals.json` | two rows `2026-08-16T18:29:04Z` expire `18:44:04Z`, reason “publish v2.0.6 tag and GitHub Release”. Wrong reason; do not reuse. |
| This change | `draft`. Active change pointer is this `b625b4` package |
| This-route receipts | empty (`b625b4f012f6/`) |
| Prior ship | `5be23b` status `ready` on `e75f3a1`; last mile already created the empty-name card from `dist/RELEASE-NOTES.md` |
| CI | none. Do not add `.github/workflows/` |

The `/releases` index HTML this wave rendered without a v2.0.6 row (JS/cache). Authority is `/releases/tag/v2.0.6` and `/releases/latest`, both showing Latest on `e75f3a1`. If those two pages ever disagree, **stop**.

---

## 2. Why this is an edit, not a republish

`gh release create` already ran at 18:29 against `e75f3a1` + `packages/adaptive-grok-build-pro-v2.0.6.zip*` + `dist/RELEASE-NOTES.md`. That is why:

- name is empty (`deploy.py:33` / runbook never pass `--title`);
- body still advertises 2.0.5 as Latest (CHANGELOG lead sentence written **before** last mile).

Both are card metadata. Git objects, assets, and Latest badge are already correct. Recreating the release, moving the tag, or rebuilding the zip would be a new production event with no user authorization.

Do **not** commit a CHANGELOG fix. The user pinned GitHub notes = CHANGELOG 2.0.6 **minus that one sentence**. Repo `CHANGELOG.md` staying historically stale is out of this route.

---

## 3. Exact command sequence

`scripts/grok_deploy.py` still prints packager + tag + push + `gh release create`. That printer is **wrong for this route**. Do not run it. Do not `--record`.

### 3.1 Scratch notes (gitignored; not a commit)

Write **exactly** these bytes to `dist/RELEASE-NOTES-v2.0.6-card.md` (do **not** overwrite `dist/RELEASE-NOTES.md` — that file is the rollback source):

```markdown
## 2.0.6 — 2026-08-16

Quality contour on this tree.

- `grok_verify` runs Ruff from `ruff.toml` without a packaging marker; skip-if-missing, fail-closed when ruff/bandit/coverage are installed
- Bandit AST next to regex `secret-scan`; excludes `tests/` and `engineering/`
- Coverage.py report in `pr`/`release` after a measured fail-under of 74 (ratchet, not a guessed 90)
- No GitHub Actions / Dependabot; local `python3 scripts/grok_verify.py --mode pr` is the only gate. `--with-ci` is forbidden.
- Optional consumer Semgrep / Trivy config / npm prettier|format when those signals exist; not enabled on this tree
```

That is CHANGELOG `## 2.0.6` with only this clause removed from the lead paragraph:

` 2.0.5 remains the previous published GitHub Latest until a human last mile.`

Keep the heading, the remaining “Quality contour on this tree.” sentence, and all five bullets. Do not invent Assets / Install / MIT wrapper (that wrapper is 2.0.4 history, not this card).

A here-doc that writes the same bytes is equivalent. Do not `git add` the scratch file.

### 3.2 Preconditions — stop if any fail

```bash
git rev-parse HEAD
# expect e75f3a1b92e247279fbb6210d46715a90cf7895c

git rev-parse origin/main
# expect e75f3a1b92e247279fbb6210d46715a90cf7895c

git rev-parse 'v2.0.6^{}'
# expect e75f3a1b92e247279fbb6210d46715a90cf7895c

git rev-parse 'v2.0.5^{}'
# expect 7c0ae7573535ddd0cfe3800f81278991ced81584

test -f packages/adaptive-grok-build-pro-v2.0.6.zip
# sidecar must still start with
# 55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d

gh auth status

gh release view v2.0.6 --json tagName,name,body,isDraft,isPrerelease
# tagName=v2.0.6; name empty or null; body contains "until a human last mile";
# isDraft=false; isPrerelease=false

gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest --jq .tag_name
# expect v2.0.6

gh release view v2.0.5 --json tagName
# expect {"tagName":"v2.0.5"}
```

This `gh` may lack `isLatest` (cd8a96). Use `GET /releases/latest`, not `gh release view --latest`.

No-go: Latest is not v2.0.6, tag no longer peels to `e75f3a1`, v2.0.5 missing, release is draft, zip digest moved, or `HEAD` is not `e75f3a1` **and** we cannot still name that SHA. Then stop. Reassess. No `-f`. No recreate.

### 3.3 Edit — controller executes

```bash
gh release edit v2.0.6 \
  --title "Adaptive Grok Build Pro v2.0.6" \
  --notes-file dist/RELEASE-NOTES-v2.0.6-card.md
```

Only those two flags. Leading argv must be `gh release edit` so PreToolUse does not mistake it for `gh release create`.

Do **not** pass:

| Flag / extra | Why |
| --- | --- |
| `--tag` / `--target` | retargets the release; forbidden |
| `--draft` / `--prerelease` / `--latest` | Latest is already correct; do not toggle |
| `--discussion-category` | scope creep |
| asset paths | `edit` is metadata; upload/replace is a different production event |
| `gh release create` / `delete` / `upload` | republish / destroy |
| MCP GitHub `update_release` / `create_release` | second publisher |

### 3.4 Confirm

```bash
gh release view v2.0.6 --json tagName,name,body,isDraft,isPrerelease
# name == "Adaptive Grok Build Pro v2.0.6"
# body has no "until a human last mile" and no "2.0.5 remains"
# body still has "Quality contour on this tree." and the five bullets
# isDraft=false; isPrerelease=false

git rev-parse 'v2.0.6^{}'
# still e75f3a1b92e247279fbb6210d46715a90cf7895c

gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest --jq .tag_name
# still v2.0.6

gh release view v2.0.5 --json tagName
# still exists

gh release list --limit 8
# Latest badge still on v2.0.6; title now matches v2.0.0–v2.0.4
```

Asset names and zip digest must be unchanged. If `gh` can print asset digests, expect `sha256:55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` on `adaptive-grok-build-pro-v2.0.6.zip`.

### 3.5 Skip (already done / would make things worse)

| Command | Why skip |
| --- | --- |
| `python3 scripts/package_stack.py` / `cp dist/… packages/` | Would fold this change package into a new digest |
| `git add` / commit of CHANGELOG, this package, runtime | Product commit. User forbade it |
| `git tag` / `git tag -f` / `git push` | Tag already on `e75f3a1` |
| `gh release create` / `delete` | Republish / destroy |
| `gh release edit v2.0.5 …` | Same empty-title cosmetic; out of scope |
| `python3 scripts/grok_deploy.py` | Prints create + packager; change is `draft` so it also fails |
| `python3 scripts/grok_approve.py production` | Not required for `gh release edit` (see §5) |
| MCP release APIs | Second publisher |
| Adding `.github/workflows/` | Banned; not this problem |

---

## 4. Frozen surfaces

| Surface | Must remain |
| --- | --- |
| `refs/tags/v2.0.6` peeled | `e75f3a1b92e247279fbb6210d46715a90cf7895c` |
| `refs/tags/v2.0.5` peeled | `7c0ae7573535ddd0cfe3800f81278991ced81584` |
| `origin/main` / local `HEAD` | `e75f3a1` (working-tree paperwork is fine; no new commit) |
| Latest | v2.0.6 |
| Zip | `55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` |
| v2.0.5 zip | `b80e63103453db3161a4e4489216f654c04aec27e0821a1642ccc6c37027b4fd` |
| `VERSION` / product tree | untouched |
| GitHub Actions | still absent |

---

## 5. Who executes, and which gates

| Action | Who |
| --- | --- |
| This design | `architect` (done; stop) |
| Parallel facts | `repo_explorer`, `docs_researcher` (read-only) |
| Scratch notes + `gh release edit` | **Controller**, after this analysis wave |
| Human terminal running the same bytes | Also valid |
| `package_stack` / retag / touch v2.0.5 / GHA | Nobody |
| `security_reviewer` + `release_reviewer` | After the live card changes + `grok_verify --mode pr` |
| This architect running `gh` | **Forbidden** |

Gates:

1. **scope_and_design_approval** — this report is the design. Already recorded in `evidence/human-approval.md` from «меняй в гите релиз». Controller does not wait for a second human prompt unless Latest/`e75f3a1` preconditions fail.
2. **production_action_approval** — same utterance; same file. Editing a published GitHub Release is the production mutation this gate covers.
3. **PreToolUse `PRODUCTION_INVOCATIONS`** — `('gh', 'release', 'create')` only (`policy.py:48-54`; `tests/test_policy.py:70-85`). `gh release edit` is **not** hook-gated. Do **not** mint `grok_approve.py production` for this argv. The 18:29 publish tokens are the wrong reason and may already be expired; ignore them.

Do not spawn `general_implementer` or any other write role. The hook will block it (`write_agent` is null).

Do not treat adaptive-delivery close (`SKILL.md:103`) as a ban on this edit. Close still forbids treating publish as paperwork; the named production gate plus user ruling authorize **this** metadata edit, not a new tag.

---

## 6. Rollback (v2.0.6 card only)

Already in `rollback.md`:

```bash
gh release edit v2.0.6 --title "" --notes-file dist/RELEASE-NOTES.md
```

That restores today’s empty name and the stale last-mile sentence. Do not delete the release. Do not touch v2.0.5.

If `--title ""` is rejected by this `gh`, leave the new title and restore notes only (`--notes-file dist/RELEASE-NOTES.md`). Empty-title restore is cosmetic.

| Must not | Why |
| --- | --- |
| `gh release delete v2.0.6` | Destroys Latest; not a title/notes rollback |
| `git push origin :refs/tags/v2.0.6` / `git tag -d` | Tag is correct |
| Any v2.0.5 mutation | Previous published artifact |
| `git push --force` / `git reset --hard` | Destructive; `policy.py` `DESTRUCTIVE_COMMANDS` |

Partial-failure matrix:

| After | Next |
| --- | --- |
| Scratch write fails | Stop. Do not `gh` |
| Preconditions fail | Stop. Reassess. No create/delete |
| `gh release edit` fails (auth / 404) | Fix auth. Retry the **same** edit only |
| Title applied, notes wrong | Retry `--notes-file` only (same title) |
| Notes applied, title still empty | Retry `--title` only |
| Wrong release edited | Stop. Do not “fix” v2.0.5. Human. |

---

## 7. Post-edit (not the edit)

After the card matches §3.4:

1. Controller: `python3 scripts/grok_verify.py --mode pr` on the current tree (working tree may contain this analysis + scratch notes; that is session paperwork, not a second ship). Required evidence kind `verification`.
2. Dispatch **only** `security_reviewer` and `release_reviewer`. They inspect the **live** name, body (no last-mile sentence), tag peel `e75f3a1`, Latest badge, zip digest `55406ff2…`, and that `v2.0.5` still exists. They do not execute.
3. Record receipts **after** any last intended `state.json` write:

```bash
python scripts/grok_review.py security_review --status pass --report engineering/changes/20260816-edit-github-release-v2-0-6-title-and-notes-b625b4/evidence/security-review.md
python scripts/grok_review.py release_review --status pass --report engineering/changes/20260816-edit-github-release-v2-0-6-title-and-notes-b625b4/evidence/release-review.md
```

4. Optionally transition this change `draft` → `ready`. Do not fold that paperwork into a commit or a new tag.

Those receipts close route `b625b4f012f6`. They are not a second ship.

---

## 8. File ledger

| Path | Action |
| --- | --- |
| GitHub Release `v2.0.6` `name` + `body` | **Edit in place** (controller) |
| `dist/RELEASE-NOTES-v2.0.6-card.md` | **Create scratch** (gitignored; not committed) |
| `dist/RELEASE-NOTES.md` | **Leave** (rollback source; still has stale sentence) |
| `CHANGELOG.md` | **Do not edit** |
| `VERSION` / `README.md` | **Do not touch** |
| `packages/…v2.0.6.zip*` | **Do not rebuild** |
| `packages/…v2.0.5.zip*` | **Do not touch** |
| `.github/workflows/*` | **Must stay absent** |
| Git refs / `origin/main` | **Do not move** |
| GitHub Release `v2.0.5` | **Do not edit** |
| This analysis file | The only write from this agent |

---

## 9. Risks

| Risk | Mitigation |
| --- | --- |
| Muscle memory `gh release create` / runbook `grok_deploy` | Explicit skip table; argv must start `gh release edit` |
| `--notes-file dist/RELEASE-NOTES.md` keeps the stale sentence | Dedicated card file; rollback keeps the original |
| Editing v2.0.5 “while we’re here” | Out of scope; confirm command tag is `v2.0.6` |
| `--tag` / `--target` by habit | Forbidden flags list; preconditions pin peel |
| Rebuild zip because notes changed | Notes are not in the zip; digest must stay `55406ff2…` |
| CHANGELOG commit “to match GitHub” | User forbade a new commit |
| Reusing 18:29 production token | Not needed; wrong reason |
| MCP `update_release` as a “safer” path | Second publisher; no |

Residual: repo CHANGELOG still says 2.0.5 is Latest until last mile. That is now historically false on GitHub and stays that way until a **later**, separately approved docs commit. Not this route.

---

## 10. Acceptance

- [ ] `gh release view v2.0.6 --json name` is `Adaptive Grok Build Pro v2.0.6`
- [ ] Body has no “until a human last mile” / “2.0.5 remains”
- [ ] Body still has “Quality contour on this tree.” and the five 2.0.6 bullets
- [ ] `git rev-parse 'v2.0.6^{}'` == `e75f3a1b92e247279fbb6210d46715a90cf7895c`
- [ ] Latest tag is still v2.0.6
- [ ] Assets / zip digest `55406ff2…` unchanged
- [ ] Release `v2.0.5` still exists at `7c0ae75`
- [ ] No new commit, no retag, no GHA

---

## 11. What this agent did not do

No application edits. No CHANGELOG edit. No package rebuild. No `git push` / `git tag` / `gh release`. No read of `.env`. Independent reviews wait for the live edited card.

This report is design. It is not a verification or review receipt.
