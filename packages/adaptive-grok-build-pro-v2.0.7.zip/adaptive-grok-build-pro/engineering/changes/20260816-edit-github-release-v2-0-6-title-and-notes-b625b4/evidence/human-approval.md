# Human approval

**scope_and_design_approval** and **production_action_approval** granted 2026-08-16 by «меняй в гите релиз».

Authorized: edit existing GitHub Release v2.0.6 title and notes. Do not retag. Do not touch v2.0.5. No GitHub Actions.
