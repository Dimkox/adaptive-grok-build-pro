# Security review — `b625b4f012f6`

**PASS**

Route: `b625b4f012f6` (intent=`release`, risk=`high`, `write_agent: null`)  
Change: `20260816-edit-github-release-v2-0-6-title-and-notes-b625b4`  
Action reviewed: in-place `gh release edit v2.0.6` (title + notes only)  
Reviewer: `security_reviewer` (read-only; in `allowed_agents`)  
Fetched: 2026-08-16 public GitHub HTML for `/releases`, `/releases/latest`, `/releases/tag/v2.0.6`, `/releases/tag/v2.0.5`, expanded assets, `/actions`, `main/.github` (404), tag tree `v2.0.6`. Local refs, hashes, change package. Unauthenticated REST `/releases` 403 rate-limited; HTML + asset pages are the live authority.

No application-code edits. `.env` was not read. No push, merge, tag, retag, zip rebuild, or deploy from this agent.

---

## Verdict in one screen

The live GitHub Release **v2.0.6** was edited in place. Title is now `Adaptive Grok Build Pro v2.0.6`. Notes no longer claim 2.0.5 is Latest. That is card metadata only.

| Required confirmation | Result |
| --- | --- |
| No retag | **PASS.** Peel still `e75f3a1b92e247279fbb6210d46715a90cf7895c` |
| No new zip | **PASS.** Digest still `55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d` (uploaded 2026-08-16T18:29:21Z) |
| No GitHub Actions | **PASS.** No `.github` on `main` or `v2.0.6`. No new workflow run |
| No `.env` | **PASS.** Not read. Notes contain no secrets |
| v2.0.5 untouched | **PASS.** Still exists at `7c0ae75`; zip `b80e6310…`; timestamps 16:10:09Z |

**Authz** is the named `production_action_approval` from «меняй в гите релиз», scoped to this card. **Secrets / PII / tenant isolation** are not in play. **Irreversible** actions (retag, delete, force-push, zip replace, GHA) did not happen and remain forbidden.

---

## 1. What actually changed

Pre-edit (analysis wave): empty Release `name` (UI fell back to tag `v2.0.6`); body was CHANGELOG §2.0.6 verbatim, including “2.0.5 remains the previous published GitHub Latest until a human last mile.” Latest already on v2.0.6 at `e75f3a1`.

Post-edit (this review, public HTML):

| Field | Live v2.0.6 |
| --- | --- |
| Page / list title | **Adaptive Grok Build Pro v2.0.6** |
| Latest badge | yes (`/releases/latest` == this card) |
| Published | still **16 Aug 18:29** (create time; not a delete+recreate) |
| Peel | [`e75f3a1`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/e75f3a1b92e247279fbb6210d46715a90cf7895c) |
| Body lead | `Quality contour: Ruff, Bandit, coverage ratchet, no GitHub Actions.` — no “until a human last mile”, no “2.0.5 remains” |
| Assets | still 4 (zip + sha256 + GitHub source zip/tar) |

Local product tree is unchanged at `HEAD` / `origin/main` = `e75f3a1`. `VERSION` is `2.0.6`. `CHANGELOG.md` and rollback source `dist/RELEASE-NOTES.md` still contain the stale last-mile sentence (not committed away). Scratch notes live only in gitignored `dist/RELEASE-NOTES-v2.0.6-card.md`.

The lead sentence is a tighter rewrite than the architect’s “Quality contour on this tree.” That is still title/notes metadata. Not a secret, not a retag, not a new artifact. `release_reviewer` owns wording fidelity.

---

## 2. Required confirmations

### 2.1 No retag

| Probe | Value |
| --- | --- |
| Local `refs/heads/main` | `e75f3a1b92e247279fbb6210d46715a90cf7895c` |
| `refs/remotes/origin/main` | same |
| Local annotated tag object `v2.0.6` | still `8e7c5b67a1f9e51cc2f15586b72e0dceff7f8ee1` (architect’s pre-edit object) |
| GitHub `/releases/tag/v2.0.6` and `/releases/latest` | peel `e75f3a1` |
| `.git/logs/HEAD` last entry | `Release v2.0.6: ban GitHub Actions, rebuild zip` → `e75f3a1` — no later commit |
| Release published-at | still 16 Aug 18:29 |

A retag, `git tag -f`, or delete+recreate would move the peel, the annotated object, the published timestamp, and/or the auto source-archive times. None of those moved.

### 2.2 No new zip

Expanded assets `v2.0.6` (unchanged vs create):

- `adaptive-grok-build-pro-v2.0.6.zip` — sha256 `55406ff22f81ae05fc70eb9a5710b5c055c76a18f2ddbe60687c03b3e0b95c4d`, **692 KB, 2026-08-16T18:29:21Z**
- sidecar `.sha256` — sha256 `916f2b61be48d18a1d411c77e309133e7469c25f61e8cb82a53313dfb4fd9fb8`, 101 B, same timestamp
- GitHub source zip/tar — 2026-08-16T18:29:14Z

Local `packages/` and `dist/` sidecars still start with `55406ff2…`. No `package_stack` rebuild, no `gh release upload`.

### 2.3 No GitHub Actions

| Probe | Result |
| --- | --- |
| Local `.github/` | absent |
| `https://github.com/Dimkox/adaptive-grok-build-pro/tree/main/.github` | **404** |
| Tag tree `v2.0.6` | no `.github` row |
| Repo `*.yml` / `*.yaml` workflows | none |
| `/actions` | **5 historical runs**, all `.github/workflows/adaptive-grok.yml` on **v2.0.4 / v2.0.5** (`097f5c9`, `33a02f1`, `7c0ae75`). **No v2.0.6 run.** |

Those five failures are pre-ban history on older SHAs. This route did not add a workflow, did not re-enable Actions, and did not trigger a run.

`gh release edit` is GitHub CLI card metadata, not Actions. Policy `PRODUCTION_INVOCATIONS` lists `('gh', 'release', 'create')` only — not workflows.

### 2.4 No `.env`

This review opened the change package, analysis reports, `human-approval.md`, `approvals.json` (ids/timestamps/reasons only), `VERSION`, `CHANGELOG.md` header, gitignored scratch notes, local tag/HEAD refs, zip sidecars, and public GitHub HTML. It did **not** open `.env`, `*.pem`, `*.key`, credential stores, or production dumps.

Live notes are public changelog bullets (Ruff / Bandit / coverage / no Actions). No tokens, keys, emails, or customer data.

### 2.5 v2.0.5 untouched

| Probe | Live v2.0.5 |
| --- | --- |
| Exists | yes |
| Title | still empty (list/H1 = `v2.0.5`) |
| Latest | **no** |
| Peel | [`7c0ae75`](https://github.com/Dimkox/adaptive-grok-build-pro/commit/7c0ae7573535ddd0cfe3800f81278991ced81584) |
| Published | still 16 Aug 16:10 |
| Body | original 2.0.5 hook/toolchain notes |
| Zip | sha256 `b80e63103453db3161a4e4489216f654c04aec27e0821a1642ccc6c37027b4fd`, 426 KB, **2026-08-16T16:10:09Z** |
| Local annotated tag object | still `7f85f7be43fd8008f6af522a967ebc5268a481d1` |

Same four assets, same times, same digest as the pre-edit analysis. Not edited, not retagged, not deleted.

---

## 3. Authz, secrets, PII, tenant isolation, irreversible actions

### Authz

Named gates `scope_and_design_approval` and `production_action_approval` are recorded in `evidence/human-approval.md` from user «меняй в гите релиз», scoped to: edit existing GitHub Release **v2.0.6** title and notes; do not retag; do not touch v2.0.5; no GitHub Actions.

`approvals.json` still holds **expired** 18:29 create/tag tokens (`c9cb3e5950e6` production, `9d4811cb3c50` external-write, reason “publish v2.0.6 tag and GitHub Release”, window 18:29–18:44Z). Those were **not** reused and must not be. `gh release edit` is not a `PRODUCTION_INVOCATIONS` prefix. The authorization for this mutation is the named production gate + SoT #1 user ruling, not a leftover create token.

Observed mutation matches that scope: v2.0.6 `name` + `body` only.

### Secrets

No secret store, no new credential path, no token in notes. Packager still excludes `.env` / keys; this route did not rebuild the zip, so the published digest is the already-reviewed 2.0.6 artifact.

### PII

No customer data, no email harvest, no coverage/SaaS upload. Public MIT Release card.

### Tenant isolation

Product is a public CLI installed into consumer git trees. A GitHub Release title/notes edit does not change zip bytes, installer behavior, or any consumer tree. No multi-tenant data plane.

### Irreversible actions

None executed.

| Forbidden | Observed |
| --- | --- |
| `git tag -f` / retag / move peel | peel still `e75f3a1` |
| `gh release delete` / create | published-at and asset times unchanged |
| Asset upload / zip rebuild | digest and 18:29:21Z timestamp unchanged |
| Touch v2.0.5 | unchanged |
| `.github/workflows` | still absent |
| Force-push / `git reset --hard` | `HEAD` still `e75f3a1` |

Rollback remains reversible card metadata:

```bash
gh release edit v2.0.6 --title "" --notes-file dist/RELEASE-NOTES.md
```

Do not delete the release. Do not touch v2.0.5.

---

## Findings

No blocking findings.

| ID | Severity | Item | Disposition |
| --- | --- | --- | --- |
| S1 | Residual (accepted) | Card lead is a rewrite (`Quality contour: Ruff, Bandit…`) vs architect “Quality contour on this tree.” | Still notes-only. No secret/PII. Leave to `release_reviewer`. |
| S2 | Residual (accepted) | `gh release edit` is not hook-gated | Named production gate + user «меняй» cover this route. Do not mint a create-reason `grok_approve` after the fact. |
| S3 | Historical, not this route | Five failed Actions runs on v2.0.4/v2.0.5 | Workflows banned on `e75f3a1`. Do not restore them. |

---

## Recommendation

**PASS.** Treat the v2.0.6 GitHub Release card edit as an authorized, reversible metadata change. Tag, zip, Actions surface, secrets, and v2.0.5 are frozen. Do not retag. Do not rebuild. Do not add GHA. Do not read `.env`.
