# Rollback

```bash
gh release edit v2.0.6 --title "" --notes-file dist/RELEASE-NOTES.md
```

Do not delete the release. Do not touch v2.0.5.
