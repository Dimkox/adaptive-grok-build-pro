# Requirements

- [ ] Release name is `Adaptive Grok Build Pro v2.0.6`
- [ ] Notes no longer say 2.0.5 is still Latest
- [ ] Tag still peels to `e75f3a1b92e247279fbb6210d46715a90cf7895c`
- [ ] Assets unchanged
- [ ] v2.0.5 still exists
