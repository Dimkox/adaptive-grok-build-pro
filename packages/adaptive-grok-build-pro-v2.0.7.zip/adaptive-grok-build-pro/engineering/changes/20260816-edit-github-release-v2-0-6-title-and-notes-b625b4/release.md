# Release

Edit in place. Title matches v2.0.0–v2.0.4. Notes = CHANGELOG 2.0.6 without the stale last-mile sentence.
