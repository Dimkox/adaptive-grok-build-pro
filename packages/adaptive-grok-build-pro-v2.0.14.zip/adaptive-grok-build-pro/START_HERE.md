# Fresh-agent bootstrap

This file is the zero-context entrypoint for any new agent, human, Codex/Grok/Claude session, or clean clone of this repository. Do not depend on chat history to continue the project.

## Current project state

- Product source identity is `2.0.14`; its tracked zip is generated only from a clean exact M5 source commit in a separate artifact-only commit. Final M4 `2.0.13` remains retained under its own digest and identity. The most recently published GitHub Release remains `v2.0.12`, and no `v2.0.13` or `v2.0.14` tag/publication is claimed.
- M0 (Live Trust Authority) is delivered to `main`.
- M0 runtime repair and policy-loop fixes are also merged into `main` through PR #7 and PR #6.
- The current integration base is protected `origin/main` `78ad2f679d38dc3244e716c586332417e610089c`; it requires `adaptive-trust-ci/verified@06ecf1c875bc` from GitHub App ID `4694114` on the exact up-to-date pull-request head.
- M1 is implemented/reviewed in the accepted stack, but only its early slice and design/plan are on `main`; complete M1 delivery is partial. M2 and M3 are implemented/reviewed and merged into predecessor milestone branches by PRs #10 and #11, not delivered to `main`.
- Final local M4 predecessor is exact `571cad7877431ac5ab5779b53fe9f7effd6859ce` (tree `9d29f25d3af4fc9f97bbb8b3d4970906b69338fd`). Its 14/14 verifier fingerprint is `2f9b3ec2dd6f73e887bf375a02870dd91b8a322807e9383e6bd171e2113dba1b`; five local exact-head reviews/receipts passed with no gaps. This local gate does not claim M4 acceptance, PR delivery, external Trust CI or merge; PR #21's GitGuardian FAILURE metadata remains unresolved and is neither inspected nor dismissed.
- PRs #12/#13 remain old-epoch `ACTION_REQUIRED`; their unique lazy CLI import/tests and repository-scoped Trust CI profiles are absent from `main`. PR #15's current-epoch Trust CI conclusion is `FAILURE` and GitGuardian is `SUCCESS`; the cause was not inspected or inferred. Wholesale M1-M3 merge is superseded, while investor demo `9dcdf5880b619f29c01dbe76e0f598ff1fad9f9b` and packaging hardening remain unique. Each needs clean successor extraction, and no successor PR is claimed.
- M5 Tasks 1-6 from clean source `141e51e75b2bb337fa3bb1544639c6c46c287309` are normal-restacked locally on final exact M4 predecessor `571cad7877431ac5ab5779b53fe9f7effd6859ce` at local merge checkpoint `d2b8c875c30bb57d5dbdadbef0bd7cf20377aed9`, preserving M4 migration `013` and M5 migration `014`. Focused source/API/contracts and disposable PostgreSQL 17 each passed 182/182, with the actual restart/reconciliation probe also passing. M5 remains provisional, not accepted or delivered: current exact-head package/full verification and final reviews are pending, rootless live-host isolation and a trusted live Git snapshot are blocked, and external/delivery evidence is absent. M6 Task 3 is provisional at `f3b2c0d07116686b27feab4b60166e8a7402d672`; after accepted M5 its migration must move to `015`, and Task 4 is untouched.
- M7 `c8b450f494b3d44b580556c6a612b21a3a780368` remains synthetic-only. M8 Task 1 is `5735e762b8d7571887f6fa4ac9cf10cd1fad1954`; Tasks 2-3 and factual cohort/activation gates remain absent. M9 Task 1 is source-only at `000301796ac19c518ede110b97b9de09dc077cbd`, without real signed input, environment/recovery proof or production authority. None of M5-M9 is accepted or delivered.
- PR #19 delivered the optional SEO side project to `main` as `8ab4e57038dec2e07f01aaa0b207813a387358f4`; it is non-milestone work and is no longer an open continuation item.
- The hard deadline is **2026-09-08 00:00 UTC+3**; it does not waive dependency order, signed scopes, the M8 cohort or external exact-SHA authority.

Machine-readable handoff: [`PROJECT_STATE.json`](PROJECT_STATE.json).

## Bootstrap from a clean clone

1. Start on the default branch and read, in order:
   - `START_HERE.md`
   - `PROJECT_STATE.json`
   - `AGENTS.md`
   - `decisions.md`
   - `mistakes.md`
   - `DARK_FACTORY_ROADMAP.md`
   - `README.md`
2. Run `git fetch --all --prune` before reasoning about active branches or pull requests.
3. Inspect `PROJECT_STATE.json`, then PRs #10, #11, #17 and #21 plus the named M4-M9 local branches with their exact base/head SHAs before continuing milestone delivery. Treat a merge into another milestone branch or a provisional source branch as integration evidence, not delivery to `main`.
4. If starting a different software-development task, create/resolve the local route first. `.grok-stack/runtime/active-route.json` is runtime state and may legitimately be absent in a fresh clone; do not fabricate it.
5. Follow `AGENTS.md`: one write owner, route-selected analysis/review agents, local verification as evidence, pull-request-only delivery, and external Trust CI as merge authority.
6. Never add GitHub Actions.
7. Never bypass the exact-SHA App-owned Trust CI check.

## What is intentionally not in Git

A clean clone contains all source, contracts, roadmap, durable change artifacts, runbooks, public operational facts, and agent handoff needed to understand and continue development. It intentionally does **not** contain secrets or machine-local runtime material, including:

- `.env` files and credentials;
- GitHub App private keys;
- human approval private keys;
- Trust CI signing keys or trust-store private material;
- PostgreSQL runtime state;
- temporary approvals/receipts under runtime directories;
- host-local Docker/socket overlays and other machine-specific deployment scratch.

Do not try to reconstruct missing secrets from repository history or chat. Public/operator-safe deployment facts belong in `engineering/runbooks/`; secrets remain outside Git.

## Live Trust CI orientation

The source and runbooks for the independent merge authority are under `trust-ci/` and `engineering/runbooks/`. The live CI host is `claw`; its public inbound GitHub App webhook reaches the service through the documented Tailscale Funnel, while the API listener itself is loopback-bound on the host. These are operator-safe facts only; credentials are not repository content.

Before changing Trust CI behavior, read the current deployed-policy/holdout constraints in `AGENTS.md` and the activation/rollout runbooks. Repository code cannot itself alter deployed trust material.

## Current milestone delivery handoff

Use one repository-level delivery ledger and one consolidated continuation route. Existing branches are evidence and integration inputs; their names, local `ready` files and GitHub `MERGED` labels do not prove protected-main delivery.

1. Treat `2.0.14` as the current local provisional M5 source identity only, normally restacked on final local M4 predecessor `571cad7877431ac5ab5779b53fe9f7effd6859ce`. Run fresh exact-head M5 verification and reviews; M4's passing local receipts do not transfer to this M5 tree.
2. Only after explicit branch/PR authorization may M4 be pushed as a clean successor; it remains undelivered until `adaptive-trust-ci/verified@06ecf1c875bc` succeeds on the exact PR head and protected merge completes. Preserve PR #21's unresolved GitGuardian FAILURE metadata without inspecting or dismissing the finding.
3. Preserve contiguous `013_persisted_infrastructure_retry_limit.sql` + `014_execution_plane.sql` and rerun checksum/upgrade/restart evidence on the exact M5 candidate; prove rootless live-host isolation and the trusted live Git snapshot before any acceptance claim.
4. Keep M6 Task-3 head `f3b2c0d07116686b27feab4b60166e8a7402d672` quarantined until accepted M5; then move provisional migration `014` to `015`, regenerate checksum/upgrade/restart evidence, restack/review Tasks 1-3, and continue with untouched Task 4.
5. Restack M7 provisional synthetic source `c8b450f494b3d44b580556c6a612b21a3a780368` only after M6 acceptance; require runtime and real-outcome evidence before any M7 acceptance claim.
6. Continue M8 from provisional Task-1 head `5735e762b8d7571887f6fa4ac9cf10cd1fad1954` without treating synthetic fixtures as a factual trust profile or 30-real-task cohort; Tasks 2-3, activation and acceptance remain gated by accepted M7.
7. Keep M9 source-only Task-1 head `000301796ac19c518ede110b97b9de09dc077cbd` non-authoritative until later tasks, real signed inputs, an environment, recovery proof and the required human production authority exist.
8. Retain open PRs #12, #13, #15 and #21 plus the unresolved PR #14/local work identified in `PROJECT_STATE.json`; extract unique work through clean successors without claiming those successors exist. PR #17 is a closed exact duplicate of #21, and PR #19 is already delivered with its predecessor staging path archival.
9. After every protected-main merge, fetch remote refs, update the one state model, and obtain fresh exact-head verification/approvals for every branch made stale by the base change. `origin/milestone/a-plus-autopilot` remains design input, not the current M8 source branch.

## No chat dependency

A new agent must be able to continue from GitHub alone. If a future decision, blocker, milestone handoff, or non-secret operational fact matters to the next agent, commit it to the repository or the active pull request before ending the session. Chat is the lowest-priority source of truth.
