# Fresh-agent bootstrap

The current `2.1.0` branch is a source-only release candidate. Its BB, rotator, VibeVM, FPF, prediction, and Linux setup contours are default-off and not live-qualified; U4/macOS, artifacts, publication, deployment, and activation are excluded. The immutable published release remains `v2.0.19`.

This file is the zero-context entrypoint for any new agent, human, Codex/Grok/Claude session, or clean clone of this repository. Do not depend on chat history to continue the project.

## First action: measure resources and schedule independent work

**Step zero, before all other startup work:** complete and record CPU/capacity discovery before inspecting backlog/routes, planning dependencies, spawning agents or running heavy commands. Store the snapshot locally first and attach it to the active package after routing. Follow the [mandatory startup algorithm](AGENTS.md#mandatory-startup-algorithm-measure-then-dispatch):

1. Measure physical/online logical topology (`lscpu`, `nproc --all`), current capacity (`nproc`) and affinity. Resolve actual cgroup membership/mounts, effective cpuset and finite quota, including ancestor limits.
2. If permitted and appropriate, run a bounded child-only affinity-widening probe over verified CPU IDs, then inspect the child's affinity and limits. Derive effective CPU capacity from allowed online CPUs, cpuset and quota; unknown bounds require a conservative choice. Record timestamp, commands/results, bounds and chosen capacity in the active package, and remeasure when the environment changes.
3. Only after recording effective capacity, inspect the repository handoff/backlog/routes, build dependencies and dispatch all independent route-permitted work in parallel after its prerequisites. Spread eligible heavy child work over measured capacity without oversubscribing it. The observed host had **14 physical cores / 28 logical CPUs**; default affinity could expose 22, while `taskset -c 0-27 nproc` exposed 28 in a verified child. These are dated September 26 observations, not permanent guarantees.
4. Count agent slots separately: the current platform exposes **one controller + 12 child slots**, route `max_parallel_analysis=10` is a separate routing cap, and test workers are separate processes. Use only route-selected agents. Then keep one writer per isolated task/route/branch/worktree; independent isolated writers may run concurrently. Verification and delivery gates follow implementation.
5. Treat an explicitly delegated exact isolated-branch push before verification as **UNVERIFIED transport only**, with its exact local action/resource grant and unverified handoff label. Direct push to protected/shared branches remains forbidden. Merge requires a PR, App-owned exact-head Trust CI and all required approvals.

## Second mandatory startup step: select the verification scope

After the capacity snapshot and route/dependency scheduling above, but before verification-heavy work, invoke `python3 scripts/grok_verify.py --mode pr` using the verified CPU allocation. The merged issue #205 / PR #207 [closed selector](.grok-stack/adaptive_grok/verification_scope.py) computes scope from the trusted exact base..HEAD plus staged, unstaged and untracked inventory/statuses; use the actual agreed PR base, not a shortened range that hides changes.

Its closed focused inventory admits the named docs/state paths, tracked `packages/**` release bytes, and exactly five binding test modules: `tests/test_structure.py`, `tests/test_project_state.py`, `tests/test_manifest_package.py`, `tests/test_workflow_sources.py` and `tests/test_repo_router.py`. For that admitted inventory, `docs-state-focused` skips the replaced full-discovery runner, coverage and `factory-postgres-exit`, not factory-unit or the other selected checks. All other executable changes (including factory/database/schema/contract/selector changes), non-admitted paths or ambiguous inventories require the full suite; "factory unaffected" is not a separate shortcut. Historical measurements were **629 s serial Core coverage versus about 14 s for the five focused modules**, not the complete verifier or a future timing guarantee.

Record exact base/head, dirty paths, profile/reason, changed-path digest and all skipped checks. Do not call skips passes or reuse: references to prior component evidence must retain their original exact Git identities and scope and be explicitly marked historical/reused; they grant no additional skips or current completion. `--full-scope` forces full. Independent review and the external exact-SHA App-owned Trust CI plus approvals remain mandatory; see [the complete startup rule](AGENTS.md#second-mandatory-startup-step-select-verification-scope-before-heavy-work).

## Current project state

Snapshot: **2026-09-24**. Repository `main` was observed at release-sync merge `3f41be92161fef451a2dfa7451eb458ce8f022b3` (PR #189); fetch refs before assuming it is still the tip.

- **Candidate:** product identity `2.0.19` has a merged release-sync parent `3f41be92161fef451a2dfa7451eb458ce8f022b3` and a separate artifact-child candidate carrying a twice-reproducible ZIP (`4176a872…`) and sidecar (`77057e0b…`). The latest published release remains `v2.0.18`, target `e7d0f72bf834b75eb543d9424ee47c7829cc65c0`, tag object `31d3171f651ea77e29de58d4affc58d008f1c7a5`, ZIP `0bc6adc9f4660e1b60be4cb4895e97f2641338b52b6a5e05ac3c7acd85e59b3a`; it and `v2.0.17` stay immutable. The `v2.0.19` tag and GitHub Release remain absent until the exact artifact-child merge and delegated publication steps.
- **Source:** M0-M9 implementation is delivered. The seven-slice L5 production runtime landed through PR #75, with a [delivery ledger](engineering/reviews/l5-delivery-stack.json); the durable Qwen→Grok→OpenAI→Claude→OpenRouter failover arrived through PR #91 and the workflow artifact adapters plus the `workflow_sources` upstream version contract through PR #93 (change `20260915-update-third-party-workflow-components-superpowe-1b0c02`), all of them inside the observed source named above. Source defaults keep provider execution off.
- **Historical runtime (September 15–16):** on Claw, Qwen primary `adaptive-l5.service` at `5f6f6ce1ecb0cef8e1b3910b037af983c5fb8f8a` and Grok secondary `adaptive-l5-grok.service` at `61a05da2bd0c9fb09db5307f53ebc99e4e94040d` were active and enabled. Both have authenticated `artifact_ready` evidence; Grok took **29.852 s** with `live_url=null`. Read the [dated runtime observation](engineering/runbooks/l5-runtime-observation-2026-09-15.md) for exact boundaries.
- **Latest runtime operation (September 19):** primary Qwen is accepted at `f12807c2b75750072ba768fc95ed492362ae6489` / `qwen-omni-intl`: one POST, `artifact_ready` in 4.991 s, usage 766/195, separate zero-POST readback. Grok stays accepted at `26a0d3d`; separate Omni remains unchanged. All three units are active/enabled. Read the [successful continuation record](engineering/runbooks/l5-primary-continuation-2026-09-19.md). The earlier failure/rollback remains historical, not the current installation.
- **Next unmet outcomes:** a full external pilot with maintainer acceptance, an exact-profile M8 qualifying cohort and activation, and general M9 operational qualification. The live L5 result proves bounded artifact generation, without proving these outcomes or factory publication of a public site.
- **Merge authority:** App-owned `adaptive-trust-ci/verified@06ecf1c875bc`, GitHub App ID `4694114`, on the exact up-to-date PR head. The deployed Trust CI service is separate from L5; repository tests and runtime success do not replace it.
- **Active delivery:** complete #165/#163/#118 and the capacity subset of #62 on `fix/factory-tooling-batch-20260921`, route `cf23849faca6`, following the [19-path integration plan](engineering/changes/20260921-fix-the-combined-source-delivery-of-issue165-int-cf2384/brief.md). PR #173 actually merged at 11:27:32 UTC after App-owned success, closing #147/#148/#153/#156/#161/#162/#166/#168; drafts #171/#172 are closed as superseded. The generated current-main route preserves all five static analyses and original candidate failures/results. The sole selected data implementer completed the exact imports; initial integrated verification passed877root tests/1426subtests and804factory/PostgreSQL cases with2conditional skips. All five independent source reviews passed; final frozen-tree verification, current receipts and external delivery remain pending. Keep #62 open for bounded App Check Run command output; #158 and trusted-validator compatibility remain separate. Historical delivered work includes PR #12 and the optional SEO side project PR #19.

Machine-readable handoff: [`PROJECT_STATE.json`](PROJECT_STATE.json). `latest_source_observation` names the merged release-sync parent, `active_source_delivery` names the factory/tooling successor, and `active_operation_delivery` records the delivered PR151 operation; `latest_runtime_operation` records the newest installation outcome; top-level `observed_at`/`observed_main_sha` and `active_delivery` now describe the artifact-child stage of the pending `v2.0.19` chain; `runtime_observations` preserves the historical service observation, `published_release` binds immutable `v2.0.18`, and `operational_qualification` records unproven outcomes. `current_unreleased_change` and `local_candidate` record the delivered v2.0.19 bytes and the still-pending tag/Release; `delivered_change_history.post_v2_0_18_landing` lists the twenty PRs merged after the last publication, while the earlier release rows remain immutable. A release chain's own commits are not landing rows: the release-sync and artifact-child commits are identified by `current_unreleased_change` and `local_candidate`; publication is recorded only after the exact artifact-child merge.

The earlier [dated backlog](engineering/changes/20260921-research-open-backlog-map-each-item-to-its-sourc-d54d3a/issue-queue.json) remains historical; the latest recorded counts and scope live in `PROJECT_STATE.json` (its nested issue inventory is dated separately). The [accepted CI ingress operation](engineering/changes/20260921-fix-production-trust-ci-webhook-ingress-and-rest-68274/evidence/operational-acceptance.md) restored actual GitHub intake; [PR #173 delivery](engineering/changes/20260921-fix-the-combined-source-delivery-of-issue165-int-cf2384/evidence/pr173-delivery.json) records the later external result. Separate #158 source has focused and complete Trust CI suite evidence but still needs current-main integration, the full route gate, reviews and eventual separately authorized live acceptance.

## Bootstrap from a clean clone

1. Start on the default branch and read, in order:
   - `START_HERE.md`
   - `PROJECT_STATE.json`
   - `AGENTS.md`
   - `decisions.md`
   - `mistakes.md`
   - `DARK_FACTORY_ROADMAP.md`
   - `README.md`
2. Run `git fetch --all --prune` before reasoning about active branches or pull requests.
3. Inspect `PROJECT_STATE.json`, its dated source/runtime/release observations, the open-work inventory and [runtime runbook](engineering/runbooks/l5-production-runtime.md). Historical milestone branches and release-preparation records are evidence, not current continuation instructions.
4. If starting a different software-development task, create/resolve the local route first. `.grok-stack/runtime/active-route.json` is runtime state and may legitimately be absent in a fresh clone; do not fabricate it.
5. Follow `AGENTS.md`: measured parallel-first scheduling, one write owner per isolated task/route/branch/worktree, route-selected agents, local verification as evidence, and PR-only merge through external Trust CI and required approvals. Explicitly delegated pre-verification branch transport remains labelled UNVERIFIED.
6. Never add GitHub Actions.
7. Never bypass the exact-SHA App-owned Trust CI check.

## What is intentionally not in Git

A clean clone contains all source, contracts, roadmap, durable change artifacts, runbooks, public operational facts, and agent handoff needed to understand and continue development. It intentionally does **not** contain secrets or machine-local runtime material, including:

- `.env` files and credentials;
- GitHub App private keys;
- human approval private keys;
- Trust CI signing keys or trust-store private material;
- PostgreSQL runtime state;
- temporary approvals/receipts under runtime directories;
- host-local Docker/socket overlays and other machine-specific deployment scratch.

Do not try to reconstruct missing secrets from repository history or chat. Public/operator-safe deployment facts belong in `engineering/runbooks/`; secrets remain outside Git.

## Live Trust CI orientation

The source and runbooks for the independent merge authority are under `trust-ci/` and `engineering/runbooks/`. The live CI host is `claw`; its public inbound GitHub App webhook reaches the service through the documented Tailscale Funnel, while the API listener itself is loopback-bound on the host. These are operator-safe facts only; credentials are not repository content.

Before changing Trust CI behavior, read the current deployed-policy/holdout constraints in `AGENTS.md` and the activation/rollout runbooks. Repository code cannot itself alter deployed trust material.

## Current milestone delivery handoff

1. Continue from fetched source and the dated state model. M0 is delivered and live; M1-M9 are delivered repository source. Keep their historical exact-head evidence and migrations `001`-`018` intact.
2. Preserve tag-bound ZIPs and sidecars for `v2.0.16`, `v2.0.15`, `v2.0.14` and `v2.0.13`; the machine-readable release records carry their hashes. Documentation successors do not rebuild released artifacts.
3. Treat the installed Qwen and Grok service SHAs separately from the latest source and release tag. Source defaults remain off; these observed instances were explicitly enabled. New provider, installation, publication or hosting effects require their own exact authority.
4. To continue the external pilot, start with the [September 21 target investigation and successor issue draft](engineering/changes/20260920-fix-issue-155-guards-inside-the-semantic-bind-re-c4e47e/next-pilot/README.md). The old issue targets an obsolete site, and its PR was closed unmerged. Current target `6226aa0` has a reproduced browser-audit coverage gap for two Russian pages. Route a separate successor profile/gate change around that bounded task; the [delivered pilot package](engineering/changes/20260905-feature-implement-a-single-operator-codex-github-0ce2d6/brief.md) and [pilot runbook](engineering/runbooks/design-partner-pilot-v2.0.15.md) remain historical context. Record the actual result and maintainer acceptance. Earlier blocked attempts and fake/local tests cannot substitute for that outcome.
5. Do not mark M8 active without its factual qualifying cohort and activation record. General M9 qualification requires signed inputs, the applicable environment/provider deployment, exercised recovery and human production authority. The bounded L5 runtime observation does not supply those gates.
6. Refresh exact head/base and required external checks before extracting or delivering retained PR work. After every protected-main merge, update the dated state and recheck branches whose base changed. Never promote a historical success into current authority.

## No chat dependency

A new agent must be able to continue from GitHub alone. If a future decision, blocker, milestone handoff, or non-secret operational fact matters to the next agent, commit it to the repository or the active pull request before ending the session. Chat is the lowest-priority source of truth.
