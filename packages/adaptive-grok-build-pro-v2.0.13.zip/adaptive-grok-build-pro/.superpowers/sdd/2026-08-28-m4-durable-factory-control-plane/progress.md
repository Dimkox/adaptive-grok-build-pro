# SDD ledger — plan: docs/superpowers/plans/2026-08-28-m4-durable-factory-control-plane.md

Recovery state 2026-09-02: original M4 plan tasks are implemented through historical source `460a8a0`; current-main integration candidate advanced through `01a10f5`, `aee6558`, and `d31a4ad`.
Final exact-head verifier at `d31a4ad` passed 14/14, but independent code review failed with three Important trust-gate findings; evidence is therefore not merge-ready.

| Work pair | Producer / consumer | Preflight finding |
| --- | --- | --- |
| committed-range verifier / hygiene gates | `_git_range_selection` supplies route and PR ranges to changed-file and diff-check gates | Multiple merge bases and absent PR target must fail closed. |
| architecture inventory / drift gate | repository inventory supplies paths to undeclared-source and unsafe-artifact checks | Untracked verifier `.venv` may be ignored, but tracked descendants must remain visible. |
| repair / final review wave | focused RED→GREEN repair produces one new exact HEAD consumed by all reviewers | Every prior review/receipt becomes stale after repair. |

Repair complete: `da7ec8d7d40f52663aba1ff59bf03ccf209395b0`, tree `e8689c9daa100909c1703a34844419956cca4b14`.
Review finding 1: tracked `.venv` descendants hidden — repaired with observed RED and focused GREEN.
Review finding 2: ambiguous merge bases accepted — repaired with observed RED and focused GREEN.
Review finding 3: missing PR target fails open — repaired with observed RED and focused GREEN.
Independent controller focused verification: 113/113 PASS in 114.699s.
Exact code-head full verifier: 14/14 PASS, changed-file union 469, tree fingerprint `65fd26f975e3b53b07d7fed8dd625b4cd5f37e730287c9da3f40e9bffb8ad7d0`.
Current task: factual README/roadmap/bootstrap/state/schedule refresh before the final verifier and five-review wave.
