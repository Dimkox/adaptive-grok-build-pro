# SDD ledger — plan: engineering/changes/20260831-implement-a-new-m4-application-feature-on-exact-b7f288/tasks.md

Base: `67714a1f1b87effcfabe55d5ca2770d0a68d17c1`.

Execution ruling: M4's PostgreSQL schema, store, service, API, CLI, contracts, and integration tests are tightly coupled vertical work under route-selected single write owner `integration_implementer`; execute them as one batched implementation task, then apply all five route-selected independent whole-branch reviews. Cost if wrong: a broad fix wave may be needed instead of smaller task-local repair loops.

Preflight interface scan pending the write owner's finalized task breakdown; no product edit may precede corrected route-base binding and approved package state.
