# Requirements — working 2.0.6

## Acceptance

- [ ] Marker-less tree still runs `python-unittest` (Ruff present or absent)
- [ ] `ruff` runs without packaging markers; missing binary → skip; CI fail-closed after install
- [ ] `bandit` does not replace `secret-scan`; planted `eval` in product paths fails; planted `eval` in `tests/` does not
- [ ] Coverage measured this session; `fail_under = floor(line%) - 2`; no 90% invention; `fast` does not fail-under
- [ ] Dependabot `.github/dependabot.yml` is `github-actions` only
- [ ] Semgrep / Trivy / npm prettier|format do not appear on this tree
- [ ] `VERSION` is `2.0.6`; CHANGELOG `## 2.0.6`; README H1; packages zip + sha256
- [ ] No `pyproject.toml` / `requirements.txt` / `setup.py`
- [ ] CI template and `.github/workflows/adaptive-grok.yml` stay byte-identical
- [ ] No tag / push / `gh release`

## Non-goals

Dobryakov dump, Codecov, `trivy image`, `semgrep --config auto`, `npx` without a script, Bucket C SaaS.
