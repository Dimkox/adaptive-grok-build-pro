# Requirements

- [ ] No `.github/workflows/` files
- [ ] No `.github/dependabot.yml`
- [ ] `install_into --with-ci` does not write a workflow (exits with forbidden)
- [ ] Tests lock the ban
- [ ] `python3 scripts/grok_verify.py --mode pr` PASS
- [ ] Zip rebuilt; in-zip VERSION 2.0.6; no workflow in zip
- [ ] GitHub Latest v2.0.6 after last mile
