# Tasks

- [ ] Analysis
- [ ] Remove GHA + lock tests
- [ ] Rebuild 2.0.6 zip
- [ ] grok_verify --mode pr
- [ ] Independent reviews
- [ ] Publish tag + GitHub Release v2.0.6
