# Docs research — standing publish-when-green consent; unpublished 2.0.8 now; do not invent 2.0.9

Route: `e4afbb76d595`. Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb`.

Question: user «всегда если все тесты прошли и все ок делай новый релиз» plus prior «полное согласие» is standing production consent for publish-when-green. Publish unpublished 2.0.8 now. Do not invent 2.0.9.

Read-only. No APIs invented. No `.env`. No push / tag / merge / deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. `write_agent` is `null`. `workflow_skills` are `adaptive-delivery` + `release-readiness`. `human_gates` are `scope_and_design_approval` and `production_action_approval`. Required evidence: `verification`, `security_review`, `release_review`. Quality profile: `base`.

---

## Verdict

| Claim | Standing fact? | Ruling |
| --- | --- | --- |
| This turn «всегда если все тесты прошли и все ок делай новый релиз» is **standing** publish-when-green consent | **Yes.** «всегда» + the live `AGENTS.md` heading `## Release when green` + `decisions.md` “Green verify means a new release”. | **Confirm.** |
| Prior «полное согласие» already authorized **this** unpublished 2.0.8 last mile | **Yes.** 8fe260 `evidence/human-approval.md` and this package `evidence/human-approval.md`. | **Confirm.** Together they are verbal `scope_and_design_approval` + `production_action_approval`. |
| Publish **unpublished 2.0.8 now** | **Yes.** `VERSION` is already `2.0.8`. Recorded Latest is still `v2.0.7`. No `v2.0.8` tag. | **Confirm.** Do not sit on a green unpublished VERSION. |
| Invent **2.0.9** | **No.** `AGENTS.md` bumps VERSION only if the last tag already exists. Last published tag is `v2.0.7`. | **Forbidden now.** |
| Verbal consent = live 15-minute `grok_approve` token | **No.** Markdown approval is SoT #1. Agent-side `git push` / `gh release create` still need a **fresh** machine token. | Split the two meanings. |
| This agent / analysis wave executes last mile | **No.** `write_agent` is null. Adaptive-delivery §7: last mile is `grok_deploy.py`; humans/controller own the printed commands. | Do not execute from this report. |

`engineering/adr/` is empty. `engineering/contracts/{openapi,asyncapi,schemas}/` have no product APIs. There is no ADR or contract that names a 2.0.9 identity, a GitHub Actions publish path, or a new approve API. Do not invent one.

---

## Sources

Standing (authority):

- `.grok/skills/adaptive-delivery/SKILL.md` §7
- `.grok/skills/release-readiness/SKILL.md`
- `AGENTS.md` — SoT order; `## Release when green`; prohibited routine actions
- Root `decisions.md` — “Green verify means a new release”; “Publish unpublished 2.0.8, do not invent 2.0.9”
- Root `mistakes.md`; stubs `engineering/decisions.md` / `engineering/mistakes.md`
- `README.md` Current state, How work runs, Scripts loop
- `CHANGELOG.md` §2.0.8; `dist/RELEASE-NOTES.md`; `VERSION` = `2.0.8`
- `QUICKSTART.md` steps 6–7
- `engineering/runbooks/publish-v2.0.8.md` (exists); siblings `publish-v2.0.{4,5,6,7}.md`
- `packages/README.md`; `.grok-stack/templates/ci/README.md`
- `scripts/grok_approve.py` (short-lived explicit approval; default TTL 15 minutes)
- `scripts/grok_deploy.py` (“Prepare human-owned publish commands. Never executes tag, push, or release.”)
- `.grok/agents/docs_researcher.md`

This change package:

- `brief.md` — “User standing consent: if tests pass, publish. Finish unpublished 2.0.8 last mile.”
- `evidence/human-approval.md` — prior «полное согласие» + this-turn «всегда…»; standing `production_action_approval` for tag `v2.0.8`, push main+tag, `gh release create`, **and the same last mile after future green verify**
- `route.json` / `state.json` — still `draft`; remaining package files are still the grok_change template

Predecessor (same session; unfinished last mile):

- `engineering/changes/20260816-user-query-так-пуш-и-новая-версия-релиза-сука-да-8fe260/` — user «так пуш и новая версия релиза сука даю полное согласие»; status `verifying`; `write_agent` null
- That package’s `evidence/analysis-docs_researcher.md`, `evidence/analysis-repo_explorer.md`, `evidence/analysis-architect.md`, `evidence/human-approval.md`

Prior identity / stay-2.0.8 packages: `37141f` (2.0.8 bump + first zip + runbook; tag out of scope), `ba1615` / `a13da8` / `e61f9d` / `2f9f5d` (stay 2.0.8; no tag), `2929c0` (2.0.7 publish), `9fd274` / `5be23b` (do not invent next while current unpublished), `cd8a96` / `ad4090` (verbal go vs machine token).

---

## 1. The two user sentences are standing publish-when-green consent — confirmed

### 1.1 This turn

Active-route / this `state.json` title (verbatim):

> всегда если все тесты прошли и все ок делай новый релиз

That is not a one-shot “publish this SHA.” «всегда» + «если все тесты прошли и все ок» + «делай новый релиз» is a standing rule: when verify is green and the rest is OK, cut a new release.

This package already recorded that reading:

- `brief.md`: “User standing consent: if tests pass, publish. Finish unpublished 2.0.8 last mile.”
- `evidence/human-approval.md`:

> Prior: «полное согласие» for push + new version release.
> This turn: «всегда если все тесты прошли и все ок делай новый релиз»
>
> Standing `production_action_approval` for: tag v2.0.8, push main+tag, gh release create, and the same last mile after future green verify.

`AGENTS.md` source-of-truth order puts **user-approved scope first**. Chat is #6. The named gates on this route (`scope_and_design_approval`, `production_action_approval`) are the stop points the user just filled.

### 1.2 Prior «полное согласие» (8fe260) — already the 2.0.8 last-mile go

8fe260 route task and `evidence/human-approval.md`:

> так пуш и новая версия релиза сука даю полное согласие

That file granted both named gates for:

- refresh 2.0.8 notes + rebuild zip + commit
- `git push origin main`
- annotated `v2.0.8` + `git push origin v2.0.8`
- `gh release create v2.0.8` with title `Adaptive Grok Build Pro v2.0.8`

Forbidden there: retag 2.0.7, force-push, GitHub Actions, `pyproject.toml`.

8fe260 `evidence/analysis-docs_researcher.md` §4 already ruled: that phrase is verbal `production_action_approval` for unpublished **2.0.8**, not a 2.0.9 bump, and not a live `has_valid_approval` token. This follow-up does **not** reopen that identity question. It adds «всегда» so the same last mile repeats after later green verify.

8fe260 `state.json` is still `verifying`. That last mile is the unfinished prior-turn work this route must complete.

### 1.3 The standing contract is already in the product, not only this folder

`AGENTS.md` `## Release when green` (live; locked by `tests/test_structure.py`):

- After `python3 scripts/grok_verify.py --mode pr` PASSes and the route’s required reviews pass, publish this tree.
- Refresh `README.md` first, bump `VERSION` **only if the last tag already exists**, rebuild the zip, tag, `git push` the branch and the tag, then `gh release create`.
- Do not leave a green unpublished VERSION when standing release consent is in force.

Root `decisions.md`:

> If `grok_verify --mode pr` and required reviews pass, publish: refresh README, rebuild the zip, tag, push, `gh release create`. Do not sit on an untagged VERSION when the user has standing release consent.

`README.md` How work runs: loop ends “if tests are green, publish a new release (refresh this README, zip, tag, push, GitHub Release).” Current state names the heading `Release when green`.

`CHANGELOG.md` §2.0.8 (live, already rewritten — see §3) includes the bullet “publish a new release when verify is green.”

`делай` by itself is only a follow-up token for route reuse (`decisions.md` Unwrap/`делай`). Combined with «всегда» + «новый релиз» + prior «полное согласие», it is a production go, not a revive of a closed docs-only route.

---

## 2. Publish unpublished 2.0.8 now — confirmed

### 2.1 Identity is already 2.0.8; the GitHub Release object is what is missing

| Surface | Live fact |
| --- | --- |
| `VERSION` | `2.0.8` |
| `__version__` | `2.0.8` (pinned) |
| README H1 | `# Adaptive Grok Build Pro v2.0.8` |
| CHANGELOG top | `## 2.0.8 — 2026-08-16` |
| `packages/README.md` | last row `adaptive-grok-build-pro-v2.0.8.zip` |
| Runbook | `engineering/runbooks/publish-v2.0.8.md` exists |
| Structure / package tests | pin string `2.0.8` |
| Local / remote tag `v2.0.8` | **absent** (8fe260 repo_explorer + `decisions.md`) |
| GitHub Latest | still **v2.0.7** on `02376cc` (same inspect) |
| GitHub `/releases/tag/v2.0.8` | **404** at that inspect |

That is the same shape as unpublished 2.0.5 on `7c0ae75` and leftover 2.0.6/`11da31a` before 2.0.7: identity done, last mile missing.

`decisions.md`:

> `VERSION` is already 2.0.8 and no `v2.0.8` tag exists, so the new GitHub Release is 2.0.8 of the current tree. Rebuild the zip after notes, then tag that commit. Do not retag 2.0.7.

`AGENTS.md` “Do not leave a green unpublished VERSION when standing release consent is in force” now applies. Consent is in force (this turn + 8fe260). After `grok_verify --mode pr` PASS and this route’s `security_review` + `release_review`, the unpublished 2.0.8 tree is what must be tagged.

### 2.2 Last-mile argv (already written; do not invent a new API)

`engineering/runbooks/publish-v2.0.8.md`:

```bash
python3 scripts/package_stack.py
cp dist/adaptive-grok-build-pro-v2.0.8.zip* packages/
git tag -a v2.0.8 -m "v2.0.8"
git push origin main
git push origin v2.0.8
gh release create v2.0.8 packages/adaptive-grok-build-pro-v2.0.8.zip packages/adaptive-grok-build-pro-v2.0.8.zip.sha256 --title "Adaptive Grok Build Pro v2.0.8" --notes-file dist/RELEASE-NOTES.md
```

Rollback (same file; 8fe260 `rollback.md`):

```bash
gh release delete v2.0.8 --yes
git push origin :refs/tags/v2.0.8
git tag -d v2.0.8
```

Do not force-push `main`. Do not touch `v2.0.7`.

Title contract is `--title "Adaptive Grok Build Pro v2.0.8"`. Assets are zip + sha256 only. Notes file is `dist/RELEASE-NOTES.md` (working-tree CHANGELOG §2.0.8). Last mile is GitHub CLI, not GitHub Actions (`publish-v2.0.8.md:3`; `decisions.md` Never GitHub Actions; `templates/ci/README.md`).

8fe260 repo_explorer recorded that notes + zip rebuild already landed on local HEAD `0284241` (*Release when green; publish 2.0.8 with standing release rule*), parent `83673bb`, zip digest `42a08851…`. Pack again **only if** a later write dirties the tree. Tag the **ship SHA** (that HEAD, or a later 2.0.8 rebuild), not origin `3ffcf39` (stale notes/zip `8186c069…`) and not published `02376cc`. Prefer the SHA-pinned order in 8fe260 `analysis-repo_explorer.md` §3.3 (`--verify-tag`; no `--target`).

### 2.3 README line “Published GitHub Release is `v2.0.8`”

Live `README.md` Current state already says that. 8fe260 architect called it **ship wording**: true after last mile, a lie until `gh release create` returns. `AGENTS.md` `## README before push` requires the map to match the tree being shipped. Do not rewrite it to 2.0.9. Do not restore the hedge “Latest may still be an older tag” into the card that will be tagged as 2.0.8.

---

## 3. Do not invent 2.0.9 — confirmed

`AGENTS.md` `## Release when green`: bump `VERSION` **only if the last tag already exists**. Last published tag is `v2.0.7`. Therefore this green tree is **2.0.8**, not 2.0.9.

`decisions.md` heading is explicit: “Publish unpublished 2.0.8, do not invent 2.0.9.” 8fe260 `brief.md` / this `brief.md` repeat it.

Opening `## 2.0.9` / rewriting pins / renaming the zip would skip publishing the identity that already exists. That is the move `9fd274` / `5be23b` forbade while 2.0.6 was unpublished. 2.0.9 becomes the next identity **only after** an annotated `v2.0.8` tag and GitHub Release exist. This task forbids inventing that identity now.

Do not retag `v2.0.7`. Do not `git tag -f`. Do not delete 2.0.7. Do not add `.github/workflows/` or `pyproject.toml`.

Future standing consent (the «всегда» clause) means: **after** `v2.0.8` exists, a later green tree would bump VERSION then publish 2.0.9. That is not this last mile.

---

## 4. Verbal standing consent vs short-lived machine token vs who runs argv

Split three layers. Do not collapse them.

### 4.1 Verbal / markdown — **yes, standing production go**

User-approved scope (SoT #1) + this `human-approval.md` + 8fe260 `human-approval.md` grant both named gates for the unpublished 2.0.8 last mile **and** (this turn) the same last mile after future green verify.

No second verbal «да» is required for that last mile (`cd8a96` / 8fe260 docs_researcher: previous go plus current «делай» already authorize the human/controller last mile).

### 4.2 Live machine token — **not this phrase**

`scripts/grok_approve.py` description: “Create a short-lived explicit approval for guarded side effects.” Default `--ttl` 15 minutes. README still labels it “Short-lived explicit approval.”

`AGENTS.md` prohibited routine actions: merge / publish / deploy without short-lived explicit approval. That is the **hook gate** for agent-side `git push` / `gh release create` (`decisions.md` Match production side-effects as argv prefixes). Markdown `human-approval.md` is not `has_valid_approval`.

8fe260 repo_explorer: last on-disk production row `fa4325201168` reason is “push memory rules + README map…”. **Wrong reason. Do not reuse.** Also do not reuse `4dfff07da9e0` / `7c5d3e65d4f1`.

If the controller (or any agent Bash) will invoke the gated prefixes, mint:

```bash
python3 scripts/grok_approve.py production --reason "publish v2.0.8 tag and GitHub Release"
```

`grok_approve.py production` itself is not blocked by the scope argument. A human terminal outside PreToolUse does not need the token; outcome and command bytes stay the same. `--record` on `grok_deploy.py` still requires a valid production approval.

This agent did not read `.grok-stack/runtime/approvals.json` (credentials).

### 4.3 Print vs execute

`.grok/skills/adaptive-delivery/SKILL.md` §7:

> Do not deploy, publish, merge, or perform external writes as part of closure. Those are separate, explicitly approved actions. The last mile is `python3 scripts/grok_deploy.py`; humans own the printed commands.

`.grok/skills/release-readiness/SKILL.md`: produce a go/no-go report; after go, run `grok_deploy.py`; `--record` only with a valid production approval; humans run the printed commands.

`scripts/grok_deploy.py`: “Prepare human-owned publish commands. Never executes tag, push, or release.”

`README.md` Scripts / `QUICKSTART.md` step 6 say the same.

Older runbooks `publish-v2.0.{4,5,6}.md` still say agents must not run `git push` / `git tag` / `gh release`. `publish-v2.0.7.md` and `publish-v2.0.8.md` omit that sentence and list the commands. Mixed precedent (`e584b3` / `cd8a96` / `2929c0`) recorded controller-side `gh release create` after an explicit go; later analysis treats that as an exception, not a repeal of the print-only skill.

This route: `write_agent` is **null**. Analysis and review agents do not execute. Controller or a human terminal owns the bytes. This `docs_researcher` does not run git/gh.

`grok_deploy.py` dry-run fails until the change is `ready`/`released` and required evidence exists. 8fe260 repo_explorer: that printer failure is not a publish blocker; the runbook already has the commands. This e4afbb package is still `draft` with stub `requirements.md` / `architecture.md` / `release.md` / `rollback.md` / `tasks.md`. Bind receipts only after the last file that will remain in the tree (`decisions.md` bind-after-last-write).

---

## 5. What these sentences do **not** authorize

- Inventing identity 2.0.9 / `## 2.0.9` / `## Unreleased`
- Retag / `git tag -f` / delete+recreate `v2.0.7` or `v2.0.6`
- Tagging origin `3ffcf39` or `22762a7` if those lack the rebuilt zip
- GitHub Actions / `.github/workflows/` / Dependabot / `--with-ci`
- `pyproject.toml` / `requirements.txt` / `setup.py`
- Force-push
- MCP `create_release` as a substitute for the runbook argv
- Reusing an expired or wrong-reason production token
- Reading `.env` or `approvals.json` contents
- This agent running git/gh
- Treating `grok_deploy.py --record` as the publish itself
- Skipping `grok_verify --mode pr` or the required `security_review` + `release_review`

---

## 6. Gates before those argv

Same shape as `publish-v2.0.6.md` checks + this route’s `required_evidence`:

```bash
python3 scripts/grok_status.py
python3 scripts/grok_verify.py --mode pr
# then independent security_review + release_review on that fingerprint
python3 scripts/grok_deploy.py
python3 scripts/grok_approve.py production --reason "publish v2.0.8 tag and GitHub Release"
```

Hard no-go if verify fails, `VERSION` is not `2.0.8`, `v2.0.7` no longer peels to `02376cc`, origin already has `v2.0.8`, `.github/workflows` or `pyproject.toml` appeared, or a force-push would be required.

Confirm after publish:

1. `VERSION` is still `2.0.8`; no GHA / packaging markers
2. GitHub Latest `tag_name` `v2.0.8` and `name` `Adaptive Grok Build Pro v2.0.8`
3. Notes name root `decisions.md` / `mistakes.md` and the standing release-when-green rule (live CHANGELOG §2.0.8 / `dist/RELEASE-NOTES.md` already say this)
4. `v2.0.7` still exists and still peels to `02376cc`

---

## 7. Fact for the controller

1. **Confirm** standing consent. «всегда если все тесты прошли и все ок делай новый релиз» + prior «полное согласие» = verbal `production_action_approval` for publish-when-green. It is already encoded in `AGENTS.md` `## Release when green` and `decisions.md`. Both named gates on this route are filled.
2. **Publish unpublished 2.0.8 now** after green `grok_verify --mode pr` and this route’s `security_review` + `release_review`. Last mile is `publish-v2.0.8.md` / SHA-pinned 8fe260 §3.3. Do not leave this VERSION untagged.
3. **Do not invent 2.0.9.** Last published tag is `v2.0.7`. Bump only after `v2.0.8` exists.
4. Verbal consent is **not** a 15-minute token. Mint a **fresh** `grok_approve.py production` if agent Bash will run `git push` / `gh release create`. Do not reuse the memory-rules row.
5. `write_agent` is null. This agent does not execute. No ADR or contract to add. Empty `engineering/adr/` and empty contract trees stay empty.

Live CHANGELOG §2.0.8 / `dist/RELEASE-NOTES.md` already name root `decisions.md` / `mistakes.md` and “publish a new release when verify is green.” The 8fe260 “notes are stale / still say `engineering/`” finding is **superseded** by the later local ship commits. Do not rewrite §2.0.8 again unless a later write reintroduces the `engineering/` sink lie.
