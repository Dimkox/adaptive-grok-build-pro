# Analysis — architect

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb`  
Route: `e4afbb76d595` · intent=`release` · risk=`high` · `write_agent`=`null`  
Reviews: `security_reviewer` + `release_reviewer`  
Gates: `scope_and_design_approval`, `production_action_approval`  
Evidence: `verification`, `security_review`, `release_review`  
Question: standing rule in `AGENTS.md` `## Release when green` + `decisions.md` entry. Then finish unpublished 2.0.8: rebuild zip after the rule, tag THAT commit, push, `gh release`. write_agent none. User consent.

Read-only. No application-code edits. No `.env`. Architect does **not** push, tag, or `gh release`.

Loaded `/adaptive-delivery` and `/release-readiness`. This agent is in `allowed_agents`. Active change pointer is this `e4afbb` package.

---

## Ruling (one screen)

**Keep the landed standing rule. Do not invent 2.0.9. Do not retag 2.0.7. Ship identity is 2.0.8 of commit `02842413509dc98eaaf104e27f212888f9449826`.**

The user order is two slices that share `AGENTS.md` / `decisions.md`:

1. Standing contract: after `grok_verify --mode pr` PASS **and** the route’s required reviews pass, publish this tree while standing release consent is in force.
2. This unpublished identity: stay on `VERSION` **2.0.8**, rebuild the zip **after** the rule bytes exist, tag **that** commit `v2.0.8`, push `main`+tag, `gh release create`.

`write_agent` is null → adaptive-delivery step 4 has no implementer. Controller is the only actor. Do **not** spawn `general_implementer`.

Both named gates are already granted (`evidence/human-approval.md`): prior «полное согласие» plus this turn «всегда если все тесты прошли и все ок делай новый релиз». This report is design, not a second ask.

| In | Out |
| --- | --- |
| Keep `## Release when green` as the fourth `AGENTS.md` heading | Rewrite or bury it under Bitrix/API |
| Keep `## 2026-08-16 — Green verify means a new release` (≤3 sentences) | A twin decisions entry; `engineering/decisions.md` |
| Tag / Release peel = `0284241` (rule + rebuilt zip) | Tag `3ffcf39` / `83673bbc` / `22762a7`; retag `v2.0.7` |
| Confirm last mile; if already live, **close** this route | Second `gh release create`; bump to 2.0.9 on this same green tree |
| Controller CLI (`git` / `gh`) | Spawn a write owner; GHA; `pyproject.toml` |

`python3 scripts/grok_deploy.py` will fail while this change is `draft` and receipts are stale/missing. That failure is not a publish blocker. Do not run it as the publisher.

---

## 1. Facts inspected this wave

| Item | Value |
| --- | --- |
| Local `HEAD` / `refs/heads/main` | `02842413509dc98eaaf104e27f212888f9449826` — *Release when green; publish 2.0.8 with standing release rule* |
| `origin/main` (after the 0284241 push) | same SHA |
| Route `base_commit` | `3ffcf393a6f17d7c97b80b2d299816a5f96102a8` (two local-then-pushed children: `83673bbc`, then `0284241`) |
| Ancestry after published `v2.0.7` | `02376cc` → `22762a7` → `7152b75` → `ffd30fd` → `fc7b674` → `3ffcf39` → `83673bbc` → **`0284241`** (7 commits on `v2.0.7...main`) |
| `VERSION` / README H1 | **2.0.8**. Do not bump. |
| `AGENTS.md` headings | `[0] Agent self-learning`, `[1] README before push`, `[2] Split large tasks`, `[3] Release when green`, then intro, then `## Mandatory entrypoint` |
| Root `decisions.md` newest entry | `## 2026-08-16 — Green verify means a new release` (two sentences) |
| Structure locks | `test_agents_md_releases_when_green`, `test_decisions_md_records_green_verify_means_release` |
| `0284241` file set | `AGENTS.md`, `CHANGELOG.md`, `README.md`, `decisions.md`, `tests/test_structure.py`, `packages/…v2.0.8.zip` + `.sha256`, this `e4afbb` package (brief + human-approval + templates) |
| Tracked 2.0.8 zip digest | `42a08851f2a6c2844f57fe91ce8a370544b51e683c4ff443fa20bee44da60c52` (changed again in `0284241`, not the `22762a7` digest `26178c7c…`) |
| Local tags | `v2.0.0`–`v2.0.8`. Annotated `v2.0.8` object `695ee7918b6b21cfe5d9bd8d2497067a6a38a594` |
| GitHub `/releases/tag/v2.0.8` | **exists**, 16 Aug 23:34, peels to `0284241`, title Adaptive Grok Build Pro v2.0.8, notes = CHANGELOG §2.0.8 including “publish a new release when verify is green” |
| GitHub `/releases/latest` HTML | still rendered as v2.0.7 / “5 commits” in this agent’s fetch — treat as **stale cache or prerelease leak**. Controller must confirm with `gh`, not this HTML. |
| Remote | `https://github.com/Dimkox/adaptive-grok-build-pro.git` |
| GHA / packaging markers | **absent**. No `.github/workflows`, no `pyproject.toml` / `requirements.txt` / `setup.py` |
| This change | `draft`. `human-approval.md` already on `0284241`. |
| This-route verification | receipt exists, **stale** (`stale_reason`: tree changed after tool use; fingerprint `d91bbd68…` is the pre-evidence tree). Re-verify after the last markdown write. |
| `approvals.json` | `fa4325201168` (wrong reason, expires 23:38:38). Live-or-just-minted `a6cc4f6d9775` reason is “standing consent: if tests pass publish; last mile v2.0.8 from 0284241” (expires 23:48:56). |
| Predecessor `8fe260` | notes+zip ship at `83673bbc`, status `verifying`. Superseded for tagging: that zip predates `## Release when green`. Keep the package; do not retag `83673bbc`. |

`83673bbc` rebuilt the 2.0.8 zip **before** the standing rule. Tagging it would ship an `AGENTS.md` that lacks `## Release when green`. `0284241` is the first commit that contains the rule, the structure tests, the CHANGELOG/README line, **and** a zip rebuilt in the same commit.

---

## 2. Standing rule (already landed — keep)

Placement is the design. Self-learning stays first. README-before-push stays second. Split-large-tasks stays third. Release-when-green is the next always-applied heading so a rewrite cannot bury it under Bitrix/API.

Exact heading (do not rename):

```markdown
## Release when green
```

Required heading order:

```text
headings[0] == '## Agent self-learning'
headings[1] == '## README before push'
headings[2] == '## Split large tasks'
headings[3] == '## Release when green'
```

`## Mandatory entrypoint` stays after the intro paragraph. Do not mention `engineering/decisions.md` / `engineering/mistakes.md` anywhere before that heading.

Required meaning in **that section** (already present):

- Trigger = `python3 scripts/grok_verify.py --mode pr` PASS **and** the route’s required reviews pass.
- Sequence = refresh `README.md` first → bump `VERSION` **only if the last tag already exists** → rebuild the zip → tag → `git push` branch **and** tag → `gh release create`.
- Negative = do not leave a green unpublished `VERSION` when standing release consent is in force.

This is an **agent standing order**, not a GitHub Action and not a hook that auto-tags. Local `grok_verify --mode pr` remains the only quality gate.

### decisions.md

Canonical log is root `decisions.md`. `engineering/decisions.md` stays the two-line stub.

Exact title (already present; structure test names this string):

```markdown
## 2026-08-16 — Green verify means a new release
```

Keep the live two-sentence body. Do not add a twin. Do not add a fourth sentence.

### What “always make a new release” does **not** mean

| Reading | Ruling |
| --- | --- |
| This same 2.0.8 tree is green, so cut **2.0.9** now | **No.** Last tag did not exist when this identity started; `VERSION` is already 2.0.8. After `v2.0.8` exists, the *next* distinct green delivery may bump. |
| Green verify alone, reviews missing | **No.** Both conjuncts are required. |
| Auto-publish from a workflow file | **No.** Never GitHub Actions. |
| Standing consent expires after this tag | **No.** `human-approval.md` keeps the same last mile for future green verifies. Still mint a fresh 15-minute `grok_approve.py production` row per publish (PreToolUse). |

Installer: `merge_agents` ships the whole `AGENTS.md`. Intended. Do not add root `decisions.md` / `mistakes.md` to `MANAGED_FILES`.

---

## 3. This last mile — 2.0.8 of `0284241`

Stay on identity 2.0.8. The last published tag before this ship is `v2.0.7` → `02376cc`. Do not retag it.

Correct tag target is **`0284241`**, not `HEAD` after later paperwork (this analysis file is dirt after the tag).

In-zip contract the controller must still **prove** (zip is binary here; this agent could not grep the heading out of the deflate stream):

```text
in-zip VERSION == 2.0.8
in-zip AGENTS.md contains '## Release when green'
in-zip CHANGELOG §2.0.8 names root decisions.md and 'publish a new release when verify is green'
no .github/workflows/, no pyproject.toml inside the zip
packages sidecar starts with 42a08851f2a6c2844f57fe91ce8a370544b51e683c4ff443fa20bee44da60c52
2.0.7 sidecar still starts with ec48d3174248e15e241519546b1414a7698857509cf97ac61e078dbd204de01c
```

If that proof fails **and** `v2.0.8` already peels to `0284241`: do **not** `git tag -f`. Record the defect in `mistakes.md` and open a new route. Forward-fix is 2.0.9 (last tag now exists). That is out of scope for this package unless the in-zip check fails.

If the proof passes: last mile is done. Do not rebuild. Do not `gh release create` a second time.

---

## 4. Who executes

| Action | Who |
| --- | --- |
| This design | `architect` (this file) |
| Parallel facts | `repo_explorer`, `docs_researcher` |
| Confirm / finish last mile | **Controller** (`git` / `gh` CLI) |
| Spawn any write role | **Nobody** |
| `security_reviewer` + `release_reviewer` | After confirmation (and after the last evidence markdown), observational |
| This architect running tag / push / release | **Forbidden** |

Production invocations that need a live token: `git push`, `gh release create` only (`policy.PRODUCTION_INVOCATIONS`). `git tag`, `package_stack`, and `git commit` are not hook-gated.

Reuse **only** `a6cc4f6d9775` if it is still unexpired **and** a push/`gh release create` is still required. Do **not** reuse `fa4325201168` (wrong reason). If last mile is already live, do not mint another production row.

---

## 5. Numbered controller commands

Working directory: repo root. Stop if any precondition fails. Do not add `.github/workflows/` or `pyproject.toml`.

### Phase A — identity and in-zip proof (not a production invocation)

**1.** Frozen surfaces.

```bash
test "$(git symbolic-ref --short HEAD)" = main
test "$(git rev-parse HEAD)" = 02842413509dc98eaaf104e27f212888f9449826
test "$(tr -d '[:space:]' < VERSION)" = 2.0.8
test ! -e pyproject.toml
test ! -e requirements.txt
test ! -e setup.py
test ! -d .github/workflows
test ! -e .github/dependabot.yml
git rev-parse 'v2.0.7^{}'   # expect 02376cc097d7640d56dd308b98efe4e026f4c253
git rev-parse 'v2.0.8^{}'   # expect 02842413509dc98eaaf104e27f212888f9449826
```

If `HEAD` is not `0284241`, stop. Do not move the existing `v2.0.8` tag.

**2.** In-zip contains the standing rule.

```bash
python3 - <<'PY'
import zipfile
from pathlib import Path
z = Path('packages/adaptive-grok-build-pro-v2.0.8.zip')
sidecar = Path('packages/adaptive-grok-build-pro-v2.0.8.zip.sha256').read_text().split()[0]
assert sidecar == '42a08851f2a6c2844f57fe91ce8a370544b51e683c4ff443fa20bee44da60c52'
with zipfile.ZipFile(z) as archive:
    names = archive.namelist()
    version = archive.read('adaptive-grok-build-pro/VERSION').decode().strip()
    agents = archive.read('adaptive-grok-build-pro/AGENTS.md').decode()
    notes = archive.read('adaptive-grok-build-pro/CHANGELOG.md').decode()
assert version == '2.0.8'
assert '## Release when green' in agents
assert 'gh release create' in agents
assert 'log-to-root `decisions.md`' in notes
assert 'publish a new release when verify is green' in notes
assert not any('.github/workflows/' in n for n in names)
assert not any(n.endswith('pyproject.toml') for n in names)
print('zip ok')
PY
```

**3.** Remote truth. Prefer `gh`, not a cached HTML Latest page.

```bash
git fetch origin
test "$(git rev-parse origin/main)" = 02842413509dc98eaaf104e27f212888f9449826
git ls-remote --tags origin 'refs/tags/v2.0.8'
gh release view v2.0.8 --json tagName,name,isDraft,isPrerelease,targetCommitish
gh api repos/Dimkox/adaptive-grok-build-pro/releases/latest --jq .tag_name
gh release view v2.0.7 --json tagName
```

Expected:

- `v2.0.8` exists, `name` = `Adaptive Grok Build Pro v2.0.8`, `isDraft=false`, `isPrerelease=false`
- peeled commit / target = `0284241`
- Latest tag name = `v2.0.8`
- `v2.0.7` still exists

### Phase B — only if Phase A shows a hole

Do **not** enter this phase if Latest is already `v2.0.8` on `0284241` and the zip proof passed.

| Hole | Action |
| --- | --- |
| Tag missing locally, exists on origin | `git fetch origin tag v2.0.8` |
| Tag missing everywhere, zip proof passed | `git tag -a v2.0.8 02842413509dc98eaaf104e27f212888f9449826 -m "v2.0.8"` then push SHA-pinned `main` (if origin lagged) then `git push origin v2.0.8` then `gh release create` with `--verify-tag` (runbook `engineering/runbooks/publish-v2.0.8.md`) |
| Release exists as draft/prerelease | `gh release edit v2.0.8 --draft=false --prerelease=false --latest` — **not** a second `create`. `gh release edit` is not a `PRODUCTION_INVOCATIONS` prefix; still do not force-push |
| `origin/main` behind `0284241` | `git push origin 02842413509dc98eaaf104e27f212888f9449826:refs/heads/main` with a live production token |
| Zip proof fails | **stop**. No `-f` tag. New route / 2.0.9 |

Publish command bytes if `gh release create` never ran (title required, no `--target`):

```bash
gh release create v2.0.8 \
  packages/adaptive-grok-build-pro-v2.0.8.zip \
  packages/adaptive-grok-build-pro-v2.0.8.zip.sha256 \
  --title "Adaptive Grok Build Pro v2.0.8" \
  --notes-file dist/RELEASE-NOTES.md \
  --verify-tag
```

Order is load-bearing: tag → push `main` → push tag → `gh release create`.

### Phase C — this route’s paperwork (no second ship)

Wait until sibling analyses exist:

- `evidence/analysis-architect.md` (this file)
- `evidence/analysis-repo_explorer.md`
- `evidence/analysis-docs_researcher.md`

Then:

```bash
python3 scripts/grok_change.py transition 20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb reviewing --reason "analysis complete; confirm 0284241 last mile"
```

Dispatch **only** `security_reviewer` and `release_reviewer`. They inspect `git diff 3ffcf393a6f17d7c97b80b2d299816a5f96102a8..02842413509dc98eaaf104e27f212888f9449826` plus the GitHub Release object, and write:

- `evidence/security-review.md`
- `evidence/release-review.md`

Do not invent `code_review` / `test_review` receipts — the route does not ask for them.

After the **last** `*.md` write in this package (fingerprint includes change-package files; runtime receipts do not):

```bash
python3 scripts/grok_verify.py --mode pr
```

If `project_copy` races on `.last-fingerprint.json.*`, re-run **once**. A real fail stops closure. Do not publish a red tree. Do not treat a flake as a reason to cut 2.0.9.

```bash
python3 scripts/grok_review.py security_review --status pass --report engineering/changes/20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb/evidence/security-review.md
python3 scripts/grok_review.py release_review --status pass --report engineering/changes/20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb/evidence/release-review.md
python3 scripts/grok_status.py
```

`evidence_gaps` must be `[]`. Then:

```bash
python3 scripts/grok_change.py transition 20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb ready --reason "verify + security/release on 0284241 v2.0.8"
python3 scripts/grok_change.py transition 20260816-the-user-sent-a-message-while-you-were-working-u-e4afbb released --reason "GitHub Release v2.0.8 peels to 0284241"
```

Do **not** `git add` this analysis into a follow-up ship commit. Leftover change packages stay local unless a later paperwork route says otherwise. `git add -A` is forbidden.

---

## 6. Do not run

| Command | Why |
| --- | --- |
| spawn `general_implementer` / any write role | `write_agent` is null |
| bump `VERSION` to 2.0.9 | last mile is unpublished-then-published **2.0.8** |
| `git tag -f v2.0.8` / any touch of `v2.0.7` | retag forbidden |
| `git tag` on `3ffcf39` / `83673bbc` / `22762a7` | zip or notes stale vs the rule |
| second `gh release create v2.0.8` after a live Latest | already shipped |
| `python3 scripts/grok_deploy.py` as publisher | fails on `draft` / stale evidence; printer is not the SHA-pinned last mile |
| `python3 scripts/package_stack.py` after a passing in-zip proof | would dirty `dist/` and tempt a 2.0.9 |
| `.github/workflows/` / `pyproject.toml` / `requirements.txt` / `setup.py` | Never GHA; flips `detect_repo` |
| `git push --force` / `git push -f` | rollback is delete-release + delete-tag, or a forward-fix |
| reuse `fa4325201168` | wrong reason; likely expired |
| `gh auth login` / `xdg-open` / Bitvise | existing `gh` session only |

---

## 7. Rollback

Already-published `v2.0.8` on `0284241`:

```bash
gh release delete v2.0.8 --yes
git push origin :refs/tags/v2.0.8
git tag -d v2.0.8
```

Do **not** force-push `main`. Do **not** touch `v2.0.7`. Forward-fix is a new change / new VERSION.

If the push never landed: local `0284241` stays; no reset.

---

## 8. Go / no-go

**GO** to close this route when:

- `VERSION` is 2.0.8
- `v2.0.8^{}` is `0284241`
- in-zip `AGENTS.md` has `## Release when green`
- GitHub Release title is `Adaptive Grok Build Pro v2.0.8`, not draft/prerelease
- Latest is `v2.0.8` (confirm with `gh api …/releases/latest`, not a cached HTML page)
- `v2.0.7` still peels to `02376cc`
- no GHA, no `pyproject.toml`
- this package has fresh `verification` + `security_review` + `release_review` on the final evidence tree

**NO-GO** if `HEAD` moved off `0284241` without a new approved route, if the zip lacks the standing rule, if anyone retags 2.0.7, or if a writer is spawned.

Architect / this report must not run the last mile.
