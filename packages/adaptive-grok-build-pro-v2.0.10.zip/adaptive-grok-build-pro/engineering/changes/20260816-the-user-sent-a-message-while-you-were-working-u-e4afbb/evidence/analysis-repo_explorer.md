# Analysis — repo_explorer
Route `e4afbb76d595`. Confirm last-mile argv for unpublished 2.0.8. write_agent=none.
HEAD is `02842413509dc98eaaf104e27f212888f9449826` ("Release when green"), parent `83673bbc` is the zip rebuild; do not tag 83673bb alone.
origin/main=`3ffcf393`. Local tags `v2.0.0`…`v2.0.7`. GitHub Latest remains `v2.0.7` @ `02376cc`. No `v2.0.8` tag/Release. VERSION stays 2.0.8; no 2.0.9; do not retag 2.0.7.
Argv source is print-only `python3 scripts/grok_deploy.py` (`_human_commands` + `engineering/runbooks/publish-v2.0.8.md`). Never executes. `--record` needs production approval + change `ready`/`released`.
`python3 scripts/package_stack.py`
`cp dist/adaptive-grok-build-pro-v2.0.8.zip* packages/`
`git tag -a v2.0.8 -m "v2.0.8"`
`GIT_TERMINAL_PROMPT=0 git -c credential.helper='!gh auth git-credential' push origin main`
`GIT_TERMINAL_PROMPT=0 git -c credential.helper='!gh auth git-credential' push origin v2.0.8`
`gh release create v2.0.8 packages/adaptive-grok-build-pro-v2.0.8.zip packages/adaptive-grok-build-pro-v2.0.8.zip.sha256 --title "Adaptive Grok Build Pro v2.0.8" --notes-file dist/RELEASE-NOTES.md`
If package_stack changes zip bytes vs `42a08851…` (current dist/packages sidecar), commit `packages/` first, then tag that SHA. Rollback: `gh release delete v2.0.8 --yes`; `git push origin :refs/tags/v2.0.8`; `git tag -d v2.0.8`.
Mint first: `python3 scripts/grok_approve.py production --reason "publish v2.0.8 after green verify"` (approvals.json tokens expired 22:20 / 23:06 / 23:38Z). Route still needs `security_review` + `release_review` receipts.
Live `receipts/e4afbb76d595/verification.json` is FAIL+stale (unittest `project_copy` race on `.last-fingerprint.json.*`). Re-run `python3 scripts/grok_verify.py --mode pr`; publish only on PASS. No GHA.
Standing consent is this user query plus `evidence/human-approval.md`. Controller/human runs the argv; this agent does not tag, push, or `gh release`.
