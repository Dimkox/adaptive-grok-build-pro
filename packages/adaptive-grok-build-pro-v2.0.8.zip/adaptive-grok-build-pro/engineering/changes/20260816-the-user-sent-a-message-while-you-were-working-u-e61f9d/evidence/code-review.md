# Code review — README-before-push + split large tasks

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`  
Route: `e61f9d74d5c2` · reviewer: `code_reviewer` (read-only) · write owner: `general_implementer`  
Reviewed: 2026-08-16  
Commits: `ffd30fd` (`Require current complete-graph README before every push; record ship evidence`) + `fc7b674` (`Remember: split large tasks; share AGENTS/decisions/mistakes`)  
Base: `7152b75` (`origin/main`, `Document root agent logs and complete K10 stack graph in README`)

**PASS.** I would not block.

HEAD is `fc7b674`. `origin/main` is still `7152b75`. The product tree at HEAD meets every named acceptance item: `AGENTS.md` has `## README before push` then `## Split large tasks`; `decisions.md` has both 2026-08-16 entries; README has Current state, Map, and the locked K10 mermaid; structure tests lock those rules; `VERSION` is `2.0.8`; no GitHub Actions; no `pyproject.toml`.

---

## Verdict against acceptance

| # | Criterion | Result |
| --- | --- | --- |
| 1 | `AGENTS.md` has `## README before push` and `## Split large tasks` | **PASS** |
| 2 | `decisions.md` has both entries (`README is the push-time product map` + `Split one large task; share memory`) | **PASS** |
| 3 | README has Current state + Map + K10 complete graph | **PASS** |
| 4 | Structure tests lock those surfaces | **PASS** |
| 5 | `VERSION` 2.0.8 | **PASS** |
| 6 | No GitHub Actions | **PASS** |
| 7 | No `pyproject.toml` | **PASS** |

Would I block? **No.**

---

## What was actually inspected

Did not trust `evidence/implementation.md` alone. Compared the live tree at `fc7b674` to GitHub raw of `7152b75` plus both change packages (`e61f9d` and predecessor `f1bdb9`: brief, requirements, architecture, test-plan, tasks, release, rollback) and later analysis notes. This session has no shell, so there is no live `git show --name-only` / `unittest` / `ruff`. Equivalents below.

```text
# refs
.git/HEAD                     → ref: refs/heads/main
.git/refs/heads/main          → fc7b67415c81111db2f5169d0903e2e930020d74
.git/refs/remotes/origin/main → 7152b75b610bada0ecc7468752900ab1515324f1
.git/COMMIT_EDITMSG           → Remember: split large tasks; share AGENTS/decisions/mistakes
.git/logs/HEAD                → 7152b75 → ffd30fd → fc7b674
.git/refs/tags                → v2.0.0 … v2.0.7 (no v2.0.8)

# GitHub main (public HTML)
latest commit still 7152b75   ffd30fd / fc7b674 not pushed

# contracts
engineering/changes/…-e61f9d/{brief,requirements,architecture,test-plan,tasks,release,rollback}.md
engineering/changes/…-e61f9d/evidence/{analysis-*,implementation}.md
engineering/changes/…-f1bdb9/{brief,requirements,test-plan,implementation}.md
.grok-stack/runtime/active-route.json   allowed_agents includes code_reviewer; write_agent=general_implementer

# product vs 7152b75 (GitHub raw + working tree at HEAD)
AGENTS.md                     +## README before push + ## Split large tasks
decisions.md                  +Split one large task; share memory
                              +README is the push-time product map
README.md                     +Current state / Read first / How work runs / Map
                              K10 fence unchanged (45 ---)
tests/test_structure.py       +test_agents_md_requires_readme_refresh_before_push
                              +test_decisions_md_records_readme_before_push
                              +test_readme_names_onboarding_docs_and_current_version
                              +test_agents_md_splits_large_tasks
                              +test_decisions_md_records_split_large_tasks

# unchanged on purpose
VERSION                       2.0.8
.grok-stack/adaptive_grok/__init__.py  __version__ = "2.0.8"
README.md H1                  Adaptive Grok Build Pro v2.0.8
mermaid first fence           same 10 ids / 45 --- pairs as 7152b75
engineering/decisions.md      still a 2-line stub

# absences
pyproject.toml / requirements.txt / setup.py   do not exist
.github/                                       directory missing
.github/dependabot.yml                         missing
.grok-stack/templates/ci/github-actions.yml    missing
v2.0.8 tag                                     missing (correct)
```

`grok_verify --mode pr` receipt at `.grok-stack/runtime/receipts/e61f9d74d5c2/verification.json` is `pass` on fingerprint `4a9e74b7…` and is already marked `stale` (`repository tree changed after tool use`). Used only as a changed-file *union* and as proof the 190-test / ruff / bandit / coverage gate went green after `fc7b674`. It is not a `git show` of either commit.

---

## Diff reviewed

### 1. `AGENTS.md` — both standing rules

Origin `7152b75` prefix was only `## Agent self-learning` then the intro paragraph then `## Mandatory entrypoint`.

HEAD headings in order:

```text
headings[0] == '## Agent self-learning'
headings[1] == '## README before push'
headings[2] == '## Split large tasks'
headings[3] == '## Mandatory entrypoint'
```

`## README before push` (ffd30fd) names `git push`, `python3 scripts/grok_deploy.py`, current VERSION / tree, and a complete pairwise `---` graph. It forbids pushing a README whose graph or current-state section is behind the tree.

`## Split large tasks` (fc7b674) sits immediately after that block. Body:

- “For reading and delivery, split one large task into several small concrete subtasks that share memory.”
- Shared memory is `AGENTS.md`, `decisions.md`, and `mistakes.md`.
- “Do not keep the whole plan only in chat.”

Does not spawn extra write owners. Does not name `engineering/decisions.md` / `engineering/mistakes.md` (existing self-learning prefix lock still holds). First heading is unchanged.

### 2. `decisions.md` — both entries

Newest-first, after the intro (“Patterns that paid for themselves”). Both bodies are three `.`-terminated sentences.

| Entry | Commit | Names |
| --- | --- | --- |
| `## 2026-08-16 — Split one large task; share memory` | `fc7b674` | `AGENTS.md` / `decisions.md` / `mistakes.md` |
| `## 2026-08-16 — README is the push-time product map` | `ffd30fd` | refresh before `git push` / `grok_deploy`; complete pairwise graph |

Prior K10 / move-the-logs / never-GHA / no-pyproject entries are still present. `engineering/decisions.md` is still the two-line stub (`Canonical log is /decisions.md`. `Do not append here.`).

### 3. README — Current state + Map + K10

Origin `7152b75` started at `## What this is` then the K10 fence. No Current state, Read first, How work runs, or Map.

HEAD, after the H1 / pitch:

- `## Current state` — identity **2.0.8**; standing contract names `AGENTS.md` / `decisions.md` / `mistakes.md` and README-before-push; local verify only; **No GitHub Actions**; do not add `pyproject.toml`.
- `## Read first` — `AGENTS.md` → `decisions.md` → `mistakes.md` → `CHANGELOG.md` → `QUICKSTART.md` → `active-route.json`.
- `## How work runs` — split into small subtasks that share `decisions.md` / `mistakes.md`; refresh README before push.
- `## Map` — the onboarding file list including `AGENTS.md`, `decisions.md`, `mistakes.md`, `CHANGELOG.md`, `QUICKSTART.md`, `VERSION`.
- `## Stack graph` — same first mermaid as `7152b75`.

Independent pair check against  
`{Route, Skills, Agents, Hooks, Policy, Verify, Packages, Contract, Decisions, Mistakes}`:

| From | Degree-to-later nodes |
| --- | --- |
| Route | 9 (Skills…Mistakes) |
| Skills | 8 |
| Agents | 7 |
| Hooks | 6 |
| Policy | 5 |
| Verify | 4 |
| Packages | 3 |
| Contract | 2 |
| Decisions | 1 |
| **Total** | **45 = C(10,2)** |

Not a star, path, or K7-plus-pendants. Cross edges such as `Policy --- Mistakes`, `Packages --- Contract`, and `Contract --- Decisions` are present. Caption kept: `Simple complete graph: every core piece is linked to every other.` One mermaid in README. H1 still `v2.0.8`. MIT / commercial / free / public / no-EULA copy is unchanged.

Current-state standing-contract line still ends at “next is README-before-push” and does not name the new third heading. How-work-runs names `decisions.md` / `mistakes.md` but omits `AGENTS.md` from the shared-memory sentence. Later analysis asked for a one-line catch-up. The required *sections* exist; the K10 fence was not rewritten. Not a block of this review’s must-have list. See nits.

### 4. Tests lock them

`tests/test_structure.py` vs origin `7152b75` adds five methods. Prior self-learning, stub-pointer, K10, MIT, no-packaging, and `2.0.8`/no-GHA tests stay.

| Method | What it fails on |
| --- | --- |
| `test_agents_md_requires_readme_refresh_before_push` | missing `## README before push`, `git push`, `grok_deploy`, or `complete` |
| `test_decisions_md_records_readme_before_push` | missing title `README is the push-time product map` |
| `test_agents_md_splits_large_tasks` | missing `## Split large tasks`, `shared memory`, or `decisions.md` |
| `test_decisions_md_records_split_large_tasks` | missing title `Split one large task` |
| `test_readme_names_onboarding_docs_and_current_version` | missing `QUICKSTART.md`, `CHANGELOG.md`, or `2.0.8` |
| `test_readme_stack_graph_is_complete` (kept) | first mermaid not exactly the 10 ids / 45 unique `---` pairs |

Those methods match `f1bdb9` test-plan + `e61f9d` test-plan + this review’s “tests lock them” list. Existing `test_version_is_2_0_8_and_github_actions_are_absent` and `test_product_tree_has_no_packaging_markers` still lock identity and the two absences.

Weaker than the post-commit architect slice (`headings[2]`, section-body tokens, ≤3-sentence body). Whole-file `assertIn('decisions.md', AGENTS.md)` would still pass if the new section dropped that name, because self-learning already contains it. The **product** still has the tokens in the right section. Test-strength gaps belong to `test_reviewer`; they do not fail this code review.

### 5. VERSION / GHA / pyproject

- `VERSION` file is `2.0.8`. README H1 is `v2.0.8`. `__version__` is `"2.0.8"`.
- `.github/` does not exist. No Dependabot. No CI template.
- No root `pyproject.toml` / `requirements.txt` / `setup.py`.
- No `v2.0.8` tag. GitHub `main` is still `7152b75`. This reviewer does not push.
- None of `VERSION`, `CHANGELOG.md`, `packages/*`, `dist/*`, `install_into.py`, or `.github/**` needed to change for this docs/test slice.

---

## Scope and contracts

| Guard | Observed |
| --- | --- |
| Identity stays 2.0.8 | `VERSION` / H1 / `__version__` unchanged |
| No GHA / Dependabot | `.github/` absent; template absent |
| No packaging markers | `pyproject.toml` / `requirements.txt` / `setup.py` absent |
| K10 not redrawn | first fence byte-identical in structure to `7152b75` (same 10 ids, same 45 pairs) |
| No zip / tag / Release | tags stop at `v2.0.7`; GitHub latest commit is `7152b75` |
| One write owner | product files attributed to `general_implementer`; this agent only reviews |
| Smallest vertical | docs + structure tests + both change packages; no new service |

e61f9d `requirements.md` / `architecture.md` / `test-plan.md` and f1bdb9 `requirements.md` / `test-plan.md` are met on the landed tree. Post-commit analysis (`analysis-architect.md`, `analysis-task_analyst.md`) asked to tighten the two new tests to a heading-order / section slice and to add one Current-state line. That is residual polish, not a missing must-have on `ffd30fd`+`fc7b674`.

---

## Findings

No functional, security, or scope-break findings that fail the must-have list.

### Nits (do not fail)

1. **Current state is one heading behind the tree.** The standing-contract bullet still says “next is README-before-push” and does not name `## Split large tasks`. The new README-before-push rule itself says not to *push* a stale current-state section. Fine for this unpushed pair; refresh that one line before any last mile.
2. **How work runs omits `AGENTS.md`** from the shared-memory sentence. The `AGENTS.md` section itself names all three files.
3. **Split-task tests are whole-file substrings.** They go red if the heading or title disappears. They do not lock `headings[2]`, the section slice, or a ≤3-sentence body. Architect asked to extend the same two methods; test_reviewer owns that gap.
4. **`test_readme_names_onboarding_docs_and_current_version` does not assert `## Current state` or `## Map`.** It locks `QUICKSTART.md` / `CHANGELOG.md` / `2.0.8`. The sections exist; a delete of the headings with those names kept elsewhere would still pass.
5. **Verification receipt is stale.** Post-commit analysis files changed the tree after `4a9e74b7…`. Controller must re-verify on the final fingerprint after review reports land.
6. **Working-tree leftovers** from sibling packages (`ad4090` merge files, `37141f`, `ff295d`, `d55ce4`, `2f9f5d`, `79f406`, …) appear in the verify `changed_files` union. That list is not a `git show`. Push must stay path-limited. `git add -A` would fail cleanliness.

---

## Residual risk

- `origin/main` is still `7152b75` until a separately approved last mile. This reviewer does not push.
- A human push of `fc7b674` without the one-line Current-state catch-up would violate the new README-before-push rule.
- Official receipts must be rebound after this report (and any sibling test-review) is written; the current verification receipt is already stale.
- Could not independently run `python3 -m unittest` or `git show ffd30fd` / `git show fc7b674`. File-level parent-vs-HEAD comparison was done via GitHub raw `7152b75` + local `HEAD` + reflog subjects.

Rollback if not pushed: `git reset --keep origin/main` (drops `ffd30fd` and `fc7b674`). If already on `origin/main`: forward-fix, no force-push.

---

## Recommendation

**PASS.** Both commits vs `7152b75` land the required memory: README-before-push + split-large-tasks in `AGENTS.md`, both `decisions.md` entries, README Current state / Map / K10, and structure tests that lock those headings and the complete graph. Identity stays `2.0.8`. No GHA. No `pyproject.toml`. Do not tag, push, or `gh release` from review.
