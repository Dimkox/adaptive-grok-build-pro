# Implementation

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`  
Route: `e61f9d74d5c2` · write owner: `general_implementer`

Large work is split into small subtasks that share `AGENTS.md` / `decisions.md` / `mistakes.md`. `VERSION` stays `2.0.8`. No push, tag, or zip from this owner.

## SHA

`fc7b67415c81111db2f5169d0903e2e930020d74`  
Subject: `Remember: split large tasks; share AGENTS/decisions/mistakes`

Follow-up (README current-state only): `3ffcf393a6f17d7c97b80b2d299816a5f96102a8`  
Subject: `README current state names split-task rule`

This report is written after the commits so it can record the SHAs. It is intentionally uncommitted (same wave as upcoming review reports).

## What changed

| Path | Change |
| --- | --- |
| `AGENTS.md` | New `## Split large tasks` after `## README before push`. Shared memory is `AGENTS.md` / `decisions.md` / `mistakes.md`. Do not keep the whole plan only in chat. |
| `decisions.md` | New 2026-08-16 entry: `Split one large task; share memory`. |
| `README.md` | How work runs: large work is split into small subtasks that share `decisions.md` / `mistakes.md`. Current state standing-contract bullet now names README-before-push **and** Split large tasks (`3ffcf39`). |
| `tests/test_structure.py` | `test_agents_md_splits_large_tasks` and `test_decisions_md_records_split_large_tasks`. Prior README-before-push locks kept. |
| e61f9d package | Included. |
| f1bdb9 `evidence/implementation.md` | Leftover SHA report from `ffd30fd`, included in this commit. |

Not touched: `VERSION` (2.0.8), packager, zip, `pyproject.toml`, GitHub Actions, tag, push.

## Red then green

Before the docs:

```
python3 -m unittest \
  tests.test_structure.StructureTests.test_agents_md_splits_large_tasks \
  tests.test_structure.StructureTests.test_decisions_md_records_split_large_tasks \
  tests.test_structure.StructureTests.test_agents_md_requires_readme_refresh_before_push -q
```

- `test_agents_md_splits_large_tasks` — `AssertionError: '## Split large tasks' not found`
- `test_decisions_md_records_split_large_tasks` — `AssertionError: 'Split one large task' not found`
- `test_agents_md_requires_readme_refresh_before_push` — ok

After the docs:

```
python3 -m unittest tests.test_structure -q
```

`Ran 22 tests in 0.011s` · `OK`

## Left unstaged

f1bdb9 leftover analysis notes (not in the commit list):

- `engineering/changes/...-f1bdb9/evidence/analysis-architect.md`
- `engineering/changes/...-f1bdb9/evidence/analysis-docs_researcher.md`
- `engineering/changes/...-f1bdb9/evidence/analysis-task_analyst.md`

## Residual risk

- Official `grok_verify --mode pr` and independent `code_review` / `test_review` are not recorded here. Controller runs those after this stop.
