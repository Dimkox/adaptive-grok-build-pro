# Test review — `e61f9d74d5c2`

Change: `engineering/changes/20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`  
Reviewer: `test_reviewer` (read-only). Write owner: `general_implementer`.  
Scope: `tests/test_structure.py` locks for README-before-push, complete K10 graph, split large tasks, and `decisions.md` entries. Assigned bar: **must fail if those headings are dropped.**  
Suite was **not** re-run here (would dirty receipts / coverage artifacts / fingerprint temp files). Independent file review of the lock methods, the files they pin, and the official verification receipt.

**PASS.**

Dropping `## README before push`, `## Split large tasks`, or the two 2026-08-16 decisions titles fails the matching `assertIn` on a string that lives only in that heading (or, for the graph, dropping the mermaid / any `---` pair fails the K10 pair-set). Do not return this to `general_implementer` for missing heading locks.

| ID | Required case | Test | Result |
| --- | --- | --- | --- |
| P0 | Drop `## README before push` from `AGENTS.md` | `test_agents_md_requires_readme_refresh_before_push` | Covered |
| P0 | Drop `## Split large tasks` from `AGENTS.md` | `test_agents_md_splits_large_tasks` | Covered |
| P0 | Drop decisions title `README is the push-time product map` | `test_decisions_md_records_readme_before_push` | Covered |
| P0 | Drop decisions title `Split one large task` | `test_decisions_md_records_split_large_tasks` | Covered |
| P0 | First mermaid fence is K10: 10 ids, 45 unique undirected `---` pairs | `test_readme_stack_graph_is_complete` | Covered |
| P0 | Prior self-learning / stub / MIT / 2.0.8 tests not weakened | surrounding `StructureTests` | Covered |

---

## Verdict

| Gate | Result |
| --- | --- |
| Product-test adequacy for this delta | **PASS.** Official `test-plan.md` and `requirements.md` asked the structure test to lock the new heading plus `shared memory` / `decisions.md`. Both new methods do that. Prior README-before-push and K10 locks are still present and still heading-sensitive. |
| Characterization coverage | **PASS.** Implementation recorded red-then-green: before the docs, the two new methods failed on the missing heading / title; `test_agents_md_requires_readme_refresh_before_push` stayed green. Residual whole-file / order / slice gaps are noted below and are not fail against the assigned heading-drop bar. |
| Verification evidence | **Noted, not a test-design fail.** Official `python3 scripts/grok_verify.py --mode pr` is **190 tests, OK**. Receipt is later marked stale because the tree changed after that run (this package’s analysis/implementation notes). |

---

## 1. Assigned bar

The review question is whether `tests/test_structure.py` fails when these headings disappear:

1. `## README before push`
2. `## Split large tasks`
3. the `decisions.md` entries that record those two rules
4. the complete K10 README graph (every listed core node linked to every other)

A body-only leftover after the heading is deleted must still be red. A whole-file hunt that would stay green after the heading is deleted is a fail.

---

## 2. README-before-push

```79:88:tests/test_structure.py
    def test_agents_md_requires_readme_refresh_before_push(self) -> None:
        text = (ROOT / 'AGENTS.md').read_text(encoding='utf-8')
        self.assertIn('## README before push', text)
        self.assertIn('git push', text)
        self.assertIn('grok_deploy', text)
        self.assertIn('complete', text)

    def test_decisions_md_records_readme_before_push(self) -> None:
        text = (ROOT / 'decisions.md').read_text(encoding='utf-8')
        self.assertIn('README is the push-time product map', text)
```

`## README before push` is an exact heading lock. Deleting that line, or demoting it to `#` / `###` / a bullet, is `AssertionError: '## README before push' not found`.

The decisions lock is the title substring. Live file:

```8:11:decisions.md
## 2026-08-16 — README is the push-time product map

A cold reader (human or LLM) only gets current context if `README.md` is refreshed to the tree being shipped. Before every `git push` or `grok_deploy`, rewrite current state and keep the mermaid a complete pairwise-linked graph. Structure tests fail if that AGENTS.md rule or the complete graph disappears.
```

`README is the push-time product map` occurs **only** in that heading. Dropping the heading while leaving the body is red.

Implementation (f1bdb9, kept by this route) recorded the same first-fail: `'## README before push' not found` / `'README is the push-time product map' not found` on the pre-heading tree. This route re-ran that method after adding Split large tasks and it stayed green.

---

## 3. Split large tasks

```90:98:tests/test_structure.py
    def test_agents_md_splits_large_tasks(self) -> None:
        text = (ROOT / 'AGENTS.md').read_text(encoding='utf-8')
        self.assertIn('## Split large tasks', text)
        self.assertIn('shared memory', text.lower())
        self.assertIn('decisions.md', text)

    def test_decisions_md_records_split_large_tasks(self) -> None:
        text = (ROOT / 'decisions.md').read_text(encoding='utf-8')
        self.assertIn('Split one large task', text)
```

`## Split large tasks` is an exact heading lock. Deleting it fails even if the three bullets stay. Implementation recorded that first-fail before the docs: `AssertionError: '## Split large tasks' not found`.

`shared memory` appears only in that section (line 16). Deleting the heading **and** the body also fails that assert. Deleting only the heading still fails the heading assert.

The decisions lock is the title substring. Live file:

```5:6:decisions.md
## 2026-08-16 — Split one large task; share memory
```

`Split one large task` occurs **only** in that heading. The body says “Split into concrete subtasks…”, which does not contain the locked phrase. Dropping the heading is red. Implementation recorded `AssertionError: 'Split one large task' not found` on the pre-entry tree.

This matches `test-plan.md` (`## Split large tasks` + `shared memory` / `decisions.md`) and `requirements.md` (“Structure test locks the heading”). Architecture asked for one structure test; the implementer added the sibling decisions-title method. Keep both.

---

## 4. Complete K10 graph

```100:137:tests/test_structure.py
    def test_readme_stack_graph_is_complete(self) -> None:
        ...
        required = (
            'Route', 'Skills', 'Agents', 'Hooks', 'Policy',
            'Verify', 'Packages', 'Contract', 'Decisions', 'Mistakes',
        )
        ...
        self.assertEqual(nodes, set(required))
        self.assertEqual(len(edges), 45, ...)
        expected = {frozenset(pair) for pair in combinations(required, 2)}
        self.assertEqual(edges, expected)
```

Unchanged by this route. Still the pair-set lock, not a node-existence check.

Independent read of `README.md` first mermaid fence (lines 62–112):

- Three labeled decls: `Contract["AGENTS.md"]`, `Decisions["decisions.md"]`, `Mistakes["mistakes.md"]`.
- 45 unique `A --- B` lines. Degree sequence is 9+8+7+6+5+4+3+2+1. Every unordered pair among the ten ids is present, including `Contract --- Decisions`, `Contract --- Mistakes`, `Decisions --- Mistakes`.
- Parser shape matches the file: two-space indent, `---` with spaces, labels only on the three decls.

Dropping the fence fails `missing mermaid fence`. Dropping any one pair fails `len(edges) == 45` and `edges == expected`. A star, a path, K7-plus-pendants, or directed `-->` only is not enough. Caption-only “complete graph” does not pass.

`test_readme_names_onboarding_docs_and_current_version` still pins `QUICKSTART.md`, `CHANGELOG.md`, and `2.0.8`. Identity stays 2.0.8.

---

## 5. Surrounding suite (not weakened)

Still present and still the ba1615 / f1bdb9 / a13da8 product locks:

- `test_agents_md_starts_with_self_learning` — `headings[0] == '## Agent self-learning'`; prefix before Mandatory entrypoint names the root logs; forbids `engineering/` as the live sink.
- `test_engineering_self_learning_stubs_are_pointers`
- `test_readme_names_root_self_learning_logs`
- `test_readme_is_free_mit_commercial_product`
- `test_version_is_2_0_8_and_github_actions_are_absent`
- `test_package_version_matches_version_file`
- `test_product_tree_has_no_packaging_markers`

No `pyproject.toml` / `requirements.txt` / `setup.py` were added to light the tests. Structure suite count is 22 (20 after f1bdb9 + the two new split-task methods). Official verify ran 190 tests.

---

## 6. Gaps (not fail)

These are weaker than the in-package `analysis-architect.md` / `analysis-task_analyst.md` wish-list. They are **not** required to meet the assigned heading-drop bar or this package’s `test-plan.md`.

| Gap | Why not fail |
| --- | --- |
| `test_agents_md_splits_large_tasks` searches the **whole** `AGENTS.md` for `decisions.md` | Self-learning already contains `decisions.md`, so that one assert would stay green without the new section. The **heading** assert would not. Assigned bar is heading-drop, and `test-plan.md` names exactly these three tokens. |
| No `headings[2] == '## Split large tasks'` order lock | Heading can move below Bitrix and still pass. Dropping it still fails. Order is reviewer-eyeball: live file is self-learning → README before push → Split large tasks → Mandatory entrypoint. |
| Slice is not required to name `mistakes.md` / `AGENTS.md` | Body does name all three. A later edit that stripped those two names from the slice would stay green. That is a tighten, not a missing heading lock. |
| `assertIn('complete', AGENTS.md)` is a substring of `completion` | Load-bearing lock for that method is `## README before push`. Graph completeness is the sibling K10 pair-set. |
| README `## Current state` still ends at “next is README-before-push”; How-work-runs names only `decisions.md` / `mistakes.md` | Product-copy catch-up, not a structure-test heading lock. K10 and onboarding-name tests still pass. Analysis asked for a Current-state assert; this package’s `test-plan.md` did not. |
| Decisions body ≤3 sentences is not counted | Live entry is three sentences. Title drop still fails. |
| K10 `decisions.md` heading (`README stack graph is K10…`) is not separately locked | The mermaid pair-set is the product lock. |

---

## 7. Verification evidence (did not re-run)

Receipt: `.grok-stack/runtime/receipts/e61f9d74d5c2/verification.json`  
Fingerprint at verify: `4a9e74b736ed74774fea30a5bb9674c933dcd28cd46c02aaadd54390fc7012e9`  
Current `last-fingerprint.json`: `a9fb2e1ab05a8950d058855f29c3f34083eb170b1fc81a87203e21df760bafc1`  
Mode: `pr` · profiles: `base` · **status: pass** · later `stale: true` (`repository tree changed after tool use`)

| Check | Status |
| --- | --- |
| git-diff-check | pass |
| secret-scan | pass |
| contract-structure | pass |
| sql-safety | pass |
| ruff | pass |
| bandit | pass |
| python-unittest | **pass** — 190 ran, OK (40.958s) |
| coverage report | pass (76%) |

Implementation red/green (not re-run here):

- Before docs: `test_agents_md_splits_large_tasks` red (`'## Split large tasks' not found`); `test_decisions_md_records_split_large_tasks` red (`'Split one large task' not found`); `test_agents_md_requires_readme_refresh_before_push` ok.
- After docs: `python3 -m unittest tests.test_structure -q` → `Ran 22 tests in 0.011s` / `OK`.

Controller still needs review receipts bound on the **final** fingerprint after this report is written. That is sequencing, not a missing heading characterization.

---

## Verdict (repeat)

**PASS.**

`test_agents_md_requires_readme_refresh_before_push` is red if `## README before push` is dropped.  
`test_agents_md_splits_large_tasks` is red if `## Split large tasks` is dropped.  
`test_decisions_md_records_readme_before_push` / `test_decisions_md_records_split_large_tasks` are red if those decisions titles are dropped (the locked phrases live only in the headings).  
`test_readme_stack_graph_is_complete` is red if the first mermaid fence, any of the ten ids, or any of the 45 undirected `---` pairs disappears.
