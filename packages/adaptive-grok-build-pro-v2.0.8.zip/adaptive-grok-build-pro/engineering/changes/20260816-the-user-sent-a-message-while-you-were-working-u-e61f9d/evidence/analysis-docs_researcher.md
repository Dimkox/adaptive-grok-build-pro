# Docs research — split reading into subtasks linked by shared memory

Route: `e61f9d74d5c2`. Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`.

Question: user said for reading, always split one big task into several small concrete subtasks linked by shared memory. That is a standing agent rule, not a change-package-only note.

Read-only. No APIs invented. No `.env`. No push / merge / deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. Sibling: `evidence/analysis-repo_explorer.md`. Write owner: `general_implementer`. Package status when read: `implementing`. `human_gates` empty.

---

## Verdict

| Claim | Standing fact? |
| --- | --- |
| User order is a **standing agent rule** | **Yes.** It belongs in root `AGENTS.md`, the Engineering Contract. A note only under `engineering/changes/…` is not enough. |
| Shared memory is the three root contract files | **Yes.** This package names `AGENTS.md`, `decisions.md`, `mistakes.md`. Chat is not memory. Change-package evidence is task-local, not standing. |
| Scope of the user sentence is **reading** | **Yes, verbatim.** Original: «для чтения разбивай всегда одну большую задачу на несколько маленьких конкретных подзадач, связанных общей памятью». |
| A prior pattern already exists for “put the rule in AGENTS.md and lock it” | **Yes.** `## Agent self-learning` and `## README before push`. Same class as ba1615’s mistake: logs without a standing `AGENTS.md` order. |
| Any ADR / OpenAPI / AsyncAPI / schema defines this | **No.** `engineering/adr/` is empty. `engineering/contracts/{openapi,asyncapi,schemas}/` are empty. No API to invent or extend. |
| README-before-push unfinished work is still missing from the tree | **No.** Heading, `decisions.md` entry, README Current state / Read first / Map / K10, and structure tests are already on disk (f1bdb9). Do not redo them. |

Live tree already has the new heading (write owner landed it during this wave). Facts below are from docs and the tree, not from chat.

---

## Sources

- User / route task (Russian original) and this package: `brief.md`, `requirements.md`, `architecture.md`, `test-plan.md`, `release.md`, `rollback.md`
- `AGENTS.md` — Engineering Contract; SoT order; `## Agent self-learning`; `## README before push`; live `## Split large tasks`
- Root `decisions.md`, root `mistakes.md`; stubs `engineering/decisions.md`, `engineering/mistakes.md`
- `README.md` Current state, Read first, How work runs, Map, Stack graph
- `CHANGELOG.md` §2.0.8
- `VERSION` = `2.0.8`
- `tests/test_structure.py` heading locks
- `.grok/skills/adaptive-delivery/SKILL.md` §2 Parallel analysis (“one narrow question”)
- `.grok/skills/feature-workflow/SKILL.md`, `.grok/skills/task-triage/SKILL.md`, `.grok/skills/verification-evidence/SKILL.md`
- `.grok-stack/config/routing.json` analysis floors / `max_parallel_analysis`
- Agent cards: `.grok/agents/{docs_researcher,repo_explorer,task_analyst,architect,general_implementer}.{md,toml}`
- `scripts/install_into.py` `merge_agents()`
- Prior packages: ba1615 (root logs), a13da8 (K10 graph), f1bdb9 (README-before-push standing rule), 79f406 (onboarding README)
- Sibling `evidence/analysis-repo_explorer.md`, `evidence/implementation.md`
- `engineering/adr/` (empty); contracts (empty)

---

## 1. Why this cannot stay a change-package-only note

`AGENTS.md` source-of-truth order:

1. User-approved scope and decisions.
2. Active route and durable change package under `engineering/changes/`.
3. Machine-readable API/event/data contracts.
4. ADRs and repository-local instructions.
5. Existing implementation and tests.
6. Chat history.

A change package is SoT **#2 for one route**. The next session does not load `e61f9d` unless a human or route points at it. Chat is **#6**. Standing agent behavior that must fire on every later read belongs in `AGENTS.md` (the contract the installer ships and the first file README tells a cold reader to open).

Precedent that this class of rule dies if it is not wired into `AGENTS.md`:

- `mistakes.md` **Self-learning bullets never wired into AGENTS.md**: agents had log files but no standing order to write them. Root cause was authorship omission in the contract, not a later delete.
- f1bdb9 user order (“запиши в память”) was implemented as `## README before push` in `AGENTS.md` plus a ≤3-sentence `decisions.md` entry plus structure tests — not as a leftover sentence in `engineering/changes/…-f1bdb9/`.

`install_into.py` `merge_agents()` wraps the **whole** `AGENTS.md` in the managed block and ships it to consumers. Change-package markdown is not in `MANAGED_FILES`. If the split-reading rule lives only under `engineering/changes/`, installed projects never see it.

`decisions.md` header: “Patterns that paid for themselves. Each entry is at most three sentences.” That log is memory of a pattern, not the order agents read first. The **order** is the `AGENTS.md` heading.

---

## 2. Shared memory — named files, not chat, not the change folder

This package `brief.md` / `architecture.md`:

> Shared memory is `decisions.md` / `mistakes.md` / `AGENTS.md`.

Live `AGENTS.md` `## Split large tasks` (already inserted after `## README before push`):

- For reading and delivery, split one large task into several small concrete subtasks that share memory.
- Shared memory is `AGENTS.md`, `decisions.md`, and `mistakes.md`. Each subtask must leave a fact there if it will matter to the next subtask.
- Do not keep the whole plan only in chat.

Canonical paths (ba1615 + `test_agents_md_starts_with_self_learning`):

| File | Role |
| --- | --- |
| `AGENTS.md` | Standing contract. First heading remains `## Agent self-learning`. |
| `/decisions.md` | Live pattern log. “Patterns that paid for themselves.” |
| `/mistakes.md` | Live error log. “Root causes, not symptoms.” |
| `engineering/decisions.md` / `engineering/mistakes.md` | Two-line stubs: `Canonical log is /…. Do not append here.` |

Not shared memory for this rule:

- Chat / the interrupted user_query wrapper.
- `engineering/changes/<id>/` (durable for **this** change; not the next read).
- `evidence/analysis-<agent>.md` (adaptive-delivery §2 report sink; per-route).
- `.grok-stack/runtime/active-route.json` (live route; README: “not product identity”).

f1bdb9 architect said “Do not add a third memory file” **for the README-before-push pair** (`AGENTS.md` + `decisions.md`). This user-approved brief **does** name `mistakes.md` as the third shared-memory file for split-reading. That is not a conflict with the push-time rule; do not drop `mistakes.md` from this section.

---

## 3. “For reading” vs what already exists in the controller

User scope is **reading** (`для чтения`). Existing controller text already splits **analysis agents**, not the reader’s own work into memory-linked slices.

`.grok/skills/adaptive-delivery/SKILL.md` §2:

- Dispatch all `analysis_agents` whose work is independent.
- Give each agent **one narrow question** and a report path `<change>/evidence/analysis-<agent>.md`.
- Wait for all reports. Do not ask the user for facts recoverable from the repository.
- Dispatch every listed analyst in **one wave**. Do not spawn extra names to fill the cap.
- Keep exactly one write owner.

`.grok-stack/config/routing.json`:

- Principle: `parallelize read-heavy analysis and review`.
- `max_parallel_analysis`: 10 (ceiling, not a quota).
- Floors: `repo_explorer` always; `task_analyst` on feature-like; `architect` + `docs_researcher` on standard.
- `docs_researcher` is on every non-micro wave (`decisions.md`: “Ten is a read-only ceiling”).

`AGENTS.md` multi-agent discipline: “Parallel work is for read-heavy exploration, impact analysis, test analysis, and independent review.”

`feature-workflow`: “Prefer a vertical slice.” That is delivery shape, not the reading-split rule.

These facts mean: the stack already **fans out** reading across named analysts with one question each. It does **not** already say that a **single** large read must be cut into small concrete subtasks that **write into** `AGENTS.md` / `decisions.md` / `mistakes.md` so the next slice can start without the chat. That second sentence is the new standing rule.

Live heading text says “For reading **and delivery**.” The user sentence is reading-only. Delivery already has “smallest coherent vertical change” + one write owner. Broadening to delivery is a bounded ruling already in the live section; it does not invent an API. Do not weaken the reading clause.

How to apply it on a read (no new skill or agent name; do not invent one):

1. Name several **concrete** sub-questions (example for this route: where standing rules live; what shared memory already is; what adaptive-delivery already splits; what f1bdb9 already locked).
2. Recover each from docs / ADRs / contracts / tests.
3. Leave any fact that the next slice needs in `AGENTS.md` / `decisions.md` / `mistakes.md`, not only in `evidence/`.
4. Link slices through those files. Do not keep the plan only in chat.

This report is one such slice. Sibling `analysis-repo_explorer.md` is another. Shared memory they both name is the same three root files.

---

## 4. Placement and locks (do not fight the existing headings)

Required heading, this package `architecture.md` / `test-plan.md`:

```markdown
## Split large tasks
```

Insert **after** `## README before push` and **before** `## Mandatory entrypoint`.

Live heading order:

0. `## Agent self-learning` — locked first by `test_agents_md_starts_with_self_learning`
1. `## README before push` — locked present by `test_agents_md_requires_readme_refresh_before_push`
2. `## Split large tasks` — locked present by `test_agents_md_splits_large_tasks`
3. `## Mandatory entrypoint`

f1bdb9 architect required README-before-push to stay the **second** heading and to remain **before** Mandatory entrypoint. This insert keeps both. Do not move Split above README-before-push. Do not move it below Mandatory entrypoint (that would drop it out of the self-learning prefix test window).

Prefix before `## Mandatory entrypoint` must still contain `log it in decisions.md` / `record it in mistakes.md` and must **not** contain `engineering/decisions.md` or `engineering/mistakes.md`.

Structure tests this package named (now in `tests/test_structure.py`):

- `test_agents_md_splits_large_tasks` — `## Split large tasks`, `shared memory` (case-insensitive), `decisions.md`
- `test_decisions_md_records_split_large_tasks` — `Split one large task`

Keep the prior locks:

- `test_agents_md_requires_readme_refresh_before_push`
- `test_decisions_md_records_readme_before_push` (`README is the push-time product map`)
- `test_readme_stack_graph_is_complete` (K10, 45 `---` edges)
- `test_agents_md_starts_with_self_learning`

`decisions.md` live newest entry (≤3 sentences, required by self-learning and this package):

```markdown
## 2026-08-16 — Split one large task; share memory
```

Body already names the three files and “without the chat.” That matches the standing-rule claim.

`requirements.md` checkboxes are marked done. `release.md`: stay **2.0.8**. `rollback.md`: revert the AGENTS.md section, the decisions.md entry, and the test.

---

## 5. README / CHANGELOG — what is already true, what is not a new API

`README.md` already has Current state, Read first (AGENTS.md → decisions.md → mistakes.md), Map, and the locked K10 graph. Sibling repo_explorer: **do not redo** those.

`README.md` § How work runs now says large work is split into small subtasks that share `decisions.md` / `mistakes.md`. It does **not** name `AGENTS.md` in that sentence. Standing contract line still says “first section is agent self-learning … next is README-before-push” and does **not** name `## Split large tasks`.

`AGENTS.md` README-before-push rule: do not push a README whose current-state section is behind the tree. If this change is what will be pushed, Current state is one sentence behind (it does not yet list Split as the third standing heading). That is a README freshness fact, not a VERSION bump.

`CHANGELOG.md` §2.0.8 still says log-to-`engineering/decisions.md` / `engineering/mistakes.md` (the 2.0.8 ship record). a13da8 / ba1615 left that. This package’s `release.md` is “Stay 2.0.8.” Do not add a 2.0.9 bullet for a contract heading.

`QUICKSTART.md` does not mention AGENTS.md, shared memory, or split-reading. No standing doc requires it to. Skip.

Do **not** add mermaid nodes, installer APIs, a new skill, or a new agent for this rule. `merge_agents()` already ships whatever is in `AGENTS.md`.

---

## 6. Contracts and ADRs

| Surface | Fact |
| --- | --- |
| `engineering/adr/` | Empty. No ADR to amend. |
| OpenAPI / AsyncAPI / schemas | Empty. No product API. Do not invent one. |
| `docs/bitrix-local-AGENTS.md` | Bitrix `local/` rules only. Out of scope (`domains=generic`). |
| Quality profile `base` | `git-diff-check`, `secret-scan`. No contract-structure required. |
| Agent cards | `docs_researcher` remains “Recover facts from repository docs, ADRs, and contracts. Do not invent APIs.” No card change is specified. |

---

## 7. Unfinished prior turn (f1bdb9) — already in the tree

This route also says “finish the README-before-push memory and complete README.” Live facts:

- `## README before push` is in `AGENTS.md` with `git push` / `grok_deploy` / complete-graph wording.
- `decisions.md` has `README is the push-time product map`.
- README has Current state, Read first, Map, How work runs, K10 45-edge graph.
- f1bdb9 `requirements.md` is fully checked; `state.json` may still say `implementing`.
- Sibling: wait if that writer is mid-edit of the same files; then continue as the single write owner. Do not spawn a second writer.

No tag, pack, push, or CI. No Bitrix core. No `pyproject.toml`.

---

## Fact for the write owner

1. Treat the user sentence as a **standing `AGENTS.md` rule**, same class as self-learning and README-before-push. A change-package paragraph alone fails the user order.
2. Keep heading `## Split large tasks` immediately after `## README before push` and before `## Mandatory entrypoint`.
3. Shared memory in that section must name `AGENTS.md`, `decisions.md`, and `mistakes.md`. Chat is not memory.
4. Keep the reading clause. “And delivery” is already in the live bullets; do not drop reading.
5. One ≤3-sentence `decisions.md` entry (`Split one large task; share memory`). Do not append to `engineering/decisions.md`.
6. Keep structure tests for the new heading **and** the prior README-before-push / self-learning / K10 locks.
7. Stay `VERSION` **2.0.8**. Do not invent APIs, skills, agents, ADRs, or contracts. Do not rewrite CHANGELOG §2.0.8 as if this were a release.
8. If README Current state is part of the push, name the new standing heading there so the push-time map is not behind the tree.
