# Analysis — task_analyst

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`  
Route: `e61f9d74d5c2` · intent=`feature` · risk=`low` · complexity=`standard`  
Write owner: `general_implementer` (exactly one)  
Analysis wave: `repo_explorer`, `task_analyst`, `architect`, `docs_researcher`  
Reviews after implementation: `code_reviewer` + `test_reviewer`  
Evidence kinds: `verification`, `code_review`, `test_review`  
Human gates: none  
Quality profiles: `base`  
Workflow skills: `/adaptive-delivery`, `feature-workflow`  
Narrow question: **acceptance — AGENTS.md + decisions.md: always split one large task into small concrete subtasks that share memory (`decisions.md` / `mistakes.md` / `AGENTS.md`). Finish leftover README-before-push work. Stay 2.0.8.**

Read-only. No application-code edits. No `.env`. This report does not push, tag, merge, or deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md` and `feature-workflow`. This agent is in `allowed_agents`. Sibling fact: `evidence/analysis-repo_explorer.md`. Change package was `approved` when this report started and is now `implementing` (write owner already edited the same files).

---

## Ruling (one screen)

The user asked to **write into memory** that one large task is always split into several small concrete subtasks linked by shared memory. Shared memory is the three standing files: `AGENTS.md`, `decisions.md`, `mistakes.md`. Chat is not the coupling.

This route also finishes leftover **README-before-push** work from `f1bdb9` (rule + onboarding sections already in the tree; package still not closed). It does **not** reopen `79f406`’s full cold-start catalog (every skill link, banned-actions section).

- **In:** `AGENTS.md` `## Split large tasks` immediately after `## README before push`; one ≤3-sentence `decisions.md` entry; structure tests that lock the heading **and** the three memory names **in that section**; README Current state names the new third heading so the push-time map is not stale. Identity stays **2.0.8**.
- **Out:** extra write owners, a task-splitter script, routing.json changes, `VERSION` bump, zip rebuild, tag, GitHub Release, GitHub Actions, `pyproject.toml`, installer `MANAGED_FILES`, growing the K10 mermaid, leftover dirt from unrelated packages, this-route `git push`.

**Do not treat the in-flight edit as accepted.** As of this report the write owner has already inserted the heading, a decisions entry, and two tests (claimed SHA `fc7b674`). Those files are the right surface. They are **not** done until the gaps in §3 are closed.

---

## Current facts (do not treat as done)

| Item | This tree |
| --- | --- |
| `VERSION` / README H1 | `2.0.8` / `# Adaptive Grok Build Pro v2.0.8` |
| `AGENTS.md` headings[0] | `## Agent self-learning` (locked by `test_agents_md_starts_with_self_learning`) |
| `AGENTS.md` headings[1] | `## README before push` (f1bdb9; locked only by `assertIn`, not by index) |
| `AGENTS.md` headings[2] | **Now** `## Split large tasks` (in-flight write) |
| `AGENTS.md` headings[3] | `## Mandatory entrypoint` |
| Split-task body | Present: “For reading and delivery…”, names `AGENTS.md` / `decisions.md` / `mistakes.md`, “Do not keep the whole plan only in chat.” |
| `decisions.md` newest entry | `## 2026-08-16 — Split one large task; share memory` (3 sentences). Next entry is still `README is the push-time product map`. |
| New tests | `test_agents_md_splits_large_tasks`, `test_decisions_md_records_split_large_tasks` exist. The AGENTS test searches the **whole file** for `decisions.md` (already true from self-learning). |
| README `## Current state` | Still says first section is self-learning and “next is README-before-push”. **Does not name** `## Split large tasks`. Behind the tree. |
| README `## How work runs` | Mentions split + `decisions.md` / `mistakes.md`. Omits `AGENTS.md` as shared memory. |
| README `## Read first` / `## Map` / K10 | Present. First mermaid is still 10 ids / 45 `---` pairs. |
| `f1bdb9` | Product files landed (`ffd30fd`). State still `implementing`. Reviews / `grok_verify` receipts missing. Some analysis notes left unstaged. |
| `79f406` | Still `approved`, unimplemented full catalog. **Not this write.** |
| `2f9f5d` | Separate last-mile push of `7152b75`. **Not this route.** |
| This package | `implementing`. Requirements/tasks checkboxes already ticked by the writer. Official `grok_verify` + reviews not recorded. |
| `human_gates` | `[]` — proceed after this ruling. Push still needs a short-lived `grok_approve production` and is **out of this write**. |

Answer to “is the split-task memory written and leftover README-before-push finished?”: **partial.** The standing heading exists. Current state is stale. Tests do not lock the section slice. Leftover f1bdb9 close (verify/reviews/ready) is still open.

---

## 1. Outcome

After this change, a human or LLM who opens the tree sees:

1. A standing `AGENTS.md` rule, applied on every software-development task: for reading and delivery, always split one large task into several small concrete subtasks.
2. Those subtasks share memory through **root** `AGENTS.md`, `decisions.md`, and `mistakes.md`. A fact that the next subtask needs is written there. The whole plan does not live only in chat.
3. A root `decisions.md` entry (≤3 sentences) that records why the split exists.
4. The prior `## README before push` rule, its decisions entry, onboarding README (`Current state`, `Read first`, `Map`), and the locked K10 graph are still present.
5. `README.md` § Current state matches the tree: the contract now has **three** lead headings (self-learning → README-before-push → split large tasks).
6. Structure tests go red if the new heading, the three memory names in that section, or the decisions title disappear; prior README-before-push tests stay green.
7. `VERSION` is still `2.0.8`. No tag. No GitHub Release from this route.

---

## 2. Acceptance criteria

Use these Given/When/Then items as the package `requirements.md`. All are in scope for `general_implementer`.

### 2.1 `AGENTS.md` standing rule

Insert one new section **immediately after** the whole `## README before push` block and **before** `## Mandatory entrypoint`.

Exact heading:

```
## Split large tasks
```

Required meaning (wording may vary; tests lock the tokens below):

- For **reading** and delivery, always split one large task into several **small concrete** subtasks.
- Shared memory is root `AGENTS.md`, `decisions.md`, and `mistakes.md`.
- Each subtask leaves a fact in those files if the next subtask will need it.
- Do not keep the whole plan only in chat.

“For reading” is the user’s wording: analysis and cold readers decompose first. Delivery uses the same split. This is **not** permission to spawn a second write owner.

- [ ] **Given** `AGENTS.md` headings, **when** they are collected in order, **then** `headings[0] == '## Agent self-learning'`, `headings[1] == '## README before push'`, `headings[2] == '## Split large tasks'`, `headings[3] == '## Mandatory entrypoint'`. Later headings stay as they are today.
- [ ] **Given** the new section (the slice from `## Split large tasks` to the next `## `), **when** it is read, **then** it contains `shared memory` (case-insensitive), `AGENTS.md`, `decisions.md`, and `mistakes.md`.
- [ ] **Given** that same slice, **when** it is read, **then** it does **not** contain `engineering/decisions.md` or `engineering/mistakes.md` (would also fail the existing prefix lock).
- [ ] **Given** `test_agents_md_starts_with_self_learning`, **when** this lands, **then** it stays green. First heading does **not** move. Prefix still has `log it in decisions.md` / `record it in mistakes.md`.
- [ ] **Given** `## README before push`, **when** the new section is added, **then** that heading stays `headings[1]` and still names `git push`, `grok_deploy`, and complete-graph wording.
- [ ] **Given** Multi-agent discipline, **when** the split rule is read, **then** it does **not** say to launch extra write agents. Exactly one `write_agent` remains. Parallel work stays read-only analysis / review.

Do **not** add a runtime decomposer in `scripts/grok_change.py` or `routing.json`. The user said «для чтения разбивай» / «связанных общей памятью». Memory is `AGENTS.md` + `decisions.md` + `mistakes.md`, locked by tests.

### 2.2 `decisions.md` entry

Newest-first. Insert immediately under the `# Decisions` intro (`Patterns that paid for themselves…`), **above** `## 2026-08-16 — README is the push-time product map`.

Lockable title (matches the in-flight write; keep it):

```
## 2026-08-16 — Split one large task; share memory
```

If the write owner changes the title, the structure test must assert **that exact title**. Prefer the string above so this report, `test-plan.md`, and the test agree.

Body: **at most three sentences** (self-learning rule). Must say:

1. A giant undivided task produces stale maps and half-finished last miles.
2. Split into concrete subtasks that write facts into `AGENTS.md` / `decisions.md` / `mistakes.md`.
3. The next slice can start from those files without the chat.

Do not start a second living log under `engineering/`. Stubs stay stubs.

- [ ] **Given** root `decisions.md`, **when** the new test runs, **then** it finds the title `Split one large task; share memory` (or the exact title the test names).
- [ ] **Given** that entry’s body, **when** sentences are counted, **then** there are ≤3.
- [ ] **Given** that entry, **when** it names memory files, **then** it uses root `AGENTS.md` / `decisions.md` / `mistakes.md`, not `engineering/` paths.
- [ ] **Given** `engineering/decisions.md`, **when** this lands, **then** it is still a ≤5-line stub: `Canonical log is /decisions.md`, `Do not append here`, no `## 20` dated entries.
- [ ] **Given** the existing `README is the push-time product map` entry, **when** this entry is added, **then** that older entry remains immediately after the new one. Do not merge or delete it.

### 2.3 Finish leftover README-before-push work

f1bdb9 already wrote the standing rule, the decisions entry, and onboarding sections. This route **keeps** that work and applies the same rule to the new heading.

Keep, do not rewrite:

- `## README before push` as `headings[1]`
- decisions title `README is the push-time product map`
- README `## Current state`, `## Read first`, `## Map`
- first mermaid fence: K10, 45 `---` pairs, caption `Simple complete graph: every core piece is linked to every other.`
- `test_agents_md_requires_readme_refresh_before_push`
- `test_decisions_md_records_readme_before_push`
- `test_readme_names_onboarding_docs_and_current_version`
- `test_readme_stack_graph_is_complete`

Refresh Current state so it is not behind the tree (that is the leftover rule):

- [ ] **Given** README `## Current state`, **when** it describes the standing contract, **then** it names three lead `AGENTS.md` sections in order: Agent self-learning → README-before-push → Split large tasks (or the exact heading text). A line that stops at “next is README-before-push” **fails**.
- [ ] **Given** that section, **when** it names the logs, **then** they are root `decisions.md` / `mistakes.md`. It does **not** present `engineering/decisions.md` as the live sink.
- [ ] **Given** README `## How work runs` (or Current state), **when** it mentions the split, **then** shared memory includes `AGENTS.md` as well as `decisions.md` / `mistakes.md`.
- [ ] **Given** `## Read first`, **when** it is read, **then** the order is still `AGENTS.md` → `decisions.md` → `mistakes.md` → `CHANGELOG.md` → `QUICKSTART.md` → `active-route.json`.
- [ ] **Given** the first mermaid fence, **when** `test_readme_stack_graph_is_complete` runs, **then** it stays green: same 10 ids, same 45 pairs.
- [ ] **Given** identity, **when** README is edited, **then** H1 stays `v2.0.8` and Current state still says **2.0.8**. It does **not** claim GitHub Latest is 2.0.8.

Do **not** absorb `79f406`’s remaining catalog (every skill `SKILL.md`, agent list, banned-actions section, SoT six-line copy). That package is still `approved` for a different write. This leftover is f1bdb9’s memory + onboarding, plus making Current state match the new heading.

### 2.4 Structure tests lock 2.1–2.3

Failing test first when the heading is absent. Same file: `tests/test_structure.py`. Do not add `pyproject.toml`.

Required methods (names may already exist; behavior below is the acceptance):

| Method | Must assert |
| --- | --- |
| `test_agents_md_splits_large_tasks` | heading exists; `headings[2] == '## Split large tasks'`; **slice** from that heading to the next `## ` contains `shared memory`, `AGENTS.md`, `decisions.md`, `mistakes.md` |
| `test_decisions_md_records_split_large_tasks` | title `Split one large task` (or the exact title) |

- [ ] **Given** an `AGENTS.md` that has `## Split large tasks` but the slice does not name `mistakes.md` / `shared memory`, **when** unittest runs, **then** `test_agents_md_splits_large_tasks` fails.
- [ ] **Given** the current whole-file `assertIn('decisions.md', text)`, **when** acceptance is judged, **then** that assert is **not** enough. Self-learning already contains `decisions.md`. The test must inspect the **section slice**.
- [ ] **Given** a regression that drops `## README before push` or the push-time decisions title, **when** unittest runs, **then** the existing f1bdb9 tests fail. Do not weaken them.
- [ ] **Given** existing tests, **when** this lands, **then** these stay green: `test_agents_md_starts_with_self_learning`, `test_engineering_self_learning_stubs_are_pointers`, `test_readme_names_root_self_learning_logs`, `test_readme_names_onboarding_docs_and_current_version`, `test_readme_stack_graph_is_complete`, `test_readme_is_free_mit_commercial_product`, `test_version_is_2_0_8_and_github_actions_are_absent`.

### 2.5 Stay 2.0.8. No tag. No GitHub Release.

- [ ] **Given** this change, **when** it lands, **then** `VERSION` and `__version__` remain `2.0.8`. README H1 remains `v2.0.8`. Do **not** open `2.0.9`.
- [ ] **Given** this route, **when** the write owner finishes, **then** agents have not run `git tag`, `git push origin v2.0.8`, or `gh release create`. Do not rebuild `packages/adaptive-grok-build-pro-v2.0.8.zip`.
- [ ] **Given** `CHANGELOG.md` §2.0.8, **when** this ships, **then** a new `## 2.0.9` is forbidden. An in-place 2.0.8 bullet for the split-task rule is **allowed**, not required. Do not rewrite the stale `engineering/decisions.md` line as a reason to bump.

### 2.6 Commit remaining work (controller close, not a second writer)

Path-limited ship set:

| Include | Why |
| --- | --- |
| `AGENTS.md` | new section; keep README-before-push |
| `decisions.md` | new entry; keep push-time entry |
| `README.md` | Current state / How work runs catch-up |
| `tests/test_structure.py` | slice locks |
| this change package | e61f9d |
| leftover f1bdb9 evidence already intended for the same memory commit | only if still dirty and already reviewed as that package’s files |

Do **not** stage leftover dirt from `ad4090`, `39b13f`, `d55ce4`, or other unrelated packages. Do not start a second writer onto files another implementer is mid-edit on; wait, then the **same** `general_implementer` continues.

Sequence:

1. Tighten tests so the slice (not the whole `AGENTS.md`) is locked. Confirm they would have been red before the heading existed.
2. Finish README Current state so it names the third heading.
3. Focused unittest, then `python3 scripts/grok_verify.py --mode pr`.
4. Independent `code_reviewer` + `test_reviewer` reports under this package.
5. Transition this change to `ready` **before** recording receipts.
6. Record `verification`, `code_review`, `test_review` on the final fingerprint.
7. Path-limited commit of any remaining uncommitted slice (this analysis, review reports, Current state fix). Commit itself must not add unreviewed content.

- [ ] **Given** adaptive-delivery §7, **when** this route closes, **then** closure is not a push. Do not run `grok_deploy.py --record` as if this were a 2.0.9 / tag / Release ship.
- [ ] **Given** f1bdb9, **when** this route finishes product files, **then** this owner may include leftover f1bdb9 evidence already sitting next to the same memory files. Closing f1bdb9’s own `ready` + reviews is **controller** work, not a second implementer.
- [ ] **Given** rollback, **when** the commit is only local, **then** `git reset --keep` to the previous commit. If already on `origin/main`, no force-push; forward-fix.

---

## 3. Gaps on the in-flight tree (must close)

The write owner already inserted the heading and a decisions entry. These items are still **red** against this acceptance:

1. **README Current state is stale.** Line still ends at “next is README-before-push.” That violates leftover README-before-push (`Do not push a README whose … current-state section is behind the tree`) and §2.3.
2. **How work runs omits `AGENTS.md`** from the shared-memory set. User named three files.
3. **`test_agents_md_splits_large_tasks` is a false green risk.** `assertIn('decisions.md', whole AGENTS.md)` passes without the new section. It does not lock `headings[2]`, `mistakes.md`, or `AGENTS.md` in the slice.
4. **Requirements/tasks checkboxes were ticked before reviews.** Treat them as a writer claim, not as acceptance.
5. **Official `grok_verify --mode pr` and independent reviews** are not recorded. Implementation.md says so.
6. **f1bdb9** is still `implementing` with no review receipts. Product leftovers (heading, decisions entry, onboarding sections, K10) are in the tree; package close is not.

Until 1–3 are fixed and 5 is recorded on the **final** fingerprint, this change is not accepted.

---

## 4. Failure and edge cases

- [ ] Leaving the rule only in chat or only in this change package fails §2.1 (user said always, for reading, in shared memory).
- [ ] Putting `## Split large tasks` above `## Agent self-learning` fails the existing first-heading test.
- [ ] Putting it above `## README before push` (so README-before-push is no longer `headings[1]`) fails leftover f1bdb9 intent and §2.1.
- [ ] Naming `engineering/decisions.md` as the live shared memory fails ba1615 + the prefix lock.
- [ ] Interpreting “split” as ten writers, or as a second `write_agent`, fails Multi-agent discipline and §2.1.
- [ ] A test that only `assertIn('decisions.md', whole file)` fails §2.4.
- [ ] Dropping Current state / Read first / Map, or growing the first mermaid past 10 nodes, fails leftover README-before-push and K10 tests.
- [ ] Leaving Current state at “next is README-before-push” after adding the third heading fails §2.3.
- [ ] Bumping to 2.0.9, retagging, rebuilding the zip, or `gh release create` fails §2.5.
- [ ] Implementing from this agent or spawning a second writer onto the same files fails the route.
- [ ] Recording review receipts before the last change-package write (`state.json` → `ready`) repeats the 2026-08-14 fingerprint mistake.

---

## 5. Out of scope

- `VERSION` / `__version__` / README H1 identity change. Stay 2.0.8.
- Opening 2.0.9 or 2.1.0.
- `packages/*.zip` rebuild, `git tag`, `git push origin v2.0.8`, `gh release create`, `grok_deploy --record`.
- GitHub Actions, Dependabot, `pyproject.toml` / `requirements.txt` / `setup.py`.
- `install_into` `MANAGED_FILES` / doctor required-files for the logs.
- Extra mermaid vertices on the first fence.
- `79f406` full product-map / banned-actions README (separate approved package).
- `2f9f5d` `git push origin main` of `7152b75`.
- A new `scripts/` decomposer, ADR, or routing.json change.
- Mass-edit of historical change packages or CHANGELOG §2.0.8 identity.
- Bitrix core or a new Bitrix module.
- Merge, force-push, deploy, production writes.

---

## 6. Test plan (for the write owner)

| Priority | Scenario | Evidence |
| --- | --- | --- |
| P0 | New split-task tests are red if the heading or the section slice lacks `shared memory` / the three root files | failing `test_agents_md_splits_large_tasks` on a sliced assert |
| P0 | decisions.md title present; README-before-push tests still green | `test_decisions_md_records_split_large_tasks` + f1bdb9 tests |
| P0 | headings[0..3] order: self-learning, README before push, Split large tasks, Mandatory entrypoint | focused structure test or reviewer eyeball + tighter assert |
| P0 | Current state names the third heading; K10 still 45 pairs; identity 2.0.8 | README + `test_readme_stack_graph_is_complete` + version test |
| P0 | Full gate | `python3 scripts/grok_verify.py --mode pr` |
| P1 | A cold reader can start the next subtask from `AGENTS.md` / `decisions.md` / `mistakes.md` without the chat | reviewer dry run |
| P1 | No `v2.0.8` tag created by this route | `git tag -l 'v2.0.8'` empty |

---

## 7. Constraints

- Backward compatibility: docs + tests only. Consumer `AGENTS.md` gains the new section on next `install_into` (`merge_agents` wraps the whole file). Do not add root logs to `MANAGED_FILES`.
- Data: do not append to `engineering/decisions.md` / `engineering/mistakes.md`. Do not read `.env`.
- Operational: no named human gate; proceed after this ruling. Push is a separate last mile. No force-push.
- Identity: keep `2.0.8`. This is not a release.
- Parallelism: one write owner (`general_implementer`). This agent does not implement. If that writer is mid-edit, wait; do not spawn a second writer onto `AGENTS.md` / `decisions.md` / `README.md` / `tests/test_structure.py`.
- Feature-workflow: no new service, queue, store, or dependency. No ADR.

---

## 8. Suggested write-owner slice

These are the **remaining** small subtasks. Shared memory is these three files plus this report.

1. Tighten `test_agents_md_splits_large_tasks` to lock `headings[2]` and the **section slice** (`shared memory`, `AGENTS.md`, `decisions.md`, `mistakes.md`). Confirm it would fail if the slice omitted those tokens.
2. Update README `## Current state` so the standing-contract line names Split large tasks as the third heading. Name `AGENTS.md` in the How-work-runs shared-memory sentence.
3. Focused unittest, then `python3 scripts/grok_verify.py --mode pr`.
4. Independent `code_reviewer` + `test_reviewer`. Transition this package to `ready` **then** bind receipts on the final fingerprint.
5. Path-limited commit of the remaining slice (this analysis, Current state fix, tightened test, review reports). Stop. No tag. No Release. No 2.0.9.

---

## 9. Non-functional

- Security: no secrets in the memory files; do not teach agents to read `.env`.
- Reliability: heading order is the contract load order (self-learn → refresh README → split the work → then route).
- Performance: three short bullets, one decisions entry. Do not paste this whole report into `AGENTS.md`.
- Observability: Current state is the live status board; after this landing it must mention the third heading.

---

## 10. Package fill-in

**Outcome:** large work is always split into small concrete subtasks that share `AGENTS.md` / `decisions.md` / `mistakes.md`; leftover README-before-push rule and onboarding stay; Current state matches the tree; identity 2.0.8.

**In scope:** §2.1–§2.6.

**Out of scope:** §5.

**Acceptance:** the Given/When/Then boxes in §2, including the in-flight gaps in §3.

**Constraints:** §7. Backward compatible docs. No production last mile in this write.

This report is the bounded acceptance for a route with no named human gate. Architect may refine structure; they must not reopen 2.0.9, grow the first mermaid fence, or turn “split” into extra writers.
