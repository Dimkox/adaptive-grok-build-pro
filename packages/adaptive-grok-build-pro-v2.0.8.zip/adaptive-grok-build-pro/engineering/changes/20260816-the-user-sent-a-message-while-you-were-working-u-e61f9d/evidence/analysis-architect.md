# Analysis — architect

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-e61f9d`  
Route: `e61f9d74d5c2` · write owner: `general_implementer` · reviews: `code_reviewer` + `test_reviewer`  
Question: add `AGENTS.md` section `## Split large tasks` after `## README before push`. `decisions.md` ≤3-sentence entry. Test locks the heading. Shared memory = `decisions.md` + `mistakes.md` + `AGENTS.md`.

Read-only. No application-code edits from this agent. No `.env`. No push / merge / deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. Package is `draft` with prose already on disk (`implementation.md` records `fc7b674`). `human_gates` empty. Stay `VERSION` **2.0.8**.

Sibling: `evidence/analysis-repo_explorer.md` (its “gap” list is now stale — heading, decisions entry, and tests already landed). Predecessor `f1bdb9` still shows `implementing` on the same three files; do not start a second writer on that route. Wait if that owner is mid-edit, then this route’s `general_implementer` continues.

---

## Ruling

**Keep the landed prose. Tighten the structure tests so placement and the three-file memory set, not whole-file substrings, cannot disappear. One-line README Current state so that section is not behind the tree.**

1. `AGENTS.md`: `## Split large tasks` stays the **third** heading — after `## README before push`, before the intro paragraph and `## Mandatory entrypoint`.
2. Root `decisions.md`: keep the newest entry titled **`Split one large task; share memory`**, at most three sentences.
3. Shared memory is exactly `AGENTS.md` + `decisions.md` + `mistakes.md`. Not chat. Not `engineering/adr/`. Not the `engineering/` stubs.
4. `tests/test_structure.py`: lock (1)–(3) by heading order and **section body**. Keep the prior README-before-push tests.

Do **not** bump `VERSION`. Do **not** rewrite CHANGELOG §2.0.8. Do **not** edit the K10 mermaid. Do **not** add a new memory file, queue, or runtime store. Do **not** change `routing.json`, hooks, or `install_into.py`. Do **not** add `.github/workflows/` or `pyproject.toml`. Do **not** spawn a second write owner to “split” delivery.

Architect does **not** push. After the write owner tightens locks (and the one README line), `python3 scripts/grok_verify.py --mode pr`, then independent `code_reviewer` + `test_reviewer` on **this** route.

---

## 1. What already matches the contract

Live tree already contains the user-ordered memory. Do not thrash it for style.

| Surface | Live fact | Keep |
| --- | --- | --- |
| `AGENTS.md` headings | `[0] Agent self-learning`, `[1] README before push`, `[2] Split large tasks`, `[3] Mandatory entrypoint` | yes |
| New section body | “For reading and delivery, split one large task… share memory”; names `AGENTS.md`, `decisions.md`, `mistakes.md`; “Do not keep the whole plan only in chat.” | yes |
| Self-learning prefix | `test_agents_md_starts_with_self_learning` still holds: first heading unchanged; prefix still has root-log bullets and does **not** name `engineering/decisions.md` | do not mention `engineering/` sinks in this new section |
| README-before-push | Heading and `git push` / `grok_deploy` / complete-graph bullets unchanged | yes |
| `decisions.md` | `## 2026-08-16 — Split one large task; share memory` is first dated entry; three sentences; names the three files | yes |
| Prior decisions entry | `README is the push-time product map` still present | yes |
| README How work runs | Mentions split + `decisions.md` / `mistakes.md` | keep; add AGENTS.md in Current state, not a rewrite |
| K10 fence | Same ten IDs, same 45 `---` pairs | **do not edit a single mermaid line** |
| Identity | H1 and `VERSION` are `2.0.8` | stay 2.0.8 |

Repo-explorer gaps (no heading, no decisions title, no test) are **closed in prose**. Remaining gaps: lock strength, and README `## Current state` still says the next rule after self-learning is only README-before-push.

---

## 2. AGENTS.md — standing rule

Placement is the design. Self-learning stays first. README-before-push stays second. Split-large-tasks is the next always-applied heading so a rewrite cannot bury it under Bitrix/API sections.

Exact heading (already present; do not rename):

```markdown
## Split large tasks
```

Required heading order after the insert:

```text
headings[0] == '## Agent self-learning'
headings[1] == '## README before push'
headings[2] == '## Split large tasks'
headings[3] == '## Mandatory entrypoint'
```

Required meaning in **that section** (already present; keep these tokens):

- `shared memory` (case-insensitive)
- `AGENTS.md`
- `decisions.md`
- `mistakes.md`
- split-into-small-subtasks wording (`split` + `subtask`)
- chat is not the memory (`chat`)

User said «для чтения». Landed “For reading and delivery” is acceptable: reading is the trigger; delivery still has exactly one `write_agent`. Do not turn this section into permission for a second writer.

Do **not** mention `engineering/decisions.md` or `engineering/mistakes.md` anywhere before `## Mandatory entrypoint`. That would fail `test_agents_md_starts_with_self_learning`.

Installer: `merge_agents` wraps the whole `AGENTS.md` in the managed block (`scripts/install_into.py`). Adding this section ships to consumers on next `install_into`. That is intended. Do not add root `decisions.md` / `mistakes.md` to `MANAGED_FILES` (would clobber consumer logs).

Do not add a fourth memory file. Do not point shared memory at `engineering/changes/**` or chat.

---

## 3. decisions.md — ≤3-sentence entry

Canonical log is root `decisions.md`. `engineering/decisions.md` stays a stub. Newest first, after the intro paragraph.

Exact title (already present; this is the string the new test names):

```markdown
## 2026-08-16 — Split one large task; share memory
```

Keep the live three-sentence body. Do not add a fourth sentence. Do not append a twin entry if this title already exists.

Sentence-count rule: the body between this heading and the next `## ` has at most three `.`-terminated sentences. Live body has three periods. Do not introduce `e.g.` / `v2.0.8.` tricks to dodge the count.

`decisions_head = text[:400]` must still contain `Patterns that paid for themselves`. The new heading sits after that sentence, so the existing self-learning test stays green.

---

## 4. README — one Current-state line

`## Current state` is behind the tree. Line today:

> Standing contract: … first section is agent self-learning …; next is README-before-push.

That omits the new third heading. The README-before-push rule itself says not to push a Current-state section that is behind the tree.

Write owner: change **only** that standing-contract bullet so it also names `Split large tasks` (or `split-large-tasks`) after README-before-push. Keep the `decisions.md` / `mistakes.md` links.

Do **not** redo `## Read first`, `## Map`, or the mermaid. How work runs already mentions the split; optional tiny add of `` `AGENTS.md` `` there is fine, not required if Current state names all three files.

`test_readme_stack_graph_is_complete` remains the graph contract. Node tuple frozen:

```text
Route, Skills, Agents, Hooks, Policy, Verify, Packages, Contract, Decisions, Mistakes
```

`C(10,2) = 45` unique undirected `---` edges. No K11.

---

## 5. Tests — fail a move or a delete, not a whole-file hunt

Current new tests are too weak (same class as the pre-tighten README-before-push locks):

| Test | Live check | Gap |
| --- | --- | --- |
| `test_agents_md_splits_large_tasks` | `## Split large tasks`, `shared memory`, `decisions.md` **anywhere** in `AGENTS.md` | `decisions.md` already appears in the self-learning bullets. Heading can move below Bitrix. Section can drop `mistakes.md` / `AGENTS.md` and still pass. |
| `test_decisions_md_records_split_large_tasks` | title substring `Split one large task` only | no ≤3-sentence lock; no three-file names in the entry |

Architecture.md asked for one structure test. Implementer added two methods. **Keep both.** They map to the two durable surfaces. Do not add a third test file. Do not add a README Current-state assert in this change.

Write owner: **extend these two methods** (do not add a new test module). Keep every prior README-before-push / self-learning / K10 test.

### 5.1 `test_agents_md_splits_large_tasks`

```text
headings[0] == '## Agent self-learning'
headings[1] == '## README before push'
headings[2] == '## Split large tasks'
headings[3] == '## Mandatory entrypoint'
```

Slice the body between `## Split large tasks` and `## Mandatory entrypoint` and assert **that slice** contains `shared memory` (case-insensitive), `AGENTS.md`, `decisions.md`, and `mistakes.md`. Do not search the whole file for `decisions.md`.

### 5.2 `test_decisions_md_records_split_large_tasks`

- `## 2026-08-16 — Split one large task; share memory` is present.
- Body until the next `## ` contains `AGENTS.md`, `decisions.md`, and `mistakes.md`.
- Body has at most three sentences: `len(re.findall(r'\.[ \n]', body + ' ')) <= 3` or split on `'. '` and drop empties; live body is three periods.

If these asserts are already green on the landed tree after the slice change, that is fine — **do not revert prose just to restore fail-first**. Tighten first; if a required token is missing from the slice, add the token in that section only.

Keep `test_agents_md_requires_readme_refresh_before_push`, `test_decisions_md_records_readme_before_push`, `test_agents_md_starts_with_self_learning`, `test_version_is_2_0_8_and_github_actions_are_absent`, and `test_product_tree_has_no_packaging_markers` untouched except where heading-order asserts above overlap (they must stay consistent).

---

## 6. Write-owner sequence

One owner: `general_implementer`. Smallest remaining vertical.

1. If `f1bdb9` is mid-write on `AGENTS.md` / `decisions.md` / `tests/test_structure.py` / `README.md`, wait. Then continue on **this** route. Do not close `f1bdb9`.
2. Tighten the two structure tests as specified. Run `python3 -m unittest tests.test_structure`.
3. Only if a new assert is red: fix the matching heading/section. Do not restyle AGENTS.md / decisions.md if they already pass the tightened checks.
4. One Current-state bullet so README names the new third heading. Do not open the mermaid fence.
5. Do not edit `VERSION`, `CHANGELOG.md`, `install_into.py`, `grok_deploy.py`, hooks, `routing.json`, or `package_stack.py`.
6. Path-limited commit: `AGENTS.md`, `decisions.md`, `README.md`, `tests/test_structure.py`, this change package. No `git add -A`.
7. After the last file that will remain, `python3 scripts/grok_verify.py --mode pr`.
8. Dispatch `code_reviewer` and `test_reviewer` only after that verify. Record receipts on **this** route (`e61f9d74d5c2`).

This change is **not** a 2.0.9 / tag / GitHub Release. `release.md`: stay 2.0.8. Closure is not a push. Adaptive-delivery §7 still applies: humans own last-mile commands.

Unfinished previous-turn work: README-before-push prose and K10 are already in-tree (`f1bdb9` `ffd30fd`). This route does not re-implement that. It only keeps those rules and adds the split-task memory.

---

## 7. Out of scope

- New services, queues, databases, dependencies, ADRs
- OpenAPI / AsyncAPI / schema changes
- Bitrix core or `local/` product code
- New shared-memory runtime / vector store / extra log file
- Changing `max_parallel_analysis` or adding write agents
- Automated chat-vs-memory gate in policy / PreToolUse
- Copying root logs via `install_into`
- Expanding or redrawing the K10 graph
- Publishing `v2.0.8` / `v2.0.9`
- Closing leftover change packages (`f1bdb9`, `79f406`, …)

---

## 8. Risks

| Risk | Mitigation |
| --- | --- |
| Weak `decisions.md` substring in whole `AGENTS.md` | Assert inside the Split-large-tasks section only |
| Heading moved below Bitrix | `headings[2] == '## Split large tasks'` and `[3] == Mandatory entrypoint` |
| Second decisions.md entry with a new title | Keep the landed title; do not append a twin |
| Writing to `engineering/decisions.md` | Stub; existing pointer test fails dated `## 20` headings |
| Prefix names `engineering/decisions.md` | Existing self-learning test fails; do not cite stubs in the new section |
| “Split” read as two write owners | Section + this ruling: still exactly one `write_agent` |
| Two writers on AGENTS.md (`f1bdb9` vs this) | Wait, then one owner (`general_implementer` on this route) |
| Installer copies filled logs | Do not touch `install_into.py` |
| Current state stale vs new heading | One-line README update |
| Receipts before last test / README edit | Verify + reviews only after the last file that stays |
| Accidental 2.0.9 / GHA / pyproject | Existing structure tests; do not add those files |

Rollback: revert the `AGENTS.md` section, the `decisions.md` entry, the Current-state line, and the new/tightened tests. Forward-fix if already on `origin/main`. No force-push.

No named human gate. Complexity `standard`, risk `low`. Proceed after this design.
