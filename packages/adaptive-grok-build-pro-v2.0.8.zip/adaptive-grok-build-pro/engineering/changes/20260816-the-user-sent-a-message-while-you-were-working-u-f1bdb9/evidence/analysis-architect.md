# Analysis — architect

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-f1bdb9`  
Route: `f1bdb94f5af3` · write owner: `general_implementer` · reviews: `code_reviewer` + `test_reviewer`  
Question: put the push-time README rule in `AGENTS.md` (after self-learning) and `decisions.md` (≤3 sentences). Lock both with structure tests. Expand README with Current state + Read first + Map. Keep existing K10 45-edge graph.

Read-only. No application-code edits from this agent. No `.env`. No push / merge / deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. Package is `implementing`. `human_gates` empty. Stay `VERSION` **2.0.8**.

Sibling: `evidence/analysis-repo_explorer.md` (gaps it lists are now stale — prose already landed). Predecessor `79f406` designed the README onboarding; this route owns that unfinished work plus the memory write. Do not start a second write on `79f406`.

---

## Ruling

**Keep the prose already on disk. Tighten the structure tests so placement, not just substrings, cannot disappear.**

1. `AGENTS.md`: `## README before push` stays the **second** heading, immediately after `## Agent self-learning` and before `## Mandatory entrypoint`.
2. Root `decisions.md`: keep the newest entry titled **`README is the push-time product map`**, at most three sentences.
3. `README.md`: keep `## Current state`, `## Read first`, `## Map`. Do **not** touch the existing K10 mermaid.
4. `tests/test_structure.py`: lock (1)–(3) by heading order and section body. Keep `test_readme_stack_graph_is_complete` as the pairwise 45-edge oracle.

Do **not** bump `VERSION`. Do **not** rewrite CHANGELOG §2.0.8. Do **not** expand mermaid to K11+/K14. Do **not** add a `grok_deploy` / PreToolUse freshness checker. Do **not** edit `install_into.py`. Do **not** add `.github/workflows/` or `pyproject.toml`.

Architect does **not** push. After the write owner finishes the test locks, `python3 scripts/grok_verify.py --mode pr`, then independent `code_reviewer` + `test_reviewer`.

---

## 1. What already matches the contract

Live tree already contains the user-ordered memory and onboarding sections. Do not thrash them for style.

| Surface | Live fact | Keep |
| --- | --- | --- |
| `AGENTS.md` headings | `[0] Agent self-learning`, `[1] README before push`, `[2] Mandatory entrypoint` | yes |
| Rule body | Before `git push` or `python3 scripts/grok_deploy.py`, refresh `README.md`; graph must stay complete (`---` every listed pair) | yes |
| Self-learning prefix | Existing `test_agents_md_starts_with_self_learning` still holds: first heading unchanged; prefix still has root-log bullets and does **not** name `engineering/decisions.md` | do not move the new section below Mandatory entrypoint |
| `decisions.md` | `## 2026-08-16 — README is the push-time product map` is first dated entry; three sentences; names `git push`, `grok_deploy`, complete graph, structure tests | yes |
| README | `## Current state` / `## Read first` / `## Map` sit above `## What this is` and `## Stack graph` | yes |
| K10 fence | Same ten IDs, same 45 `---` pairs, `graph TD`, labels `Contract["AGENTS.md"]` / `Decisions["decisions.md"]` / `Mistakes["mistakes.md"]` | **do not edit a single mermaid line** |
| Identity | H1 and `VERSION` are `2.0.8`; README names `QUICKSTART.md` and `CHANGELOG.md` | stay 2.0.8 |

`## How work runs` is extra and harmless. Leave it.

Repo-explorer “gaps” (no heading, no decisions title, no Current state) are **closed in prose**. Remaining gap is lock strength.

---

## 2. AGENTS.md — standing rule

Placement is the design. Self-learning stays first. The push-time rule is the next always-applied heading so a rewrite cannot bury it under Bitrix/API sections.

Exact heading (already present; do not rename):

```markdown
## README before push
```

Required meaning in that section (already present; keep these tokens):

- `git push`
- `grok_deploy` (script name; full `python3 scripts/grok_deploy.py` is fine)
- complete-graph wording: `complete` **and** `---` / `edge` in the **same section**, not “declaring completion” later in the file

Do not mention `engineering/decisions.md` or `engineering/mistakes.md` anywhere before `## Mandatory entrypoint`. That would fail the existing prefix test.

Do not add a third memory file. `mistakes.md` is the error log, not this pair.

Installer: `merge_agents` wraps the whole `AGENTS.md` in the managed block. Adding this section ships to consumers on next `install_into`. That is intended. Do not add root `decisions.md` / `mistakes.md` to `MANAGED_FILES` (would clobber consumer logs).

---

## 3. decisions.md — ≤3-sentence entry

Canonical log is root `decisions.md`. `engineering/decisions.md` stays a stub. Newest first, after the intro paragraph.

Exact title (already present; this is the string `test-plan.md` named):

```markdown
## 2026-08-16 — README is the push-time product map
```

Keep the live three-sentence body. Do not add a fourth sentence. Do not append a twin entry if this title already exists.

Sentence-count rule: the body between this heading and the next `## ` has at most three `.`-terminated sentences. Abbreviations are not used in the live body; do not introduce `e.g.` / `v2.0.8.` tricks to dodge the count.

`decisions_head = text[:400]` must still contain `Patterns that paid for themselves`. The new heading sits after that sentence, so the existing self-learning test stays green.

---

## 4. README — Current state + Read first + Map

One README. Three new headings. Existing K10 stays the coupling picture. Map is navigation, not a second mermaid.

### 4.1 Section order (lock this)

```text
# Adaptive Grok Build Pro v2.0.8
## Current state
## Read first
## Map
## What this is          (existing; may sit after Map)
## Stack graph           (existing; mermaid untouched)
```

`## How work runs` may remain between Read first and Map.

### 4.2 Current state — required facts

Lock these tokens in `## Current state` (wording may vary around them):

| Token / fact | Why |
| --- | --- |
| `2.0.8` | identity; `VERSION` is SoT |
| `No GitHub Actions` (or `no GitHub Actions`) | standing ban |
| `pyproject.toml` named as forbidden | detect_repo flip |
| `self-learning` / `decisions.md` / `mistakes.md` | first contract rule |
| README-before-push mentioned | this change |

Do **not** invent “GitHub Latest is 2.0.8”. If a live line is kept, it must stay hedged (`Latest may still be an older tag`) or be re-verified at write time. Do **not** put “2.0.7 remains Latest until a human last mile” into CHANGELOG §2.0.8.

Do not rewrite CHANGELOG §2.0.8’s stale `engineering/decisions.md` bullets in this change. Optional one-liner in Current state that live logs are **root** files is enough if already implied by the AGENTS.md links.

### 4.3 Read first — required names

Ordered list must name, as markdown links:

1. `[AGENTS.md](AGENTS.md)`
2. `[decisions.md](decisions.md)`
3. `[mistakes.md](mistakes.md)`
4. `[CHANGELOG.md](CHANGELOG.md)`
5. `[QUICKSTART.md](QUICKSTART.md)`

`active-route.json` may stay backtick-only. Do not add it as a mermaid node.

### 4.4 Map — required coverage

A linked bullet list or table is fine. Must include clickable paths for:

- contract + logs: `AGENTS.md`, `decisions.md`, `mistakes.md`
- onboarding: `QUICKSTART.md`, `CHANGELOG.md`, `VERSION`
- skills / agents / hooks dirs
- scripts: at least `scripts/grok_verify.py` and `scripts/grok_deploy.py`
- `engineering/runbooks/`, `packages/`, `examples/bitrix-module/`

Do not explode into a 90-row catalog. Do not add a second ` ```mermaid ` fence.

### 4.5 K10 — frozen

`test_readme_stack_graph_is_complete` is the graph contract. Node tuple:

```text
Route, Skills, Agents, Hooks, Policy, Verify, Packages, Contract, Decisions, Mistakes
```

`C(10,2) = 45` unique undirected `---` edges. First mermaid fence only. No extra node, no dropped pair, no `-->`, no subgraphs.

Forbidden:

| Change | Why |
| --- | --- |
| K14 / 91 edges | 79f406 already rejected; operational surfaces belong in Map |
| Star / path / “key links only” | caption becomes a lie; pairwise test fails |
| Second mermaid | parser uses the first fence |
| Adding QUICKSTART / CHANGELOG / VERSION as nodes | not stack coupling |

---

## 5. Tests — fail a delete, not a substring hunt

Current new tests are too weak:

| Test | Live check | Gap |
| --- | --- | --- |
| `test_agents_md_requires_readme_refresh_before_push` | `## README before push`, `git push`, `grok_deploy`, `complete` anywhere in the file | `complete` matches “declaring completion”. Heading can move below Bitrix. |
| `test_decisions_md_records_readme_before_push` | title substring only | no ≤3-sentence lock; no `git push` in the entry |
| `test_readme_names_onboarding_docs_and_current_version` | `QUICKSTART.md`, `CHANGELOG.md`, `2.0.8` anywhere | headings `## Current state` / `## Read first` / `## Map` can vanish |

Write owner: **extend these three methods** (do not add a fourth file). Keep `test_readme_stack_graph_is_complete` unchanged.

### 5.1 AGENTS.md lock

```text
headings[0] == '## Agent self-learning'          # already in test_agents_md_starts_with_self_learning
headings[1] == '## README before push'
headings[2] == '## Mandatory entrypoint'
```

Slice the body between `## README before push` and `## Mandatory entrypoint` and assert **that slice** contains `git push`, `grok_deploy`, and (`complete` plus `---`). Do not search the whole file for `complete`.

### 5.2 decisions.md lock

- `## 2026-08-16 — README is the push-time product map` is present.
- Body until the next `## ` contains `git push` and `graph`.
- Body has at most three sentences: `len(re.findall(r'\.[ \n]', body + ' ')) <= 3` or split on `'. '` and drop empties; live body is three periods.

### 5.3 README lock

- `## Current state`, `## Read first`, `## Map` each appear as a heading line.
- `[QUICKSTART.md](QUICKSTART.md)` and `[CHANGELOG.md](CHANGELOG.md)` exist.
- `2.0.8` still in the file (already asserted).
- Existing K10 pairwise test remains the graph lock.

Do not hard-code 45 literal `'Route --- Skills'` strings. Combinations equality already exists.

If these asserts are already green on the landed tree, that is fine — **do not revert prose just to restore fail-first**. Tighten first; if a required heading is missing, add the assert (red) then the heading.

Keep `test_version_is_2_0_8_and_github_actions_are_absent` and `test_product_tree_has_no_packaging_markers` untouched.

---

## 6. Write-owner sequence

One owner: `general_implementer`. Smallest remaining vertical.

1. Tighten the three structure tests as specified. Run `python3 -m unittest tests.test_structure`.
2. Only if a new assert is red: fix the matching heading/section. Do not restyle AGENTS.md / decisions.md / README if they already pass the tightened checks.
3. Do not edit the mermaid fence, `VERSION`, `CHANGELOG.md`, `install_into.py`, `grok_deploy.py`, hooks, or `package_stack.py`.
4. Path-limited commit: `AGENTS.md`, `decisions.md`, `README.md`, `tests/test_structure.py`, this change package. No `git add -A`.
5. After the last file that will remain, `python3 scripts/grok_verify.py --mode pr`.
6. Dispatch `code_reviewer` and `test_reviewer` only after that verify. Record receipts on **this** route.

This change is **not** a 2.0.9 / tag / GitHub Release. `release.md`: stay 2.0.8. Closure is not a push. Adaptive-delivery §7 still applies: humans own last-mile commands unless a later explicit production approval says otherwise.

---

## 7. Out of scope

- New services, queues, databases, dependencies, ADRs
- OpenAPI / AsyncAPI / schema changes
- Bitrix core or `local/` product code
- Automated README-staleness gate in policy / PreToolUse / `grok_deploy`
- Copying root logs via `install_into`
- Expanding or redrawing the K10 graph
- Publishing `v2.0.8` / `v2.0.9`
- Cleaning leftover change packages (`79f406`, `2f9f5d`, …)

---

## 8. Risks

| Risk | Mitigation |
| --- | --- |
| Implementer “improves” mermaid while editing README | Do not open the fence. Existing combinations test fails any extra/missing pair |
| Weak `complete` substring | Assert inside the README-before-push section only |
| Second decisions.md entry with a new title | Keep the test-plan title; do not append a twin |
| Writing to `engineering/decisions.md` | Stub; existing pointer test fails dated `## 20` headings |
| Installer copies filled logs | Do not touch `install_into.py` |
| Receipts before last test edit | Verify + reviews only after the last `tests/test_structure.py` / package markdown write that stays |
| Accidental 2.0.9 / GHA / pyproject | Existing structure tests; do not add those files |

Rollback: revert `AGENTS.md` section, `decisions.md` entry, README onboarding headings, and the new/tightened tests. Forward-fix if already on `origin/main`. No force-push.

No named human gate. Complexity `standard`, risk `low`. Proceed after this design.
