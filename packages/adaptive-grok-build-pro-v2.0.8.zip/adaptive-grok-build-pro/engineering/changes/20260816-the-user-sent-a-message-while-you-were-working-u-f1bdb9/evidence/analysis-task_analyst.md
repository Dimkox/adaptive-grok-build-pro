# Analysis — task_analyst

Change: `20260816-the-user-sent-a-message-while-you-were-working-u-f1bdb9`  
Route: `f1bdb94f5af3` · intent=`feature` · risk=`low` · write=`general_implementer`  
Reviews after implementation: `code_reviewer` + `test_reviewer`  
Evidence kinds: `verification`, `code_review`, `test_review`  
Human gates: none  
Narrow question: **acceptance — AGENTS.md standing rule + decisions.md entry: refresh README before every `git push` / `grok_deploy`; mermaid stays a complete pairwise graph. Also finish the complete onboarding README. Stay 2.0.8.**

Read-only. No application-code edits. No `.env`. This report does not push, tag, merge, or deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md` and `feature-workflow`. This agent is in `allowed_agents`. Change package is already `implementing`. Sibling packages: `79f406` (complete onboarding README, `approved`, no implementation) and `a13da8` (K10 mermaid already in this tree).

---

## Ruling (one screen)

The user asked to **write into memory** that README must be refreshed to the current tree before every push and deploy, and that the fully-linked stack graph must always be present at push time. That memory is **not** written yet.

- Root `AGENTS.md` has no `## README before push`. First heading is still `## Agent self-learning`; next is `## Mandatory entrypoint`.
- Root `decisions.md` already records the K10 pair enumeration. It does **not** have a 2026-08-16 entry titled `README is the push-time product map` (or any push/deploy refresh rule).
- Root `README.md` already has the locked **K10 / 45 `---` edges** (a13da8). It does **not** have `## Current state`, `## Read first`, or `## Map`. It never names `QUICKSTART.md` or `CHANGELOG.md`. It has **zero** markdown links.

This route **absorbs** unfinished `79f406` (complete onboarding README). Do not spawn `79f406`'s `ai_implementer`. One write owner: `general_implementer`.

- **In:** `AGENTS.md` standing section; one ≤3-sentence `decisions.md` entry; README Current state + Read first + Map; structure tests that fail on today's tree; keep the existing K10 pair set. Identity stays **2.0.8**.
- **Out:** `VERSION` bump, zip rebuild, tag, GitHub Release, GitHub Actions, `pyproject.toml`, `install_into` `MANAGED_FILES`, `grok_deploy.py` freshness gate, exploding mermaid past 10 nodes, leftover dirt from other packages, this-route `git push`.

---

## Current facts (do not treat as done)

| Item | Today |
| --- | --- |
| `VERSION` / README H1 | `2.0.8` / `# Adaptive Grok Build Pro v2.0.8` |
| `AGENTS.md` first `##` | `## Agent self-learning` (locked). No README-before-push rule. |
| `decisions.md` newest entry | `README stack graph is K10 with every pair written out` — graph shape only, not the refresh rule |
| README mermaid | **K10 complete.** 10 ids, 45 unique undirected `---` edges. Locked by `test_readme_stack_graph_is_complete`. |
| README `## Current state` / `## Read first` / `## Map` | **Absent** |
| README hits for `QUICKSTART.md` / `CHANGELOG.md` | **Zero** |
| README markdown links | **Zero** (backticks only) |
| `79f406` | `approved`. Scope = complete onboarding README. No implementation. |
| `a13da8` | K10 + root-log names already in this tree. Do not re-litigate the pair set. |
| `2f9f5d` | Separate last-mile push of `7152b75`. **Not this route.** |
| `grok_deploy.py` | Prepare-only. Prints `git push` / tag / `gh release create`. No README check. |
| `human_gates` | `[]` |
| Identity / publish | Stay 2.0.8. No tag unless asked. |

Predecessor docs_researcher (`79f406`) already recorded: CHANGELOG §2.0.8 still says `engineering/decisions.md`; GitHub Latest was **v2.0.7**; no `v2.0.8` tag. Those are **Current state** facts, not a reason to bump or publish.

---

## 1. Outcome

After this change, a human or LLM who opens the tree sees:

1. A standing `AGENTS.md` rule, applied on every software-development task: before every `git push` and every `grok_deploy`, refresh root `README.md` to the current tree, and keep the mermaid as a complete pairwise graph.
2. A root `decisions.md` entry (≤3 sentences) that records why that rule exists.
3. A complete onboarding README: **Current state**, **Read first**, **Map**, plus the existing K10 graph that remains every-pair-linked.
4. Structure tests that go red if the rule, the decision title, the three README sections, the named first-read files, or any K10 pair disappear.
5. `VERSION` is still `2.0.8`. No tag. No GitHub Release from this route.

---

## 2. Acceptance criteria

### 2.1 `AGENTS.md` standing rule

Insert one new section **immediately after** the whole `## Agent self-learning` block (after the two bullets **and** the “This repository uses…” paragraph) and **before** `## Mandatory entrypoint`.

Exact heading:

```
## README before push
```

Required meaning (wording may vary; tests lock the tokens below):

- Refresh root `README.md` to the **current tree** before every `git push` and every `grok_deploy` (the prepare-only last mile, including `python3 scripts/grok_deploy.py` / `make deploy`).
- Purpose: anyone — human or agent — can see what lives where and how it connects.
- The mermaid stack graph must remain a **complete pairwise graph** (every listed node linked to every other). A stale README is a failed last mile, not an optional doc pass.

- [ ] **Given** `AGENTS.md` headings, **when** they are collected in order, **then** `headings[0] == '## Agent self-learning'`, `headings[1] == '## README before push'`, `headings[2] == '## Mandatory entrypoint'`. Later headings stay as they are today.
- [ ] **Given** the new section, **when** it is read, **then** it contains `git push` and `grok_deploy` and complete-graph wording (`complete` + `graph`, or `pairwise`).
- [ ] **Given** `test_agents_md_starts_with_self_learning`, **when** this lands, **then** it stays green. First heading does **not** move.
- [ ] **Given** that same test’s prefix (`text` before `## Mandatory entrypoint`), **when** the new section is written, **then** it does **not** contain `engineering/decisions.md` or `engineering/mistakes.md`. Those strings fail the existing prefix lock. Name root `README.md` / `decisions.md` / `mistakes.md` only if needed.
- [ ] **Given** the self-learning bullets, **when** this section is added, **then** they still say `log it in decisions.md` / `record it in mistakes.md` and still contain `worth the effort`, `no more than 3 sentences`, `root cause (not the symptom)`.

Do **not** add a runtime check in `scripts/grok_deploy.py` or policy. The user said «забей в память». Memory is `AGENTS.md` + `decisions.md`, locked by tests.

### 2.2 `decisions.md` entry

Newest-first. Insert immediately under the `# Decisions` intro (`Patterns that paid for themselves…`), **above** `## 2026-08-16 — README stack graph is K10 with every pair written out`.

Lockable title (test-plan):

```
## 2026-08-16 — README is the push-time product map
```

If the write owner picks a different title, the new structure test must assert **that exact title**. Prefer the string above so this report, `test-plan.md`, and the test agree.

Body: **at most three sentences** (self-learning rule). Must say:

1. README is what a reader of the pushed tree uses as the product map.
2. Refresh it before every `git push` / `grok_deploy` so current state, first reads, and the file map match HEAD.
3. Keep mermaid as a complete pairwise graph (do not ship a star or mermaid shorthand).

Do not start a second living log under `engineering/`. Stubs stay stubs.

- [ ] **Given** root `decisions.md`, **when** the new test runs, **then** it finds the title `README is the push-time product map` (or the exact title the test names).
- [ ] **Given** that entry’s body, **when** sentences are counted, **then** there are ≤3.
- [ ] **Given** `engineering/decisions.md`, **when** this lands, **then** it is still a ≤5-line stub: `Canonical log is /decisions.md`, `Do not append here`, no `## 20` dated entries.
- [ ] **Given** the existing K10 decision, **when** this entry is added, **then** that older entry remains (do not merge or delete it). One is graph shape; the new one is the refresh rule.

### 2.3 Finish the complete onboarding README (absorbs `79f406`)

Keep H1, the MIT one-liner, `## What this is`, `## Stack graph` (caption + mermaid + node table), Requirements, Install, Scripts, Hooks, Package, Bitrix, License.

Add three sections **after** the H1 + one-line pitch and **before** `## Stack graph` (What-this-is may stay where it is or sit between Read first and Stack graph; do not delete it):

```
## Current state
## Read first
## Map
```

#### Current state (opens the body)

Must make HEAD distinguishable from GitHub Latest and from CHANGELOG §2.0.8.

- [ ] **Given** `## Current state`, **when** it is read, **then** it states product identity is **2.0.8** and names the `VERSION` file as the identity source.
- [ ] **Given** that section, **when** it is read, **then** it states `AGENTS.md` first heading is Agent self-learning and live logs are **root** `decisions.md` / `mistakes.md`.
- [ ] **Given** that section, **when** it is read, **then** it states this product **never uses GitHub Actions** (or `no GitHub Actions`) and the only quality gate is local `python3 scripts/grok_verify.py --mode pr`.
- [ ] **Given** that section, **when** it is read, **then** it states there is **no** `pyproject.toml` (also no `requirements.txt` / `setup.py`).
- [ ] **Given** that section, **when** it is read, **then** it states Stop warns on missing/stale evidence and does not hard-block.
- [ ] **Given** that section, **when** it is read, **then** it does **not** claim GitHub Latest is 2.0.8. As of `79f406` research: Latest is **v2.0.7**; there is **no** `v2.0.8` tag/Release; `packages/adaptive-grok-build-pro-v2.0.8.zip` is a local tracked zip. Restate that snapshot unless a later authorized publish already exists — do not invent a Release.
- [ ] **Given** that section, **when** CHANGELOG paths are mentioned, **then** it says CHANGELOG §2.0.8 still names `engineering/decisions.md` / `engineering/mistakes.md` and those files are **stubs**. Live sinks are the root files. Do **not** rewrite CHANGELOG §2.0.8 in this change.

#### Read first (locked order)

This change package wins over the `79f406` explorer’s VERSION-first list. README itself is the front door; `VERSION` lives in Current state.

- [ ] **Given** `## Read first`, **when** the ordered list is read, **then** it names these in this order:
  1. `AGENTS.md`
  2. `decisions.md`
  3. `mistakes.md`
  4. `CHANGELOG.md`
  5. `QUICKSTART.md`
  6. `.grok-stack/runtime/active-route.json`
- [ ] **Given** those names, **when** README is searched, **then** `QUICKSTART.md` and `CHANGELOG.md` appear (this package’s `test-plan.md` lock).
- [ ] **Given** Read first, **when** links are used, **then** they are real markdown links (`[AGENTS.md](AGENTS.md)`, etc.), not backticks only. Optional extra after the six: `/adaptive-delivery` / `.grok/skills/adaptive-delivery/SKILL.md`.

#### Map

A clickable file map. Not a second mermaid.

Minimum rows (contract, logs, skills, hooks, scripts, runbooks, packages, examples):

| Must name / link | Target |
| --- | --- |
| Contract | `[AGENTS.md](AGENTS.md)` |
| Decisions | `[decisions.md](decisions.md)` |
| Mistakes | `[mistakes.md](mistakes.md)` |
| Quickstart | `[QUICKSTART.md](QUICKSTART.md)` |
| Changelog | `[CHANGELOG.md](CHANGELOG.md)` |
| Skills | `[.grok/skills/](.grok/skills/)` |
| Hooks | `[.grok/hooks/](.grok/hooks/)` |
| Verify | `[scripts/grok_verify.py](scripts/grok_verify.py)` |
| Deploy | `[scripts/grok_deploy.py](scripts/grok_deploy.py)` |
| Runbooks | `engineering/runbooks/` (at least `publish-v2.0.8.md`) |
| Packages | `[packages/](packages/)` or `[packages/README.md](packages/README.md)` |
| Examples | `[examples/bitrix-module/](examples/bitrix-module/)` |

Also in README (Current state, Map, or existing Scripts — do not drop):

- Source-of-truth order (the six-level list from `AGENTS.md`).
- Delivery loop: route → change → verify → independent reviews → `ready` → `python3 scripts/grok_deploy.py` (prepare-only) → humans own printed tag / push / GitHub Release commands.
- Bans: no GitHub Actions, no `pyproject.toml` / `requirements.txt` / `setup.py`, no unapproved production writes (`git push`, `gh release create`, etc. still need a live `grok_approve production`).

- [ ] **Given** `## Map`, **when** it is read, **then** it covers contract, logs, skills, hooks, scripts, runbooks, packages, examples with markdown links.
- [ ] **Given** existing MIT / commercial / free / public / no-EULA / no-paid-tier copy, **when** README is edited, **then** `test_readme_is_free_mit_commercial_product` stays green.
- [ ] **Given** `QUICKSTART.md`, **when** this lands, **then** it does **not** gain a second 45-edge mermaid. Skip it, or one pointer to README § Stack graph.

### 2.4 Mermaid stays a complete pairwise graph

Do **not** restyle, shrink, or grow the first ` ```mermaid ` fence.

Vertex set stays exactly:

`Route`, `Skills`, `Agents`, `Hooks`, `Policy`, `Verify`, `Packages`, `Contract`, `Decisions`, `Mistakes`

- [ ] **Given** the first mermaid fence, **when** `test_readme_stack_graph_is_complete` runs, **then** it is green: 10 ids, 45 unique undirected `---` edges, pair set == `itertools.combinations(required, 2)`.
- [ ] **Given** the caption, **when** README is edited, **then** this sentence stays verbatim: `Simple complete graph: every core piece is linked to every other.`
- [ ] **Given** labels, **when** the fence is read, **then** `Contract["AGENTS.md"]`, `Decisions["decisions.md"]`, `Mistakes["mistakes.md"]` remain.
- [ ] **Given** a temptation to add `VERSION` / `CHANGELOG.md` / `QUICKSTART.md` / `engineering/changes/` as mermaid nodes, **when** this change lands, **then** those files are in Current state / Read first / Map only. A K11+ rewrite fails the existing pair-set test.
- [ ] **Given** a regression to a star, a path, K7-plus-pendants, or mermaid `---` shorthand that drops a pair, **when** unittest runs, **then** it fails.

`79f406` architecture already ruled: a complete K10 plus an explicit file map is more usable than an unreadably dense K14. This route confirms that ruling.

### 2.5 Structure tests lock 2.1–2.4

Failing tests first. Same file: `tests/test_structure.py`.

Suggested methods (names may vary; behavior may not):

| Method | Red on today's tree because |
| --- | --- |
| `test_agents_md_has_readme_before_push_rule` | no `## README before push`; no `git push` + complete-graph wording in that slot |
| `test_decisions_md_records_readme_push_rule` | no `README is the push-time product map` |
| `test_readme_has_onboarding_sections` | no `## Current state` / `## Read first` / `## Map`; no `QUICKSTART.md` / `CHANGELOG.md` |

Keep, do not weaken:

- `test_readme_stack_graph_is_complete` (K10 pair set)
- `test_readme_names_root_self_learning_logs`
- `test_agents_md_starts_with_self_learning`
- `test_engineering_self_learning_stubs_are_pointers`
- `test_readme_is_free_mit_commercial_product`
- `test_version_is_2_0_8_and_github_actions_are_absent`
- `test_product_tree_has_no_packaging_markers`

- [ ] **Given** today’s tree, **when** the new tests run, **then** they are **red** before the doc edits.
- [ ] **Given** the new AGENTS test, **when** `## README before push` is missing, or is not `headings[1]`, or lacks `git push` / `grok_deploy` / complete-graph tokens, **then** it fails.
- [ ] **Given** the new decisions test, **when** the title is missing, **then** it fails.
- [ ] **Given** the new README test, **when** any of `## Current state`, `## Read first`, `## Map`, `QUICKSTART.md`, `CHANGELOG.md`, or `2.0.8` is missing, **then** it fails.
- [ ] **Given** a later edit that keeps the three headings but drops the K10 pair set, **when** unittest runs, **then** `test_readme_stack_graph_is_complete` still fails.
- [ ] Do not add `pyproject.toml` / `requirements.txt` / `setup.py` to light the tests. `grok_verify` already discovers `tests/test*.py`.

### 2.6 Stay 2.0.8. No tag. No GitHub Release. No push on this route.

- [ ] **Given** this change, **when** it lands, **then** `VERSION` and `__version__` remain `2.0.8`. README H1 remains `v2.0.8`. Do **not** open `2.0.9`.
- [ ] **Given** `test_version_is_2_0_8_and_github_actions_are_absent`, **when** this route closes, **then** it is unchanged and green.
- [ ] **Given** this route, **when** the write owner finishes, **then** agents have not run `git tag`, `git push origin v2.0.8`, `gh release create`, or `python3 scripts/grok_deploy.py --record`. Do not rebuild `packages/adaptive-grok-build-pro-v2.0.8.zip`.
- [ ] **Given** `tasks.md` (“Commit with already-staged keeper evidence”), **when** the write owner commits, **then** they add this ship set and **do not unstage** already-indexed keeper files. Do **not** add leftover dirt from `ad4090` / `39b13f` / `d55ce4` / other unrelated packages.
- [ ] **Given** adaptive-delivery §7, **when** this route closes, **then** closure is `ready` + receipts. This route does **not** own `git push origin main` (`2f9f5d` did). Do not treat docs memory as a publish.

Ship set (path-limited):

| Include | Why |
| --- | --- |
| `AGENTS.md` | standing rule |
| `decisions.md` | ≤3-sentence entry |
| `README.md` | Current state / Read first / Map; K10 kept |
| `tests/test_structure.py` | new locks + existing K10 |
| `engineering/changes/20260816-the-user-sent-a-message-while-you-were-working-u-f1bdb9/` | this package |
| already-staged keepers | do not drop |

Optional pointer only: do not implement inside `79f406`. The controller may later mark `79f406` superseded.

Sequence:

1. Failing structure tests for §2.1–§2.5.
2. `AGENTS.md` + `decisions.md` + README until focused unittest is green.
3. `python3 scripts/grok_verify.py --mode pr` green.
4. Independent `code_reviewer` + `test_reviewer` reports under this package.
5. Transition this change to `ready` **before** recording receipts (fingerprint includes `state.json`).
6. Record `verification`, `code_review`, `test_review` on the final fingerprint.
7. Path-limited commit including already-staged keepers.

---

## 3. Failure and edge cases

- [ ] Chat-only “remembered” with no `AGENTS.md` section fails §2.1 (user said «забей в память»; memory files are `AGENTS.md` + `decisions.md`).
- [ ] Putting `## README before push` above `## Agent self-learning` fails the existing first-heading test.
- [ ] Naming `engineering/decisions.md` inside the new AGENTS section fails the existing prefix lock.
- [ ] A `decisions.md` entry longer than three sentences violates the self-learning rule even if the test only asserts the title.
- [ ] Adding Current state but omitting Read first / Map fails `79f406` and this package’s requirements.
- [ ] Naming `QUICKSTART.md` only in chat or in this evidence file, not in README, fails §2.3.
- [ ] Claiming GitHub Latest is 2.0.8 fails Current-state honesty (`79f406` docs_researcher).
- [ ] Rewriting CHANGELOG §2.0.8 to hide the stale `engineering/` ship record is out of scope and mixes history with HEAD.
- [ ] Growing mermaid to include Map files, or shrinking it to K7, fails §2.4.
- [ ] Adding a `grok_deploy.py` hard fail on “stale README” is out of scope and is not required to accept the memory write.
- [ ] Bumping to 2.0.9, retagging, rebuilding the zip, or `gh release create` fails §2.6.
- [ ] Implementing from `ai_implementer` on `79f406` in parallel with this owner creates two writers. Forbidden.
- [ ] Pushing without a fresh production approval is not this route; do not sneak a push into the docs commit.

---

## 4. Out of scope

- `VERSION` / `__version__` / README H1 identity change. Stay 2.0.8.
- `packages/*.zip` rebuild, `git tag`, `git push`, `gh release create`, `grok_deploy --record`.
- GitHub Actions, Dependabot, `pyproject.toml` / `requirements.txt` / `setup.py`.
- `install_into` `MANAGED_FILES` / doctor required-files for the two logs (copy-list honesty is a later change; do not claim the installer copies them if it still does not).
- Runtime README-freshness detector in `deploy.py` / policy / PreToolUse.
- Exploding mermaid past K10. Duplicate mermaid in `QUICKSTART.md`.
- Rewriting CHANGELOG §2.0.8 or `dist/RELEASE-NOTES.md`.
- Mass-edit of `79f406` / `a13da8` / `2f9f5d` evidence.
- Bitrix core or Bitrix-local overlay.
- Merge, force-push, deploy, production writes.
- Opening 2.0.9 / 2.1.0.

---

## 5. Test plan (for the write owner)

| Priority | Scenario | Evidence |
| --- | --- | --- |
| P0 | New AGENTS / decisions / README tests are red on today’s tree | failing `tests/test_structure.py` methods |
| P0 | After edit: `headings[1] == '## README before push'` and section has `git push` + `grok_deploy` + complete-graph tokens | green focused test |
| P0 | `decisions.md` has the lockable title; body ≤3 sentences | green focused test + reviewer eyeball |
| P0 | README has `## Current state`, `## Read first`, `## Map`; names `QUICKSTART.md`, `CHANGELOG.md`, `2.0.8` | green focused test |
| P0 | Existing K10 pair-set test still passes (10 ids, 45/45) | `test_readme_stack_graph_is_complete` |
| P0 | Existing self-learning, stub, MIT, no-packaging, 2.0.8 / no-GHA tests stay green | `tests/test_structure.py` |
| P0 | Full gate | `python3 scripts/grok_verify.py --mode pr` |
| P1 | Manual: Read first order matches §2.3; Map links resolve; mermaid is not a star | reviewer eyeball |
| P1 | No `v2.0.8` tag / Release created by this route | `git tag` / GitHub tags page |

---

## 6. Constraints

- Backward compatibility: docs + tests only. Consumer trees pick up `AGENTS.md` on re-install / merge. Installer still does not seed empty root logs.
- Data: append one decisions entry at the root log. Do not append under `engineering/`.
- Operational: no named human gate; proceed after this ruling. This route does not push. No force-push.
- Identity: keep `2.0.8`. This is not a release.
- Parallelism: one write owner (`general_implementer`). Do not implement from this agent. Do not start `79f406`’s `ai_implementer`.
- AGENTS prefix lock: the new section sits *before* `## Mandatory entrypoint`, so it is inside `test_agents_md_starts_with_self_learning`’s prefix. Avoid `engineering/decisions.md` / `engineering/mistakes.md` there.

---

## 7. Suggested write-owner slice

1. Add failing `test_structure.py` asserts for the AGENTS heading + tokens, the decisions title, and README sections / `QUICKSTART.md` / `CHANGELOG.md` / `2.0.8`. Leave `test_readme_stack_graph_is_complete` as the pair-set lock.
2. Insert `## README before push` as `headings[1]`. Append the decisions entry (newest first, ≤3 sentences, preferred title `README is the push-time product map`).
3. Add README `## Current state`, `## Read first`, `## Map` with markdown links. Do not touch the K10 fence or caption.
4. Confirm focused tests then `python3 scripts/grok_verify.py --mode pr`.
5. Independent reviews. Transition `ready`. Bind receipts on the final tree.
6. Path-limited commit of the ship set plus already-staged keepers. Stop. No tag. No Release. No push.
