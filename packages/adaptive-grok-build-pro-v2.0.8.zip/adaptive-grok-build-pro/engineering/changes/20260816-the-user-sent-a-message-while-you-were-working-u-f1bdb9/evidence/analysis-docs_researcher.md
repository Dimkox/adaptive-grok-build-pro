# Docs research — memory files and the stale 2.0.8 log-path sentence

Route: `f1bdb94f5af3`. Change: `20260816-the-user-sent-a-message-while-you-were-working-u-f1bdb9`.

Question: `decisions.md` is the compounding log; `AGENTS.md` is always-applied. Both must carry the new README-before-push rule. CHANGELOG 2.0.8 still says `engineering/` log paths — fix that sentence in README current-state, do not rewrite published 2.0.8 history unless needed.

Read-only. No APIs invented. No `.env`. No push / merge / deploy.

Loaded `/adaptive-delivery` from `.grok/skills/adaptive-delivery/SKILL.md`. This agent is in `allowed_agents`. `write_agent` is `general_implementer`. `workflow_skills` are `adaptive-delivery` + `feature-workflow`. `human_gates` are empty. Required evidence: `verification`, `code_review`, `test_review`.

---

## Verdict

| Claim | Standing fact? |
| --- | --- |
| Root `decisions.md` is the compounding pattern log | **Yes.** Header: “Patterns that paid for themselves. Each entry is at most three sentences.” `AGENTS.md` first rule writes here. |
| `AGENTS.md` is always-applied | **Yes.** Engineering Contract; doctor required file; `install_into.merge_agents()` ships it into every consumer; first `##` is locked as `## Agent self-learning`. |
| Both must carry the new README-before-push rule | **Yes.** This package + user “запиши в память”. Memory files are exactly these two (`brief.md`). |
| `mistakes.md` is part of that standing-memory pair | **No.** Error log only. Do not put the push rule there unless a later mistake is recorded. |
| `engineering/decisions.md` is live memory | **No.** Two-line stub: “Canonical log is /decisions.md. Do not append here.” |
| CHANGELOG §2.0.8 still names `engineering/decisions.md` / `engineering/mistakes.md` | **Yes. Stale vs live root logs.** Same three bullets in `dist/RELEASE-NOTES.md`. |
| Fix that sentence in README **Current state** | **Yes.** Live snapshot belongs in README, not in published 2.0.8 history. |
| Rewrite published CHANGELOG / RELEASE-NOTES 2.0.8 | **Not needed** on this route. Stay `VERSION` 2.0.8. No tag. No zip rebuild. |

`engineering/adr/` is empty. `engineering/contracts/{openapi,asyncapi,schemas}/` are empty. There is no product API, OpenAPI, event schema, or ADR that names a README-before-push rule or a current-state section. Do not invent one. `scripts/grok_deploy.py` has no README check; the rule is standing memory + structure tests, not a new deploy API.

---

## Sources

Standing (authority):

- This change: `brief.md`, `requirements.md`, `architecture.md`, `test-plan.md`, `release.md`, `rollback.md`
- Sibling `evidence/analysis-repo_explorer.md`
- `AGENTS.md` `## Agent self-learning` + source-of-truth order + Verification + Prohibited routine actions
- Root `decisions.md` / `mistakes.md`
- `engineering/decisions.md` / `engineering/mistakes.md` (stubs)
- `README.md` (K10 already landed; no Current state / Read first / Map)
- `CHANGELOG.md` §2.0.8 (and §2.0.3 for the original graph)
- `dist/RELEASE-NOTES.md` (same 2.0.8 bullets)
- `VERSION` = `2.0.8`
- `QUICKSTART.md` (version-silent; no graph; zero hits on the logs)
- `tests/test_structure.py`
- `.grok/skills/adaptive-delivery/SKILL.md` §7
- `scripts/install_into.py` `merge_agents()` / doctor required files
- `scripts/grok_deploy.py` (prepare-only; never executes tag/push/release; no README mention)
- `engineering/runbooks/publish-v2.0.8.md` (print-only last mile; not authorized here)
- Live GitHub Latest (2026-08-16): still **v2.0.7** on `02376cc`; “2 commits to main since this release”

Predecessor packages (do not re-open their scopes except the unfinished README work this route folds in):

- `20260816-user-query-я-все-еще-не-вижу-файлов-из-промпта-д-ba1615` — `git mv` logs to root; leave CHANGELOG 2.0.8 as ship record
- `20260816-the-user-sent-a-message-while-you-were-working-u-a13da8` — K10 mermaid; CHANGELOG 2.0.8 left stale
- `20260816-the-user-sent-a-message-while-you-were-working-u-79f406` — approved, **not implemented**; designed Current state + first-reads + map; “Do not parse CHANGELOG.md for log paths. Leave §2.0.8.”
- `20260816-the-user-sent-a-message-while-you-were-working-u-2f9f5d` — push `7152b75`; no v2.0.8 tag

---

## 1. `decisions.md` is the compounding log

Quote, `decisions.md:1-3`:

```
# Decisions

Patterns that paid for themselves. Each entry is at most three sentences.
```

`AGENTS.md:3-6` (live, locked by `test_agents_md_starts_with_self_learning`):

```
## Agent self-learning

- If you make a decision that turns out to be correct and worth the effort, log it in decisions.md (pattern + why it worked, no more than 3 sentences).
- If you make a mistake that leads to a problem, identify the root cause (not the symptom) and record it in mistakes.md.
```

That is the only standing trigger that appends to the log. Entries are dated `## YYYY-MM-DD — <title>`. Latest live titles (2026-08-16) already include the K10 pair-enumeration and the `git mv` / stub move. There is **no** entry titled `README is the push-time product map` (this package’s `test-plan.md` phrase).

`engineering/decisions.md` entire file:

```
# Moved

Canonical log is /decisions.md. Do not append here.
```

`test_engineering_self_learning_stubs_are_pointers` requires that stub: ≤5 lines, `Canonical log is /decisions.md`, `Do not append here`, no `## 20` dated entries. A writer who follows an old change-package citation of `engineering/decisions.md` must hit the pointer, not a second live log.

**Write-owner implication:** append **one** 2026-08-16 entry at the top of the dated list in **root** `decisions.md`. ≤3 sentences. Title must contain `README is the push-time product map` (or the exact title the new structure test will assert — `test-plan.md` allows that fallback, so pick this phrase and lock it). Pattern + why: README is the push-time product map; refresh it to the current tree before `git push` / `grok_deploy` so every human or agent sees what is where; the K10 complete graph must still be present. Do not append under `engineering/`.

---

## 2. `AGENTS.md` is always-applied

Not a changelog and not an optional skill. Evidence it is the always-on contract:

| Surface | Fact |
| --- | --- |
| Title | `# Adaptive Grok Build Pro Engineering Contract` |
| Mandatory entrypoint | “For every software-development task” — read active-route, invoke `/adaptive-delivery` |
| Source-of-truth order | After user-approved scope: active route + change package, then contracts, then “ADRs and repository-local instructions” (this file) |
| Installer | `install_into.merge_agents()` wraps this file in the managed `AGENTS.md` block on every consumer |
| Doctor | `run_doctor` required list starts with `AGENTS.md` |
| Structure test | `test_required_files_exist`; `test_agents_md_starts_with_self_learning` locks first `##` |
| README / K10 | Node `Contract["AGENTS.md"]` |

`install_into` does **not** seed consumer `decisions.md` / `mistakes.md` / `README.md`. The standing rule that will fire on a consumer is therefore the `AGENTS.md` section, not the log entry. The log entry is how *this* repo compounds the pattern. Both are required; they are not substitutes.

`test_agents_md_starts_with_self_learning` asserts `headings[0] == '## Agent self-learning'`. Do **not** put `## README before push` first. This package `architecture.md`: insert it **immediately after** the self-learning block (before `## Mandatory entrypoint`).

`test-plan.md` lock for the new section:

- heading exactly `## README before push`
- body names `git push`
- body says the complete graph stays present

`requirements.md` also names `grok_deploy`. Put both invocation names in the section (`git push` / `grok_deploy`) so the standing rule matches the user ask (push **and** deploy) and the test-plan `git push` substring.

Do not add a `grok_deploy.py` README assertion. `scripts/grok_deploy.py` is prepare-only (“Never executes tag, push, or release”) and has no README mention. The rule is memory, not a new last-mile API.

---

## 3. Both must carry the new rule — why two files, not one

User: «забей в память … запиши в память». This package `brief.md`: “Memory files: root `decisions.md` and `AGENTS.md`.”

| File | Role | What to write |
| --- | --- | --- |
| `AGENTS.md` | Always-applied contract. Every agent that starts a task reads it. Installer ships it. | Standing `## README before push`: refresh README to the current tree before `git push` / `grok_deploy`; the fully-linked K10 graph must still be there. |
| `decisions.md` | Compounding log. Survives as a dated pattern other agents will copy. | One ≤3-sentence 2026-08-16 entry, title `README is the push-time product map`. |
| `mistakes.md` | Root-cause log | **Out.** This is a new standing rule, not a recorded mistake. |
| `engineering/decisions.md` | Stub | **Out.** Do not append. |
| Chat / change-package `architecture.md` `## Decisions` | Per-change notes | Not durable memory. |

Sibling `analysis-repo_explorer.md` already: “Do not treat `engineering/adr/` or chat as standing memory.” Confirmed: `engineering/adr/` is empty.

---

## 4. CHANGELOG 2.0.8 still says `engineering/` log paths

Quote, `CHANGELOG.md:3-9` (entire §2.0.8):

```
## 2.0.8 — 2026-08-16

Agent self-learning is the first AGENTS.md rule.

- `AGENTS.md` starts with log-to-`engineering/decisions.md` / `engineering/mistakes.md`
- Structure test locks that placement so a rewrite cannot drop it
- Still no GitHub Actions
```

`dist/RELEASE-NOTES.md` is the same three bullets. That is the 2.0.8 **ship record**, frozen when identity was cut. The live contract and the live structure test now **forbid** those paths in the `AGENTS.md` prefix (`assertNotIn('engineering/decisions.md', prefix)`).

ba1615, a13da8, and 79f406 already recorded this as stale-vs-live, not as a bug to silently rewrite:

- ba1615: “Rewriting old change-package citations of `engineering/decisions.md`” is out of scope. Historical text describes the path that existed then.
- a13da8 implementation: “Published `CHANGELOG.md` §2.0.8 and the 2.0.8 zip still describe `engineering/` as the log path. Left as the ship record.”
- 79f406 architect: “Do **not** parse `CHANGELOG.md` for log paths. §2.0.8 is the 2.0.8 ship record and still says `engineering/decisions.md`. Leave it.” Rewriting §2.0.8 is listed as a forbidden action.

This route’s `release.md`: “Stay 2.0.8. No tag unless asked.” So a 2.0.9 correction bullet is not authorized, and republishing the 2.0.8 zip/notes is not authorized.

**Unless needed** (when a rewrite *would* be justified — none of these are this route):

1. A later identity (`2.0.9`) owns a one-line correction in a **new** changelog section.
2. The user explicitly orders a rewrite of published 2.0.8 history / `dist/RELEASE-NOTES.md` / the tracked zip.
3. A human last mile cuts GitHub Release `v2.0.8` and chooses to edit notes *for that publish*. `publish-v2.0.8.md` still points at `dist/RELEASE-NOTES.md` as-is. This route does not run it.

**Needed now:** put the correction in README **Current state**, which is the live snapshot. Do not touch `CHANGELOG.md` §2.0.8, `dist/RELEASE-NOTES.md`, or `packages/adaptive-grok-build-pro-v2.0.8.zip`.

---

## 5. The sentence to put in README Current state

Live README has **no** `## Current state`, `## Read first`, or `## Map`. Title is already `# Adaptive Grok Build Pro v2.0.8`. It names `decisions.md` / `mistakes.md` in What-this-is, the K10 mermaid, the node table, and the manual copy list. It does **not** name `QUICKSTART.md` or `CHANGELOG.md` (`test-plan.md` requires those names). It does **not** warn that CHANGELOG 2.0.8 still points at `engineering/`.

This package headings (authority for the write owner; unfinished 79f406 used different labels):

| This route (`f1bdb9`) | Unfinished 79f406 design | Use |
| --- | --- | --- |
| `## Current state` | `## Current state` | **This name** |
| `## Read first` | `## Start here` | **`Read first`** (active package) |
| `## Map` | `## Product link map` | **`Map`** (active package) |
| Keep existing K10 | Keep existing K10 | Keep; do not expand to K14 |

79f406 is `approved` with no implementation. This route’s user prompt says finish unfinished previous-turn work. Fold that README fill-in under **these** headings. Do not implement a second mermaid. Do not add `Changes` / `Receipts` / `Doctor` / `Deploy` as mermaid nodes (79f406 architect rejected K14 / 91 edges). Those four stay navigation rows in **Map**.

**Current state must say, as a live fact (not as a changelog edit):**

- Identity is **2.0.8** (`VERSION`; H1 already matches).
- Live self-learning sinks are **root** [`decisions.md`](decisions.md) / [`mistakes.md`](mistakes.md).
- CHANGELOG **2.0.8** (and `dist/RELEASE-NOTES.md`) still say `AGENTS.md` starts with log-to-`engineering/decisions.md` / `engineering/mistakes.md`. Those `engineering/` files are now stubs (“Canonical log is /…. Do not append here.”). Do not send agents there.
- Stack graph is the existing K10 complete mermaid (45 undirected `---` pairs). That graph must still be in README at every push.
- No GitHub Actions; local `python3 scripts/grok_verify.py --mode pr` is the only gate (already a standing `decisions.md` 2026-08-16 ban).
- Last mile is prepare-only `python3 scripts/grok_deploy.py`; humans own printed tag / push / `gh release`.

Suggested Current-state sentence for the stale ship record (write owner may tighten; keep these path names):

> CHANGELOG 2.0.8 still says `AGENTS.md` logs to `engineering/decisions.md` / `engineering/mistakes.md`. Live logs are root `decisions.md` / `mistakes.md`. The `engineering/` paths are stubs. Do not append there.

`test-plan.md` also: README names `QUICKSTART.md`, `CHANGELOG.md`, and current `2.0.8`. Prefer markdown links `[QUICKSTART.md](QUICKSTART.md)` and `[CHANGELOG.md](CHANGELOG.md)` in **Read first** (79f406 already required clickable links; backticks-only is the current gap).

Do **not** write a live git SHA into Current state (79f406 architect: it goes stale). Optional freshness that is still true as of this report and is *not* required by this package’s test-plan: GitHub Latest remains **v2.0.7** on `02376cc`; there is no `v2.0.8` tag. If mentioned, phrase it as “GitHub Latest is still the 2.0.7 Release” without pinning a SHA. This route does not publish 2.0.8.

---

## 6. Unfinished previous-turn work this route already owns

79f406 (`Complete onboarding README`) is approved, not implemented. Current README is still the a13da8 product card: K10 + root-log names, no first-read order, no current-state table, no linked map. Completing that is in this package’s `requirements.md` / `architecture.md`, not a second write owner.

Keep, do not rewrite:

- Caption: `Simple complete graph: every core piece is linked to every other.`
- First mermaid fence: the ten IDs `Route, Skills, Agents, Hooks, Policy, Verify, Packages, Contract, Decisions, Mistakes` and all 45 `---` pairs (`test_readme_stack_graph_is_complete`).
- MIT / commercial / free / public / no EULA / no paid tier (`test_readme_is_free_mit_commercial_product`).
- `VERSION` = `2.0.8` (`test_version_is_2_0_8_and_github_actions_are_absent`).

`QUICKSTART.md` stays the 7-step install path. a13da8: skip a second graph there. A one-line pointer at README is enough if the write owner wants it; this package does not require a QUICKSTART edit.

---

## 7. Related docs this change must not treat as APIs

| Surface | Fact |
| --- | --- |
| `engineering/adr/` | Empty. No ADR to add for a memory/docs rule. |
| Contracts | Empty. No OpenAPI / AsyncAPI / schema for README or logs. |
| `feature-workflow` | Outcome → acceptance. No README API. |
| `install_into.py` | Merges `AGENTS.md` only. Do not invent `MANAGED_FILES` entries for `decisions.md` / README. |
| `grok_deploy.py` | Prepare-only. No README gate to add. |
| `CHANGELOG.md` §2.0.8 | Published ship record. Leave it. |
| `dist/RELEASE-NOTES.md` | Same ship record. Leave it. |
| `packages/…v2.0.8.zip` | Tracked 2.0.8 artifact. Do not rebuild. |
| `publish-v2.0.8.md` | Print-only last mile. Not authorized here. |
| Historical change-package citations of `engineering/decisions.md` | Closed evidence. Do not mass-edit. |

---

## Fact for the write owner

1. **Memory pair is `AGENTS.md` + root `decisions.md`.** Always-applied contract + compounding log. Not `mistakes.md`. Not `engineering/decisions.md`. Not chat.
2. **`AGENTS.md`:** add `## README before push` immediately after `## Agent self-learning`. Name `git push` and `grok_deploy`. Say the complete graph must still be in README. Do not move self-learning off heading 1.
3. **`decisions.md`:** one ≤3-sentence 2026-08-16 entry titled `README is the push-time product map`. Append only at the root file.
4. **README:** add `## Current state`, `## Read first`, `## Map`. Keep the locked K10. Name `QUICKSTART.md`, `CHANGELOG.md`, `2.0.8`.
5. **The stale 2.0.8 sentence lives in Current state**, not in CHANGELOG. Quote that CHANGELOG 2.0.8 still says `engineering/decisions.md` / `engineering/mistakes.md`, then state the live root sinks and the stubs. Do not rewrite `CHANGELOG.md` §2.0.8, `dist/RELEASE-NOTES.md`, or the 2.0.8 zip unless a later identity or an explicit user order owns that history edit. Not needed here.
6. Lock: `tests/test_structure.py` — AGENTS heading + `git push` / complete-graph wording; decisions.md title; keep `test_readme_stack_graph_is_complete`. Stay `VERSION` 2.0.8. No tag, pack, GHA, or `pyproject.toml`.
